( function( $ ) {
  
   
      /*--------------------------------------------------------
            / 1. Hero Slider
     /----------------------------------------------------------*/
      var intro_banner = function( $scope, $ ) {
    
            var $container     = $scope.find('.hero-slider');
            var $container_nav = $scope.find('.slider-nav-tab');
            var autoplay       = true;
            var progressbar    = true;
            var speed          = 2000;
                autoplay       = Boolean( $container.attr('data-autoplay') );
                progressbar    = Boolean( $container.attr('data-progressbar') );
                speed          = parseInt( $container.attr('data-speed') );
         
         
             if ($container.length > 0) {

                $container.slick({
                    autoplay: autoplay,
                    autoplaySpeed: speed,
                    slidesToShow: 1,
                    dots: progressbar,
                    arrows: false,
                    centerMode: true,
                    asNavFor: $container_nav,
                    centerPadding: '0'
                });

                $container_nav.slick({
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    asNavFor: $container,
                    dots: false,
                    centerPadding: '0',
                    centerMode: true,
                    focusOnSelect: true
                });

            }

      
    }; 
    /* end hero */
        /*--------------------------------------------------------
        / 2. Hero Slider 02
        /----------------------------------------------------------*/
    var Widget_hero_slider = function( $scope, $ ) {

        var $container  = $scope.find('.hero-slider-two');
     
        if( $container.length > 0){
            $container.owlCarousel({
                loop: false,
                margin: 0,
                responsiveClass: true,
                smartSpeed: 700,
                center: false,
                autoplay: true,
                animateIn: 'fadeIn',
                animateOut: 'fadeOut',
                nav: false,
                dots: true,
                items: 1
            });
        }
  
      }; 

      /*--------------------------------------------------------
      / 3. Quote Service Slider 
      /----------------------------------------------------------*/
      
      var Widget_quote_service = function( $scope, $ ) {

        var $container  = $scope.find('.quote-serive-slider');

        var controls    = null;
        var control_obj = {};
        
        controls    = JSON.parse($container.attr('data-controls'));
        control_obj = insut_slider_controls(controls);
             if(!control_obj.slider_enable){
                return; 
             }
            $container.owlCarousel({
              loop:control_obj.insut_slider_loop,
              autoplay:control_obj.insut_slider_autoplay,
              nav:control_obj.insut_slider_nav_show,
              autoplayTimeout:control_obj.insut_slider_autoplay_timeout,
              autoplayHoverPause:control_obj.insut_slider_autoplay_hover_pause,
              margin:control_obj.insut_slider_margin,
              navText: ['<i class="icofont-arrow-left"></i>', '<i class="icofont-arrow-right"></i>'],
              responsive:{
                0:{
                  items:control_obj.insut_slider_items_mobile
                },
                700:{
                  items:control_obj.insut_slider_items_tablet
                },
                1023:{
                  items:control_obj.insut_slider_items
                }
              }
          });
  
      }; 

            /*--------------------------------------------------------
      / 3. Widget_Testimonial_Slider  
      /----------------------------------------------------------*/
      
      var Widget_Testimonial_Slider = function( $scope, $ ) {

        var $container  = $scope.find('.testimonial-slider-ele');

        var controls    = null;
        var nav         = null;
        var style         = null;
        var control_obj = {};
        
        controls    = JSON.parse($container.attr('data-controls'));
        nav         = $container.attr('data-nav');
        style         = $container.attr('data-style');
       
        control_obj = insut_slider_controls(controls);
       
             if(!control_obj.slider_enable){
                return; 
             }

             if (typeof nav === "undefined" ) {
              
                  $container.owlCarousel({
                    loop:control_obj.insut_slider_loop,
                    autoplay:control_obj.insut_slider_autoplay,
                    nav:control_obj.insut_slider_nav_show,
                    autoplayTimeout:control_obj.insut_slider_autoplay_timeout,
                    autoplayHoverPause:control_obj.insut_slider_autoplay_hover_pause,
                    margin:control_obj.insut_slider_margin,
                    animateIn: 'fadeIn',
                    animateOut: 'fadeOut',
                    responsiveClass: true,
                    center: false,
                    navText: ['<i class="icofont-arrow-left"></i>', '<i class="icofont-arrow-right"></i>'],
                    responsive:{
                      0:{
                        items:control_obj.insut_slider_items_mobile
                      },
                      992:{
                        items:control_obj.insut_slider_items_tablet
                      },
                      1023:{
                        items:control_obj.insut_slider_items
                      }
                    }
                });
              }else if( nav == 'dot' && style == 'style4' ){

                $container.owlCarousel({
                  loop:control_obj.insut_slider_loop,
                  autoplay:control_obj.insut_slider_autoplay,
                  nav:false,
                  dots:control_obj.insut_slider_nav_show,
                  autoplayTimeout:control_obj.insut_slider_autoplay_timeout,
                  autoplayHoverPause:control_obj.insut_slider_autoplay_hover_pause,
                  margin:control_obj.insut_slider_margin,
                  animateIn: 'fadeIn',
                  animateOut: 'fadeOut',
                  responsiveClass: true,
                  center: false,
                  navText: ['<i class="icofont-arrow-left"></i>', '<i class="icofont-arrow-right"></i>'],
                  responsive:{
                    0:{
                      items:control_obj.insut_slider_items_mobile
                    },
                    992:{
                      items:control_obj.insut_slider_items_tablet
                    },
                    1023:{
                      items:control_obj.insut_slider_items
                    }
                  }
              });
            }else{

              $container.owlCarousel({
                loop:control_obj.insut_slider_loop,
                autoplay:control_obj.insut_slider_autoplay,
                nav:false,
                dots:control_obj.insut_slider_nav_show,
                autoplayTimeout:control_obj.insut_slider_autoplay_timeout,
                autoplayHoverPause:control_obj.insut_slider_autoplay_hover_pause,
                margin:control_obj.insut_slider_margin,
                animateIn: 'fadeIn',
                animateOut: 'fadeOut',
                responsiveClass: true,
                center: false,
                navText: ['<i class="icofont-arrow-left"></i>', '<i class="icofont-arrow-right"></i>'],
                responsive:{
                  0:{
                    items:control_obj.insut_slider_items_mobile
                  },
                  992:{
                    items:control_obj.insut_slider_items_tablet
                  },
                  1023:{
                    items:control_obj.insut_slider_items
                  }
                }
            });

             }
         
  
      }; 

        /*--------------------------------------------------------
      / 5. Case Suffle
      /----------------------------------------------------------*/
      
      var Widget_Case_Study = function( $scope, $ ) {

        var $container  = $scope.find('.shafull-container');
 
        $(window).on('load', function () {
          if ($container.length > 0)
          {
              var $grid = $('.shafull-container');
              $container.shuffle({
                  itemSelector: '.shaf-item',
                  sizer: '.shaf-sizer'
              });
              /* reshuffle when user clicks a filter item */
              $('.shaf-filter li').on('click', function () {
                  // set active class
                  $('.shaf-filter li').removeClass('active');
                  $(this).addClass('active');
                  // get group name from clicked item
                  var groupName = $(this).attr('data-group');
                  // reshuffle grid
                  $container.shuffle('shuffle', groupName);
              });
          }
      });
  
      }; 
  
  

	// Make sure you run this code under Elementor.
	$( window ).on( 'elementor/frontend/init', function() {
        
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/insut-intro-banner.default', intro_banner );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/insut-intro-banner-button.default', Widget_hero_slider );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/insut-quote-service.default', Widget_quote_service );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/insut-testimonial-slider.default', Widget_Testimonial_Slider );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/insut-case-study.default', Widget_Case_Study );
	   
    } );

   
   // utility function  
   // get slider control default settings
   function insut_slider_controls(controls=[]){
    var newObj = {

      insut_slider_autoplay:true,
      insut_slider_loop:false,
      insut_slider_autoplay_hover_pause:false,
      insut_slider_autoplay_timeout:5000,
      insut_slider_dot_nav_show:false,
      insut_slider_items:2,
      insut_slider_items_mobile:1,
      insut_slider_items_tablet:3,
      insut_slider_margin:20,
      insut_slider_nav_show:false,
      slider_enable:true,
      insut_slider_smart_speed:250,

    };
  
    if ('insut_slider_autoplay' in controls){
      if(controls.insut_slider_autoplay == 'yes'){
        newObj.insut_slider_autoplay = true;
      }else{
        newObj.insut_slider_autoplay = false;
      }  
    }  
    
    if ('insut_slider_loop' in controls){
      if(controls.insut_slider_loop == 'yes'){
        newObj.insut_slider_loop = true;
      }else{
        newObj.insut_slider_loop = false;
      }  
    }

    if ('insut_slider_dot_nav_show' in controls){
      if(controls.insut_slider_dot_nav_show == 'yes'){
        newObj.insut_slider_dot_nav_show = true;
      }else{
        newObj.insut_slider_dot_nav_show = false;
      }  
    } 
    
    if ('slider_enable' in controls){
      if(controls.slider_enable == 'yes'){
        newObj.slider_enable = true;
      }else{
        newObj.slider_enable = false;
      }  
    }
     if ('insut_slider_nav_show' in controls){
      if(controls.insut_slider_nav_show == 'yes'){
        newObj.insut_slider_nav_show = true;
      }else{
        newObj.insut_slider_nav_show = false;
      }  
    }

    if ('insut_slider_autoplay_timeout' in controls){
       newObj.insut_slider_autoplay_timeout = parseInt( controls.insut_slider_autoplay_timeout );
    }

    if ('insut_slider_items' in controls){
        newObj.insut_slider_items = parseInt( controls.insut_slider_items || 1 );
    }
    
    if ('slider_enable' in controls){
        newObj.slider_enable = Boolean( controls.slider_enable =='yes'?true:false);
    }

    if ('insut_slider_items_mobile' in controls){
        newObj.insut_slider_items_mobile = parseInt( controls.insut_slider_items_mobile || 1 );
    }
    if ('insut_slider_items_tablet' in controls){
        newObj.insut_slider_items_tablet = parseInt( controls.insut_slider_items_tablet || 1 );
    }
    
    if ('insut_slider_margin' in controls){
        newObj.insut_slider_margin =  controls.insut_slider_margin || '0';
    } 
    
    if ('insut_slider_smart_speed' in controls){
        newObj.insut_slider_smart_speed =  controls.insut_slider_smart_speed || 250;
    }
    return newObj; 
  }



  
} )( jQuery );


