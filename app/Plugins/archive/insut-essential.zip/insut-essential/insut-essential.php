<?php
/*
* Plugin Name: Insut Essentials
* License - GNU/GPL V2 or Later
* Description: This is a essential plugin for insut theme.
* Version: 1.0
* text domain: insut-essential
*/

// If this file is calledd directly, abort!!!
defined( 'ABSPATH' ) or die( 'Hey, what are you doing here? You silly human!' );

// Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/** 
 * plugin constant
 */
define( 'QTRP', true );
define( 'INSUT_ESSENTIAL_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'INSUT_ESSENTIAL_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'INSUT_ESSENTIAL_PLUGIN',plugin_basename( dirname( __FILE__ ) ) . '/insut-essential.php');
define( 'INSUT_ESSENTIAL_IMG', get_template_directory_uri() . '/assets/images');
define( 'INSUT_ESSENTIAL_CSS', get_template_directory_uri() . '/assets/css');
define( 'INSUT_ESSENTIAL_THEME_DIR', get_template_directory() );
define( 'INSUT_ESSENTIAL_CSS_DIR', INSUT_ESSENTIAL_THEME_DIR . '/assets/css' );
/**
 * The code that runs during plugin activation
 */
add_action( 'plugins_loaded', 'insut_essential_crb_load' );

function insut_essential_crb_load() {

	\Carbon_Fields\Carbon_Fields::boot();
	
}

function insut_activate_essential_plugin() {
	InsutEssential\Base\Activate::activate();
}
register_activation_hook( __FILE__, 'insut_activate_essential_plugin' );

/**
 * The code that runs during plugin deactivation
 */
function insut_deactivate_essential_plugin() {
	InsutEssential\Base\Deactivate::deactivate();
}

register_deactivation_hook( __FILE__, 'insut_deactivate_essential_plugin' );

/**
 * Initialize all the core classes of the plugin
 */

if ( class_exists( 'InsutEssential\\Init' ) ) {
	InsutEssential\Init::register_services();
	InsutEssential\Init::register_modules();
}
// codester custom fonts
add_action('csf_loaded',function(){

	$themefonts = new \InsutEssential\Base\ThemeFonts();
	$themefonts->register();
	
});


