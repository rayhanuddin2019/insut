<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class About_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-service-box';
    }

    public function get_title() {
        return esc_html__( 'About Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'insut-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                    'imagelarge' => INSUT_IMG . '/service/style1.png',
                    'imagesmall' => INSUT_IMG . '/service/style1.png',
                    'width'      => '100%',
               ],

         
           ],

         ]
       ); 
       $this->end_controls_section();




        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Service settings', 'insut-essential'),
            ]
        );
       
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Title', 'insut-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
     
		$repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( 'List Content' , 'insut-essential' ),
				'show_label' => false,
			]
		);

        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );

        $repeater->add_control(
			'list_shadow_icon',
			[
				'label' => esc_html__( 'Shadow Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );

        
        $repeater->add_control(
			'list_url', [
				'label'      => esc_html__( 'Url', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::URL,
				
			
			]
        );
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'About List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
   
     
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .single-feature-box' => 'text-align: {{VALUE}};',
                    

				],
			]
        );//Responsive control end

        $this->end_controls_section();
      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Title color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .single-feature-box h4' => 'color: {{VALUE}};',
				],
			]
        );
        $this->add_control(
			'title_hovr_color', [

				'label'     => esc_html__( 'Title color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .single-feature-box:hover h4' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .single-feature-box h4',
            ]
        );
        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-feature-box h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-feature-box h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'section_desc_style', [
				'label' => esc_html__( 'Description', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'desc_color', [

				'label'     => esc_html__( 'Desc color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .single-feature-box p' => 'color: {{VALUE}};',
				],
			]
        );

        $this->add_control(
			'desc_hover_color', [

				'label'     => esc_html__( 'Hover color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .single-feature-box:hover p' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .single-feature-box p',
            ]
        );

        $this->add_responsive_control(
            'desc_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-feature-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'desc_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-feature-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
       
        
        $this->start_controls_section('box_view_more_section',
                [
                    'label' => esc_html__( 'View More', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                    'condition' => [ 'block_style' => ['style1'] ],
                ]
        );

        $this->add_control(
			'view_more_color', [

				'label'     => esc_html__( 'Color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .read-more i' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'view_more_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .read-more i',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name'     => 'hover_overlay_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .read-more',
            ]
         );

        $this->add_responsive_control(
            'view_more_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'view_more_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control('box_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  
                    '{{WRAPPER}} .single-feature-box' => 'background: {{VALUE}};',
                        
                    ],
                ]
            );

            $this->add_control(
                'box_hv_background_heading1',
                [
                    'label' => esc_html__( 'Background Hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'block_style' => ['style1'] ],
                ]
            );

            $this->add_control('box_hvs_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style1'] ],
                'selectors' => [
                      '{{WRAPPER}} .single-feature-box:hover' => 'background: {{VALUE}};',
                            
                    ],
                ]
               
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'     => 'box_border',
                    'label'    => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .single-feature-box',
                ]
            );


            $this->add_responsive_control(
                '_box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .single-feature-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                     
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        
                        '{{WRAPPER}} .single-feature-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                ]
            );

            $this->add_responsive_control(
                'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .single-feature-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                        ],
                    ]
            );


        $this->end_controls_section();
      
     $this->start_controls_section('appscred_box_media_section',
        [
        'label' => esc_html__( 'Media', 'insut-essential' ),
        'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'icon_color_background', [

                'label'     => esc_html__( 'Icon background shape color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style2','style4'] ],
                'selectors' => [
                '{{WRAPPER}} .our-sevices-item .icon::before ' => 'background: {{VALUE}};',
                '{{WRAPPER}} .services-7-item .icon ' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'box_icon_color', [

                'label'     => esc_html__( 'Box Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .our-sevices-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .sevices-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .services-5-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .services-7-item .icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
			'box_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .our-sevices-item svg' => 'width: {{SIZE}}{{UNIT}};',
				
				],
			]
        );

        $this->add_responsive_control(
			'box_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .sevices-item svg' => 'height: {{SIZE}}{{UNIT}};',
				
				],
			]
        );

        $this->add_responsive_control(
            'media_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .sevices-item svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                        
                    ],
                ]
            );

            $this->add_responsive_control(
            'media_box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .our-sevices-item svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                    ],
                ]
            );
    $this->end_controls_section();

    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
        $list = $settings['list'];
       
    ?>
   
     <?php if( $settings['block_style'] == 'style1' ): ?>


        <!-- Feature Section Start -->
   
        
                <div class="row">
                    <?php foreach($list as $item): ?>
                        <div class="col-lg-4 col-md-6">
                            <!-- Feature Box Start -->
                            <div class="single-feature-box">
                                <div class="feature-icon"> 
                                       <?php if( $item['list_shadow_icon']['value'] == '' ): ?>
                                           <i class="flaticon-wifi-router"></i>
                                        <?php else: ?>
                                            <?php \Elementor\Icons_Manager::render_icon( $item['list_shadow_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif; ?>
                                    <div class="box-bg-icon">
                                        <?php if( $item['list_icon']['value'] == '' ): ?>
                                           <i class="flaticon-wifi-router"></i>
                                        <?php else: ?>
                                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <h4> <?php echo esc_html($item['list_title']); ?> </h4>
                                <?php if($item['list_content'] !=''): ?>
                                    <p>
                                        <?php echo insut_kses($item['list_content']); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if($item['list_url'] != ''): ?>
                                   <a class="read-more" href="<?php echo esc_url($item['list_url']); ?>"><i class="icofont-arrow-right"></i></a>
                                <?php endif; ?>
                            </div>

                            <!-- Feature Box End -->
                        </div>
                    <?php endforeach; ?>
                </div>
           
       
        <!-- Feature Section End -->

      
    <?php endif; ?>
     
 



    <?php  

    }
    
    protected function _content_template() { }
}