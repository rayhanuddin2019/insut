<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Single_Testimonial extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-singles-testimonial';
    }

    public function get_title() {
        return esc_html__( 'Insut Testimonial', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fa fa-quote-left';
    }
    public function get_keywords() {
		return [ 'testimonila' , 'insut' , 'quote' ];
    }
    public function get_categories() {
        return [ 'insut-elements' ];
    }
    public function layout(){
        return[
            
            'style1'   => esc_html__( 'Standard', 'insut-essential' ),
            'style2'   => esc_html__( 'Icon', 'insut-essential' ),
     
        
    
        ];
    }
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        
            $this->add_control(
                'content', [

                    'label'       => esc_html__( 'Content', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Get in ', 'insut-essential' ),
                    'default'     => esc_html__( 'Service We Offer ', 'insut-essential' ),
                    
                ]
            ); 

            $this->add_control(

                'show_border',
                [
                    'label'        => esc_html__( 'Show Border left', 'insut-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Show', 'insut-essential' ),
                    'label_off'    => esc_html__( 'Hide', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]

            );

          
     
            $this->add_responsive_control(
                'title_align', [
                    'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'insut-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'insut-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'insut-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                    ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'insut-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                    'default' => 'center',
                    'selectors' => [
                        '{{WRAPPER}} blockquote'   => 'text-align: {{VALUE}};',
                     
                    ],
                ]
            );//Responsive control end
        $this->end_controls_section();


        $this->start_controls_section(
			'section_sub_title_style', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
               
			]
        );

            $this->add_control(
                'sub_title_color', [

                    'label'		 => esc_html__( 'Color', 'insut-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} blockquote' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'sub_title_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} blockquote',
                
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} blockquote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} blockquote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => '_item_content_section_border',
                    'label' => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} blockquote',
                    'condition' => [ 'style' => ['style2'] ],
                ]
            );

            $this->add_responsive_control(
                'title_border_right_width',
                [
                    'label' => esc_html__( 'Border Active Width', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'condition' => [ 'style' => ['style1'] ],
                    'selectors' => [
                        '{{WRAPPER}} blockquote:after' => 'width: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} blockquote:before' => 'width: {{SIZE}}{{UNIT}};',
               
                
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_border_right_heiht',
                [
                    'label' => esc_html__( 'Border Active Height', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'condition' => [ 'style' => ['style1'] ],
                    'selectors' => [
                        '{{WRAPPER}} blockquote:after' => 'height: {{SIZE}}{{UNIT}};',
               
                
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'left_border_bg_active_color',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} blockquote:after, {{WRAPPER}} .content-area blockquote',
                ]
            );
       
            $this->add_responsive_control(
                'title_border_right_inactive_heiht',
                [
                    'label' => esc_html__( 'Border InActive Height', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'condition' => [ 'style' => ['style1'] ],
                    'selectors' => [
                        '{{WRAPPER}} blockquote:before' => 'height: {{SIZE}}{{UNIT}};',
               
                
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'left_border_bg_inactive_color',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} blockquote:before',
                    'condition' => [ 'style' => ['style1'] ],
                ]
            );
        $this->end_controls_section();

       

     
    } //Register control end

    protected function render( ) { 

		$settings     = $this->get_settings();
		$content        = $settings['content'];
	
       
    ?>    
          
        <?php if($settings['style'] == 'style1'): ?>
            <div class="ab-ht-content">
                            
                <blockquote class="<?php echo esc_attr( $settings['show_border'] !='yes'?'no-shape':'' ); ?>" >
                    <?php echo insut_kses($content) ?>
                </blockquote>

            </div>
                           
        <?php endif; ?>

        <?php if($settings['style'] == 'style2'): ?>
            <div class="content-area">
                            
                <blockquote>
                    <?php echo insut_kses($content) ?>
                </blockquote>

            </div>
                           
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}