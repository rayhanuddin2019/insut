<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class Intro_Banner_Button extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-intro-banner-button';
    }

    public function get_title() {
        return esc_html__( 'Intro Banner Button', 'insut-essential' );
    }

    public function get_icon() { 
        return "fab fa-adversal";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );
            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Tab Slide', 'insut-essential' ),
                        'style2' => esc_html__( 'Button Slide', 'insut-essential' ),
            
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__('Intro Banner Content', 'insut-essential'),
            ]
        );
 
        $repeater = new \Elementor\Repeater();

	
        
        $repeater->add_control(
			'list_sub_title', [
				'label' => esc_html__( 'Top Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Top Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);

        $repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( 'List Content' , 'insut-essential' ),
				'show_label' => true,
			]
        );


		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Content List', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( 'Title #1', 'insut-essential' ),
						
					],
					
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

      $this->end_controls_section();
      $this->start_controls_section(
            'section_content_form_tab',
            [
                'label' => esc_html__('Button Fields', 'insut-essential'),
            ]
        );

        
            $this->add_control(
                'form_action', [
                    'label'       => esc_html__( 'Find Page Url', 'insut-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'form_submit_text', [
                    'label'       => esc_html__( 'Submit text', 'insut-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Find' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'form_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                ]
            );

      $this->end_controls_section();

       // sub Title Style Section
		$this->start_controls_section(
			'section_sub_title_style', [
				'label' => esc_html__( 'Sub Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'sub_title_color', [

                        'label'     => esc_html__( 'Sub Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-slider-two-item .top-title' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'sub_title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .hero-slider-two-item .top-title',
                    ]
                );

                $this->add_responsive_control(
                    'sub_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'sub_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

       
      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-slider-two-item .title' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .hero-slider-two-item .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Sub Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-slider-two-item p' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .hero-slider-two-item p',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-two-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        
     

        $this->start_controls_section(
			'section_submit_button_style', [
				'label' => esc_html__( ' Button ', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
            ]
            
        );
                $this->add_control(
                    'button_color2', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv2', [

                        'label'     => esc_html__( 'Hover color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho2',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

                $this->add_control(
                    'button_icon_color2', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn i' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_icon_typho2',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn i',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );
                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Background hover color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input__section_hv_background_2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .insut-btn:after',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .insut-btn' => 'border-radius: {{VALUE}}px;',
                               
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border2',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );


        $this->end_controls_section();
        
        $this->start_controls_section('insut_progressbar_section',
            [
            'label' => esc_html__( 'Progress', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'progressbar_background_2',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .hero-slider-two.owl-carousel .owl-dots .owl-dot',
            ]
        );

        $this->add_control(
            'progress__heading__2',
            [
                'label' => esc_html__( 'Background active', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'progressbar_background_active_23',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .hero-slider-two.owl-carousel .owl-dots .owl-dot:after',
            ]
        );

        $this->add_responsive_control(
            'progressbar__margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero-slider .slick-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        
      
		
        $this->start_controls_section('appscred_box_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'section_height',
                    [
                        'label' => esc_html__( 'Height', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%','vh' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .main-section' => 'height: {{SIZE}}{{UNIT}};',
                            
                            
                        ],
                       
                    ]
                );
                
     $this->end_controls_section();
     	
     $this->start_controls_section('appscred_inner_box_section',
        [
        'label' => esc_html__( 'Inner Slider', 'insut-essential' ),
        'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

         $this->add_group_control(
         \Elementor\Group_Control_Background::get_type(),
             [
                 'name'     => 'inner_slider_background',
                 'label'    => esc_html__( 'Background', 'insut-essential' ),
                 'types'    => [ 'classic', 'gradient', 'video' ],
                 'selector' => '{{WRAPPER}} .hero-slider-two',
             ]
         );
     
         $this->add_responsive_control(
         'inner_slider_box_margin',
             [
                 'label'      => esc_html__( 'Margin', 'insut-essential' ),
                 'type'       => Controls_Manager::DIMENSIONS,
                 'size_units' => [ 'px','%'],
                 'selectors'  => [
                     '{{WRAPPER}} .hero-slider-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                 ],
             ]
         );

         $this->add_responsive_control(
            'inner_slider_box_padding',
             [
                 'label'      => esc_html__( 'Padding', 'insut-essential' ),
                 'type'       => Controls_Manager::DIMENSIONS,
                 'size_units' => [ 'px','%'],
                 'selectors'  => [
                     '{{WRAPPER}} .hero-slider-two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                 ],
             ]
         );

$this->end_controls_section();
      
    } //Register control end

    protected function render( ) { 

		$settings                  = $this->get_settings();
		$list                      = $settings['list'];
		
		$form_submit_text          = $settings['form_submit_text'];
		$form_action               = $settings['form_action'];
		$form_icon                 = $settings['form_icon'];
	
		
       
    
    ?>
        <!--====== BANNER PART START ======-->
    <?php if($settings['layout'] == 'style1'): ?>
    
        <!-- Slider Section Start -->
        <section class="slider-02 main-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-8">
                   
                        <div class="hero-slider-two owl-carousel">
                            <!-- Slider Item Start -->
                            <?php foreach($list as $item): ?>
                            <div class="hero-slider-two-item">
                                <div class="h-sub-title top-title"> <?php echo esc_html($item['list_sub_title']); ?> </div>
                               
                                <h2 class="title"> <?php echo esc_html($item['list_title']); ?></h2>
                              
                                <p class="content">
                                   <?php echo esc_html($item['list_content']); ?>
                                </p>

                                <a href="<?php echo esc_url($form_action) ?>" class="insut-btn">
                               
                                <?php if( $form_icon['value'] == '' ): ?>
                                     <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30"><g transform="translate(-376 -1655)" fill="#fff"><g transform="translate(93.356 1425.125)"><path class="a" d="M310.953,240.928a1.882,1.882,0,0,0-2.081,1.865l.015,4.492a3.914,3.914,0,0,1-1.156,2.626l-1.86,1.85a.972.972,0,0,1-1.369,0,.958.958,0,0,1,0-1.361l1.916-1.9a1.794,1.794,0,0,0,.191-2.388,1.751,1.751,0,0,0-2.586-.133l-3.771,3.748a4.486,4.486,0,0,0-1.326,3.182v2.271a.375.375,0,0,0,.378.375l7.746-.01a.377.377,0,0,0,.287-.133l4.237-4.984a4.485,4.485,0,0,0,1.069-2.9V242.9A1.952,1.952,0,0,0,310.953,240.928Zm-19.687,5.049a1.751,1.751,0,0,0-2.586.133,1.794,1.794,0,0,0,.191,2.388l1.916,1.9a.958.958,0,0,1,0,1.361.971.971,0,0,1-1.368,0l-1.861-1.85a3.914,3.914,0,0,1-1.156-2.626l.015-4.492a1.882,1.882,0,0,0-2.081-1.865,1.952,1.952,0,0,0-1.692,1.972v4.621a4.485,4.485,0,0,0,1.069,2.9l4.237,4.984a.377.377,0,0,0,.287.133l7.746.01a.375.375,0,0,0,.378-.375v-2.271a4.486,4.486,0,0,0-1.326-3.182Z"></path><path class="a" d="M306.848,257.625H299.1a.376.376,0,0,0-.377.375v1.5a.376.376,0,0,0,.377.375h7.747a.376.376,0,0,0,.377-.375V258A.376.376,0,0,0,306.848,257.625Zm-9.2-20.678a3.536,3.536,0,1,0-3.557-3.536A3.546,3.546,0,0,0,297.645,236.947Zm-5.16,6.8H302.8a.849.849,0,0,0,.818-.876v-.833a2.792,2.792,0,0,0-2.69-2.882h-6.575a2.792,2.792,0,0,0-2.69,2.882v.833A.849.849,0,0,0,292.485,243.75Zm3.7,13.875h-7.747a.376.376,0,0,0-.377.375v1.5a.376.376,0,0,0,.377.375h7.747a.376.376,0,0,0,.377-.375V258A.376.376,0,0,0,296.188,257.625Z"></path></g><path class="b" d="M392.457,1685a.377.377,0,0,1-.377-.375v-1.5a.377.377,0,0,1,.377-.375H400.2a.377.377,0,0,1,.377.375v1.5a.377.377,0,0,1-.377.375Zm-10.661,0a.377.377,0,0,1-.377-.375v-1.5a.377.377,0,0,1,.377-.375h7.747a.376.376,0,0,1,.377.375v1.5a.376.376,0,0,1-.377.375Zm10.862-4.321a.376.376,0,0,1-.376-.374v-2.272a4.487,4.487,0,0,1,1.326-3.182l3.771-3.749a1.751,1.751,0,0,1,2.587.133,1.794,1.794,0,0,1-.191,2.388l-1.916,1.9a.958.958,0,0,0,0,1.361.973.973,0,0,0,1.369,0l1.86-1.849a3.913,3.913,0,0,0,1.156-2.627l-.015-4.492a1.883,1.883,0,0,1,2.081-1.866,1.953,1.953,0,0,1,1.692,1.972v4.622a4.487,4.487,0,0,1-1.069,2.905l-4.237,4.984a.379.379,0,0,1-.288.133l-7.746.01Zm-3.317,0-7.746-.01a.38.38,0,0,1-.288-.133l-4.237-4.984a4.486,4.486,0,0,1-1.068-2.905v-4.622a1.952,1.952,0,0,1,1.691-1.972,1.882,1.882,0,0,1,2.081,1.866l-.015,4.492a3.918,3.918,0,0,0,1.156,2.627l1.86,1.849a.972.972,0,0,0,1.368,0,.958.958,0,0,0,0-1.361l-1.916-1.9a1.794,1.794,0,0,1-.191-2.388,1.751,1.751,0,0,1,2.587-.133l3.771,3.749a4.487,4.487,0,0,1,1.326,3.182v2.272a.376.376,0,0,1-.376.374Zm-3.5-11.8a.849.849,0,0,1-.818-.876v-.833a2.793,2.793,0,0,1,2.691-2.883h6.575a2.792,2.792,0,0,1,2.69,2.883V1668a.849.849,0,0,1-.818.876Zm1.6-10.339a3.557,3.557,0,1,1,3.557,3.536A3.546,3.546,0,0,1,387.443,1658.535Z"></path></g></svg>
                                <?php else: ?>   
                                    <?php \Elementor\Icons_Manager::render_icon( $form_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif; ?> 

                                <?php echo esc_html($form_submit_text); ?></a>
                            </div>
                            <!-- Slider Item End -->
                            <?php endforeach; ?>
                        </div>
                        <!-- Hero Slider End -->
                    </div>
                </div>
            </div>
        </section>  
        <!-- Slider Section End -->

    <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}