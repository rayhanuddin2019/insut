<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Call_to_Action extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-call-to-action';
    }

    public function get_title() {
        return esc_html__( 'Call To Action', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-video-camera";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
    public function layout(){
        return[
            
            'style1' => esc_html__( 'Style 1', 'insut-essential' ),
            'style2' => esc_html__( 'Video Popup Only', 'insut-essential' ),
            'style3' => esc_html__( 'Style 3', 'insut-essential' ),
      
        ];
    }
    protected function _register_controls() {
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );
            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_left_section_tab',
            [
                'label' => esc_html__('Left Image', 'insut-essential'),
                'condition' => [ 'style' => ['style3'] ],
            ]
        );
            $this->add_control(
                'image',
                [
                    'label' => esc_html__( 'Choose Image', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
        $this->end_controls_section();
        
        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Title settings', 'insut-essential'),
                
            ]
        );
      
                $this->add_control(
                    'title', [
                        'label'       => esc_html__( 'Title text', 'insut-essential' ),
                        'type'        => Controls_Manager::TEXTAREA,
                        'label_block' => true,
                        'placeholder' => esc_html__( 'Title here', 'insut-essential' ),
                        'default'     => esc_html__( ' Helps You Succeed', 'insut-essential' ),
                    ]
                );
  
 
                $this->add_control(
                'heading_type',
                    [
                        'label'   => esc_html__( 'Heading type', 'insut-essential' ),
                        'type'    => \Elementor\Controls_Manager::SELECT,
                        'default' => 'h2',
                        'options' => [
                            'h1' => esc_html__( 'H1', 'insut-essential' ),
                            'h2' => esc_html__( 'H2', 'insut-essential' ),
                            'h3' => esc_html__( 'H3', 'insut-essential' ),
                            'h4' => esc_html__( 'H4', 'insut-essential' ),
                            'h5' => esc_html__( 'H5', 'insut-essential' ),
                            'h6' => esc_html__( 'H6', 'insut-essential' ),
                            'p'  => esc_html__( 'P', 'insut-essential' ),
                        ],
                    ]
                );
                
                $this->add_responsive_control(
                    'title_align', [
                        'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                        'type'    => Controls_Manager::CHOOSE,
                        'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'insut-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                        'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'insut-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                                'title' => esc_html__( 'Right', 'insut-essential' ),
                                'icon'  => 'fa fa-align-right',
                        
                            ],
                    'justify'	 => [

                                'title' => esc_html__( 'Justified', 'insut-essential' ),
                                'icon'  => 'fa fa-align-justify',
                        
                            ],
                        ],
                    'default' => 'center',
                    
                        'selectors' => [
                            '{{WRAPPER}} .sec-title' => 'text-align: {{VALUE}};',
                            '{{WRAPPER}} .cta-content .title' => 'text-align: {{VALUE}};',

                        ],
                    ]
                );//Responsive control end

        $this->end_controls_section();
      
        $this->start_controls_section(
            'section_contact_tab',
            [
                'label' => esc_html__('Contact', 'insut-essential'),
            ]
        );
        $this->add_control(
            'contact_icon',
            [
                'label' => esc_html__( 'Contact Icon', 'insut-essential' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'contact_label', [
                'label'       => esc_html__( 'Label', 'insut-essential' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Have any problem?', 'insut-essential' ),
                'default'     => esc_html__( 'Have any problem?', 'insut-essential' ),
            ]
        );

        $this->add_control(
            'contact_value', [
                'label'       => esc_html__( 'Content', 'insut-essential' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( '+00 823 468 739', 'insut-essential' ),
                'default'     => esc_html__( '+00 823 468 739', 'insut-essential' ),
            ]
        );

        $this->add_control(
            'contact_button_label', [
                'label'       => esc_html__( 'Button Label', 'insut-essential' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Contact', 'insut-essential' ),
                'condition' => [ 'style' => ['style3'] ],
                'default'     => esc_html__( 'Contact', 'insut-essential' ),
            ]
        );

        $this->add_control(
            'contact_button_url', [
                'label'       => esc_html__( 'Button Url', 'insut-essential' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Contact', 'insut-essential' ),
                'default'     => esc_html__( 'Contact', 'insut-essential' ),
                'condition' => [ 'style' => ['style3'] ],
            ]
        );
           
        $this->add_responsive_control(
			'contcat_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .icon-box-02' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
        $this->start_controls_section(
            'contac_mid_cion_tab',
            [
                'label' => esc_html__('Mid Icon settings', 'insut-essential'),
                'condition' => [ 'style' => ['style3'] ],
            ]
        );

        $this->add_control(
			'contac_mid_enable',
			[
				'label'        => esc_html__( 'Show Title', 'insut-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'insut-essential' ),
				'label_off'    => esc_html__( 'Hide', 'insut-essential' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
        );
        
        $this->add_control(
            'mid_icon',
            [
                'label' => esc_html__( 'Icon', 'insut-essential' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_video_tab',
            [
                'label' => esc_html__('Video settings', 'insut-essential'),
                'condition' => [ 'style' => ['style1','style2'] ],
            ]
        );

            $this->add_control(
                'video_url', [
                    'label'       => esc_html__( 'Video Url', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video url here', 'insut-essential' ),
                    'default'     => 'https://www.youtube.com/embed/LXb3EKWsInQ',
                ]
            );

            $this->add_control(
                'video_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::ICONS,
                ]
            );

           
        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );
                $this->add_control(
                    'bold_text_heading1',
                    [
                        'label' => esc_html__( 'Normal Text', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'normal_title_color', [

                        'label'     => esc_html__( 'Normal Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'normal_title_typho',
                        'label'    => esc_html__( 'Normal Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title span',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

        
        $this->start_controls_section(
			'section_intro_desc_style', [
				'label' => esc_html__( 'Contact', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                  
                $this->add_control(
                    'contact_icons_color', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .icon-box-02 i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .call-info a i' => 'color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'contact_icon_typho_value',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .icon-box-02 i,{{WRAPPER}} .call-info a i',
                    ]
                );
                $this->add_responsive_control(
                    'icon__position_top',
                    [
                       'label'      => esc_html__( 'Top', 'insut-essential' ),
                       'type'       => Controls_Manager::SLIDER,
                       'size_units' => [ 'px' ],
                       'range'      => [
                          'px' => [
                             'min'  => -500,
                             'max'  => 500,
                             'step' => 1,
                          ],
                         
                       ],
                      
                       'selectors' => [
                          '{{WRAPPER}} .icon-box-02 i' => 'top: {{SIZE}}{{UNIT}};',
                         
                         
                       ],
                    ]
                 );

                 $this->add_responsive_control(
                    'icon__position_left',
                    [
                       'label'      => esc_html__( 'Left', 'insut-essential' ),
                       'type'       => Controls_Manager::SLIDER,
                       'size_units' => [ 'px' ],
                       'range'      => [
                          'px' => [
                             'min'  => -500,
                             'max'  => 500,
                             'step' => 1,
                          ],
                         
                       ],
                      
                       'selectors' => [
                          '{{WRAPPER}} .icon-box-02 i' => 'left: {{SIZE}}{{UNIT}};',
                         
                         
                       ],
                    ]
                 );
                $this->add_control(
                    'contact_label_color', [

                        'label'     => esc_html__( 'Label Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .icon-box-02 p' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .call-info h5 span' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'contact_label_typho_value',
                        'label'    => esc_html__( ' Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .icon-box-02 p ,{{WRAPPER}} .call-info h5 span',
                    ]
                );

                $this->add_responsive_control(
                    'contact_label_section_value_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .icon-box-02 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .call-info h5 span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'contact_label_section_value_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .icon-box-02 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .call-info h5 span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'conatc_value_color', [

                        'label'     => esc_html__( 'Content Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .icon-box-02 h5' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .call-info h5' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'conact_value_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .icon-box-02 h5,{{WRAPPER}} .call-info h5',
                    ]
                );
                $this->add_responsive_control(
                    'conatc_velie_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .icon-box-02 h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .call-info h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'contact_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .icon-box-02 h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .call-info h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('insut_contact_button_style_section',
            [
            'label' => esc_html__( 'Button', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'style' => ['style3','style4'] ],
            ]
        );
                $this->add_control(
                    'contact_button_label_color', [

                        'label'     => esc_html__( ' Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .insut-btn' => 'color: {{VALUE}};',
                    
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'contact_buttonl_typho_value',
                        'label'    => esc_html__( ' Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

                $this->add_responsive_control(
                    'contact_button_section_value_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                       'name'     => 'contact_button_background',
                       'label'    => esc_html__( 'Background', 'insut-essential' ),
                       'types'    => [ 'classic', 'gradient' ],
                       'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                 );
   
                 $this->add_control(
                    'contact_button_hover_background_heading',
                    [
                       'label'     => esc_html__( 'Hover background', 'insut-essential' ),
                       'type'      => \Elementor\Controls_Manager::HEADING,
                       'separator' => 'after',
                       
                    ]
                 );  

                 $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                       'name'     => 'contact_button_background_hover',
                       'label'    => esc_html__( 'Background', 'insut-essential' ),
                       'types'    => [ 'classic', 'gradient' ],
                       'selector' => '{{WRAPPER}} .insut-btn::after',
                    ]
                 );

                 $this->add_control(
                    'contact_button_background_',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .insut-btn' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .insut-btn::after' => 'border-radius: {{VALUE}}px;',
                               
                        ],
                    ]
                ); 

        $this->end_controls_section();

        $this->start_controls_section('appscred_icon_inner_main_section',
            [
            'label' => esc_html__( 'Video Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'style' => ['style2','style1'] ],
            ]
        );
                $this->add_control( 
                    'video_icon_color', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .popup-video i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .popup-video svg path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'video_icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .popup-video i',
                    ]
                );
                $this->add_responsive_control(
                    'video_icon_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .popup-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name' => 'video_icon_gradient_background',
                            'label' => esc_html__( 'Background', 'insut-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .popup-video',
                        ]
                );

                $this->add_control(
                    'video_iconhover_bg_heading1',
                    [
                        'label' => esc_html__( 'Hover', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                     
                    ]
                );
    
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name' => 'video_iconhover_gradient_background',
                            'label' => esc_html__( 'Background', 'insut-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .popup-video::after',
                        ]
                );

                $this->add_control(
                    'video_icon_borde_hv_rradius',
                        [
                            'label' => esc_html__( 'Hover Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .popup-video:after' => 'border-radius: {{VALUE}}px;',
                               
                        ],
                    ]
                ); 

                $this->add_control(
                    'video_icon_borde_rradius',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .popup-video' => 'border-radius: {{VALUE}}px;',
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'video__icon_section_border',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .calltoaction-wrapper:after',
                    ]
                );

        $this->end_controls_section();
            $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_control(
                '_section_box_radius',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 2000,
                        'step'  => 1,
                       
                        'selectors' => [
                            '{{WRAPPER}} .calltoaction-wrapper' => 'border-radius: {{VALUE}}px;',
                            '{{WRAPPER}} .calltoaction-area' => 'border-radius: {{VALUE}}px;',
                            
                    ],
                ]
            );

           

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'section_item_content_section_border',
                    'label' => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .calltoaction-wrapper,{{WRAPPER}} .calltoaction-area',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_gradient_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .calltoaction-wrapper,{{WRAPPER}} .calltoaction-area',
                    ]
            );

            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .calltoaction-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .calltoaction-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .calltoaction-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .calltoaction-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );

            
            $this->add_control(
                'section_left_bg_heading1',
                [
                    'label' => esc_html__( 'Left Section', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'style' => ['style1'] ], 
                ]
            );

            $this->add_control(
                '_section_box_radius_left',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 2000,
                        'step'  => 1,
                       
                        'selectors' => [
                            '{{WRAPPER}} .calltoaction-wrapper:before' => 'border-radius: {{VALUE}}px;',
                            
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_sec_gradient_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .calltoaction-wrapper:before',
                    ]
            );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		$title     = $settings['title'];
	    $title_1   = str_replace(['{', '}'], ['<span>', '</span>'], $title);
       
    ?>
           
        <?php if($settings['style'] == 'style1'): ?>  
             
            <div class="calltoaction-wrapper">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <<?php echo esc_attr($settings['heading_type']); ?> class="sec-title title"> <?php echo insut_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="icon-box-02">

                            <?php if( $settings['contact_icon']['value'] == '' ): ?>
                                <i class="insut-Icon10"></i>
                             <?php else: ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                            <?php if( $settings['contact_label'] !='' ): ?>
                               <p> <?php echo esc_html( $settings['contact_label'] ); ?> </p>
                            <?php endif; ?>
                            <?php if( $settings['contact_value'] !='' ): ?>
                               <h5> <?php echo esc_html($settings['contact_value']); ?></h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!-- Video BTN -->
                <a class="popup-video" data-rel="lightcase" href="<?php echo esc_url($settings['video_url']); ?>">
                    <?php if( $settings['video_icon']['value'] == '' ): ?>
                        <i class="fa fa-play"></i>
                        <?php else: ?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>
                </a>
                
            </div>
  
       <?php endif; ?>
       <?php if($settings['style'] == 'style2'): ?>   
        <div class="calltoaction-wrapper">
                 <!-- Video BTN -->
                <a class="popup-video" data-rel="lightcase" href="<?php echo esc_url($settings['video_url']); ?>">
                    <?php if( $settings['video_icon']['value'] == '' ): ?>
                        <i class="fa fa-play"></i>
                        <?php else: ?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>
                </a>
                
            </div>
       <?php endif; ?>
       <?php if($settings['style'] == 'style3'): ?>  

        <div class="calltoaction-area">
            <div class="row">
                <div class="col-lg-6 col-md-12 noPaddingRight">
                    <?php if($settings['image']['url'] !=''): ?>
                        <img class="member-img" src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                    <?php endif; ?>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="cta-content">
                    <<?php echo esc_attr($settings['heading_type']); ?> class="title"> <?php echo insut_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                        <div class="call-info">
                            <a href="<?php echo esc_url($settings['contact_button_url']); ?>" class="insut-btn">
                                
                                <?php if( $settings['contact_icon']['value'] == '' ): ?>
                                    <i class="icofont-home">
                                <?php else: ?>
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif; ?>
                            </i> <?php echo esc_html($settings['contact_button_label']); ?> </a>
                            <h5><span><?php echo esc_html( $settings['contact_label'] ); ?></span>
                            
                            <?php if( $settings['contact_value'] !='' ): ?>
                               <?php echo esc_html($settings['contact_value']); ?>
                            <?php endif; ?>
                           </h5>
                            
                        </div>
                    </div>
                </div>
            </div>
               <?php if($settings['contac_mid_enable'] == 'yes'): ?>
                    <!-- Middle Icon -->
                    <div class="find-icon">
                    
                        <?php if( $settings['mid_icon']['value'] == '' ): ?>
                        <i class="icofont-globe"></i>
                            <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['mid_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <?php endif; ?>
                </div>
               <?php endif; ?>
        </div>

       <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}