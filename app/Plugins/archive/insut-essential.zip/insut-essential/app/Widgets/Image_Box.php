<?php
namespace InsutEssential\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class Image_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-image-boxs';
    }

    public function get_title() {
        return esc_html__( 'Image Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-file-image-o";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
        
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

            'block_style', [
                'label'   => esc_html__('Choose Style', 'insut-essential'),
                'type'    => Custom_Controls_Manager::RADIOIMAGE,
                'default' => 'style1',
                'options' => [
                        'style1' => [
                                'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                                'imagelarge' => INSUT_IMG . '/image-box/style-1.png',
                                'imagesmall' => INSUT_IMG . '/image-box/style-1.png',
                                'width'      => '100%',
                        ],

                       

            ],

            ]
        ); 

       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Image Box settings', 'insut-essential'),
            ]
        );
      
        $this->add_control(
			'image1',
			[
				'label' => esc_html__( 'Choose Image one', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'image_thumb',
			[
				'label' => esc_html__( 'Choose Thumb Image', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
			'animated_section_shape_image_style', [
				'label' => esc_html__( 'Animated Shape Image', 'insut-essential' ),
			    'condition' => [ 'block_style' => ['style2'] ],
			]
        );
           
            $this->add_control(
                'shape_1',
                [
                    'label' => esc_html__( 'Choose Shape Image', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
            $this->add_control(
                'shape_2',
                [
                    'label' => esc_html__( 'Choose Shape Image', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
            $this->add_control(
                'shape_3',
                [
                    'label' => esc_html__( 'Choose Shape Image', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );


            $this->add_responsive_control(
                'shape_align', [
                    'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
    
                   'left'		 => [
                      
                      'title' => esc_html__( 'Left', 'insut-essential' ),
                      'icon'  => 'fa fa-align-left',
                   
                   ],
                    'center'	     => [
                      
                      'title' => esc_html__( 'Center', 'insut-essential' ),
                      'icon'  => 'fa fa-align-center',
                   
                   ],
                   'right'	 => [
    
                            'title' => esc_html__( 'Right', 'insut-essential' ),
                            'icon'  => 'fa fa-align-right',
                      
                    ],
                    'justify'	 => [
    
                            'title' => esc_html__( 'Justified', 'insut-essential' ),
                            'icon'  => 'fa fa-align-justify',
                      
                        ],
                    ],
                    'default' => 'center',
                    'selectors' => [
                         '{{WRAPPER}} .advertiser-thumb'   => 'text-align: {{VALUE}};',
                      
                     
                    
                    ],
                ]
            );//Responsive control end
        $this->end_controls_section();
  
        //Image Style Section
		$this->start_controls_section(
			'section_image_style', [
				'label' => esc_html__( 'Image one', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
    
               
                $this->add_responsive_control(
                    'section_thumb_image_radius',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                        
                            'selectors' => [
                                '{{WRAPPER}} .big-img' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 

                $this->add_responsive_control(
                    'image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .big-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'image_section_padding',
                    [
                        'label'      => esc_html__( 'padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .big-img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'augmented_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'condition' => [ 'block_style' => ['style3'] ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .augmentation-area .augmentation-thumb' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'augmented_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'condition' => [ 'block_style' => ['style3'] ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .augmentation-area .augmentation-thumb' => 'left: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );
                $this->add_responsive_control(
                    'input_box_width',
                    [
                        'label'      => esc_html__( 'Width', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'condition' => [ 'block_style' => ['style3'] ],
                        'size_units' => [ 'px', '%' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0,
                                'max'  => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                      
                        'selectors' => [
                            '{{WRAPPER}} .augmentation-area .augmentation-thumb'   => 'width:{{SIZE}}{{UNIT}};',
                           
                        ],
                    ]
                );
        $this->end_controls_section();

         //Image Style Section
		$this->start_controls_section(
			'section_thumb_image_style', [
				'label' => esc_html__( 'Thumb Image', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style1'] ],
			]
        );

              
                $this->add_responsive_control(
                    'thumb_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-thumb-7 .thumb' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .big-img' => 'top: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'thumb_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-thumb-7 .thumb' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .big-img' => 'left: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'thumb_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-thumb-7 .thumb' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .big-img' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
              

                $this->add_responsive_control(
                    'thumb_image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .about-thumb-7 .thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .big-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'thumb_image_radius',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .about-thumb-7 .thumb img' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .advertiser-item .advertiser-thumb .big-img' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 
    

        $this->end_controls_section();

        $this->start_controls_section(
			'section_shape_image_style', [
				'label' => esc_html__( 'Shape Image', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

              
                $this->add_responsive_control(
                    'shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-7-area .about-thumb-7::before' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .thumb' => 'top: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .augmentation-area .augmentation-shape' => 'top: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-7-area .about-thumb-7::before' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .thumb' => 'left: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .augmentation-area .augmentation-shape' => 'left: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .about-7-area .about-thumb-7::before' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .thumb' => 'bottom: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .augmentation-area .augmentation-shape' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
               
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shapebackground',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'condition' => [ 'block_style' => ['style1','style2'] ],
                        'selector' => '{{WRAPPER}} .about-7-area .about-thumb-7::before',
                    ]
                );

                $this->add_responsive_control(
                    'shape_imageopacity',
                        [
                            'label' => esc_html__( 'Opacity', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 1,
                            'step'  => 0.1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .about-7-area .about-thumb-7::before' => 'opacity: {{VALUE}};',
                                '{{WRAPPER}} .advertiser-item .advertiser-thumb .thumb' => 'opacity: {{VALUE}};',
                                '{{WRAPPER}} .augmentation-area .augmentation-shape' => 'opacity: {{VALUE}};',
                        ],
                    ]
                ); 
    

        $this->end_controls_section();
        $this->start_controls_section(
			'animated_round_shape_image_style', [
				'label' => esc_html__( 'Round Shape', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

                $this->add_control(
                    'round_shape',
                    [
                        'label' => esc_html__( 'Show', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'Show', 'insut-essential' ),
                        'label_off' => esc_html__( 'Hide', 'insut-essential' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                    ]
                );
              
                $this->add_responsive_control(
                    'round_one_shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .round-shape' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'round_shape_one_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .round-shape' => 'left: {{SIZE}}{{UNIT}};',

                        ],
                    ]
                );

                $this->add_responsive_control(
                    'round_shape_one_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                           
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .round-shape' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
               
 
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name' => 'round_shape__gradient_background',
                            'label' => esc_html__( 'Background', 'insut-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .round-shape',
                          
                           
                        ]
                );

                $this->add_responsive_control(
                    'round_shapes_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .round-shape' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();
        $this->start_controls_section(
			'animated_s_shape_image_style', [
				'label' => esc_html__( 'Animated Shape One', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

              
                $this->add_responsive_control(
                    'animated_one_shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_one_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape' => 'left: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_one_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                           
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
               
 

        $this->end_controls_section();

        $this->start_controls_section(
			'animated_two_section_shape_image_style', [
				'label' => esc_html__( 'Animated Shape Two', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

              
                $this->add_responsive_control(
                    'animated_two_shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-1' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_two_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-1' => 'left: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_two_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-1' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
               
 

        $this->end_controls_section();

        $this->start_controls_section(
			'animated_three_section_shape_image_style', [
				'label' => esc_html__( 'Animated Shape three', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

              
                $this->add_responsive_control(
                    'animated_three_shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-2' => 'top: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_three_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-2' => 'left: {{SIZE}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'animated_shape_three_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                           
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb .advertiser-bg-shape .advertiser-shape-2' => 'bottom: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
               
 

        $this->end_controls_section();
 
 
 
 
        $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Inner Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style2','style1'] ],
                ]
            );

          
                $this->add_responsive_control(
                    'box_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .about-thumb-7' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                
                $this->add_responsive_control(
                    'box_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .about-thumb-7' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .advertiser-item .advertiser-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        
        $this->start_controls_section('appscred__main_section',
                [
                'label' => esc_html__( 'Main Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

          
                $this->add_responsive_control(
                    'main_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .about-7-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'main_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .about-7-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_section_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .about-7-area,{{WRAPPER}} .main-section',
                    ]
                );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		
     
    ?>
        <?php if( $settings['block_style'] =='style1' ): ?> 

            <div class="about-7-area main-section">
                <div class="about-thumb-7">
                    <?php if($settings['image1']['url'] !=''): ?>
                       <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                    <?php endif; ?>
                    <?php if($settings['image_thumb']['url'] !=''): ?> 
                        <div class="thumb">
                            <img src="<?php echo esc_url($settings['image_thumb']['url']); ?>" alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                        </div>
                    <?php endif; ?>
                </div> <!-- about thumb 7 -->
            </div> <!-- main -->

        <?php endif; ?>
        <?php if( $settings['block_style'] =='style2' ): ?> 
                    <div class="advertiser-item main-section">
                        <div class="advertiser-thumb">
                             <?php if($settings['image_thumb']['url'] !=''): ?>
                                <img class="big-img" src=" <?php echo esc_url($settings['image_thumb']['url']); ?> " alt="<?php echo esc_attr__('advertiser ','insut-essential'); ?>">
                            <?php endif; ?>
                            <?php if($settings['image1']['url'] !=''): ?> 
                                <div class="thumb">
                                    <img src="<?php echo esc_url($settings['image1']['url']); ?>" alt="<?php echo esc_attr__('advertiser thumb','insut-essential'); ?>">
                                </div>
                            <?php endif; ?>
                            <div class="advertiser-bg-shape">
                                <?php if($settings['shape_1']['url'] !=''): ?>
                                    <img class="shape-1" src=" <?php echo esc_url($settings['shape_1']['url']); ?> " alt="<?php echo esc_attr__('advertiser ','insut-essential'); ?>">
                                <?php endif; ?>
                                <?php if($settings['round_shape'] =='yes'): ?>  
                                    <div class="round-shape"></div>
                                <?php endif; ?>
                                
                                <?php if($settings['shape_2']['url'] !=''): ?>
                                    <div class="advertiser-shape-1">
                                        <img class="shape-2" src=" <?php echo esc_url($settings['shape_2']['url']); ?> " alt="<?php echo esc_attr__('advertiser ','insut-essential'); ?>">
                                    </div>
                                <?php endif; ?>
                                <?php if($settings['shape_3']['url'] !=''): ?>
                                    <div class="advertiser-shape-2">
                                        <img class="shape-3" src=" <?php echo esc_url($settings['shape_3']['url']); ?> " alt="<?php echo esc_attr__('advertiser ','insut-essential'); ?>">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div> <!-- advertiser thumb -->
                    </div>    
         <?php endif; ?>
         <?php if( $settings['block_style'] =='style3' ): ?> 
                    <div class="augmentation-area main-section">
                        <?php if($settings['image1']['url'] !=''): ?>
                            <div class="augmentation-shape">
                               <img src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                            </div>
                        <?php endif; ?>
                        <?php if($settings['image_thumb']['url'] !=''): ?> 
                            <div class="augmentation-thumb">
                                <img class="big-img" src="<?php echo esc_url($settings['image_thumb']['url']); ?>" alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
         <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}