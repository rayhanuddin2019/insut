<?php
namespace AppscredEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Service_Box extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appscred-service-box';
    }

    public function get_title() {
        return esc_html__( 'Service Box', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'appscred-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'insut-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                    'imagelarge' => INSUT_IMG . '/service-box/style-1.png',
                    'imagesmall' => INSUT_IMG . '/service-box/style-1.png',
                    'width'      => '100%',
               ],

              
            
         
         
           ],

         ]
       ); 
       $this->end_controls_section();
       $this->start_controls_section(
            'section_heading_tab',
            [
                'label' => esc_html__('Service Heading', 'insut-essential'),
                'condition' => [ 'block_style' => ['style2','style3','style4'] ],
            ]
        );
        $this->add_control(
			'show_heading',
			[
				'label' => esc_html__( 'Show Heading', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insut-essential' ),
				'label_off' => esc_html__( 'Hide', 'insut-essential' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
			'top_title', [
				'label'       => esc_html__( 'Top Title', 'insut-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Get in ', 'insut-essential' ),
				'default'     => esc_html__( 'Service We Offer ', 'insut-essential' ),
                'condition' => [ 'block_style' => ['style2','style4'] ],
				
			]
        ); 
        $this->add_control(
			'title', [
				'label'       => esc_html__( 'Title text', 'insut-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Get in ', 'insut-essential' ),
				'default'     => esc_html__( 'Get Best {Advertiser} In Your Side Pocket ', 'insut-essential' ),
               
				
			]
        );
        $this->add_control(
			'header_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
                'condition' => [ 'block_style' => ['style3'] ],
			]
        );
        
        $this->add_responsive_control(
			'heading_title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
				],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
                'default' => 'center',
                'selectors' => [
                     '{{WRAPPER}} .section-title'   => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .section-title-4' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .section-title-5' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .services-7-title' => 'text-align: {{VALUE}};',
                 
                
				],
			]
        );//Responsive control end

        $this->add_control(
            'heading_type',
                [
                    'label'   => esc_html__( 'Heading type', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'h3',
                    'options' => [
                        'h1' => esc_html__( 'H1', 'insut-essential' ),
                        'h2' => esc_html__( 'H2', 'insut-essential' ),
                        'h3' => esc_html__( 'H3', 'insut-essential' ),
                        'h4' => esc_html__( 'H4', 'insut-essential' ),
                        'h5' => esc_html__( 'H5', 'insut-essential' ),
                        'h6' => esc_html__( 'H6', 'insut-essential' ),
                        'p'  => esc_html__( 'P', 'insut-essential' ),
                    ],
                ]
            );
       $this->end_controls_section();



        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Service settings', 'insut-essential'),
            ]
        );
       
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);
     
		$repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( 'List Content' , 'insut-essential' ),
				'show_label' => false,
			]
		);

        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );

        $repeater->add_control(
			'list_readmore', [
				'label'      => esc_html__( 'Readmore text', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( 'View More' , 'insut-essential' ),
				
			]
        );
        
        $repeater->add_control(
			'list_url', [
				'label'      => esc_html__( 'Url', 'insut-essential' ),
				'type'       => \Elementor\Controls_Manager::URL,
				
			
			]
        );
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Service List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
   
     
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'left',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .sevices-item' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .services-7-item' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end

        $this->end_controls_section();
      

        $this->start_controls_section(
            'section_overlay_tab',
            [
                'label' => esc_html__('Overlay Image settings', 'insut-essential'),
                'condition' => [ 'block_style' => ['style1','style2','style4'] ],
            ]
        );

            $overlay_shape = new \Elementor\Repeater();

            $overlay_shape->add_control(
                'shape',
                [
                    'label' => esc_html__( 'Choose shape', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::MEDIA,
                ]
            );
            
            $overlay_shape->add_control(
                'list_title', [
                    'label'       => esc_html__( 'Title', 'insut-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'List Title' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );

            $overlay_shape->add_responsive_control(
                'overlay_heading_border_line_pos_top',
                [
                    'label' => esc_html__( 'Position Top', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );

            $overlay_shape->add_responsive_control(
                'overlay_heading_border_line_pos_left',
                [
                    'label' => esc_html__( 'Position left', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );

            $overlay_shape->add_responsive_control(
                'overlay_heading_border_line_pos_right',
                [
                    'label' => esc_html__( 'Position right', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'right: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );

            $overlay_shape->add_responsive_control(
                'overlay_heading_border_line_pos_bottom',
                [
                    'label' => esc_html__( 'Position bottom', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'bottom: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );
   
            
            $this->add_control(
                'shape_list',
                [
                    'label'     => esc_html__( 'Shape List', 'insut-essential' ),
                    'type'      => \Elementor\Controls_Manager::REPEATER,
                    'fields'    => $overlay_shape->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                ]
            );

        $this->end_controls_section();
  
        //Title Style Section
	
        $this->start_controls_section(
			'heading_section_top_title_style', [
				'label' => esc_html__( 'Heading Top Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
        $this->add_control(
			'heading__left_border_color', [

				'label'		 => esc_html__( 'Left line color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title-4 > span::before' => 'background: {{VALUE}};',
                 
                ],
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

        $this->add_control(
			'heading_right_border_color', [

				'label'		 => esc_html__( 'Right line color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title-4 > span::after' => 'background: {{VALUE}};',
                 
                ],
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

        $this->add_responsive_control(
			'heading_border_line_pos',
			[
				'label' => esc_html__( 'Line Top Position', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-4 > span::before' => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-title-4 > span::after' => 'top: {{SIZE}}{{UNIT}};',
					
                ],
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );

        $this->add_responsive_control(
			'heading_border_line_gap',
			[
				'label' => esc_html__( 'Line text Gap', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-4 > span::before' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-title-4 > span::after' => 'right: {{SIZE}}{{UNIT}};',
					
                ],
                'condition' => [ 'block_style' => ['style2'] ],
			]
        );
       
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'heading_top_title_border',
				'label' => esc_html__( 'Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .top-title,{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title',
               
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'heading_top_title_gradient_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .top-title,{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title',
                  
                   
                ]
        );

        $this->add_control(
			'heading_top_title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .top-title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .top-title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .top-title' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_top_title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .top-title,{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title',
            ]
        );
        $this->add_responsive_control(
            'heading_top_title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'heading_top_title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

       
        $this->end_controls_section();

        
        $this->start_controls_section(
			'heading_section_title_style', [
				'label' => esc_html__( 'Heading Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

       
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'heading_border',
				'label' => esc_html__( 'Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .services-7-title .title,{{WRAPPER}} .section-title-5 .title,{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title',
               
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'heading_gradient_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .services-7-title .title,{{WRAPPER}} .section-title-5 .title,{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title',
                  
                   
                ]
        );

        $this->add_control(
			'heading_title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-5 .title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .services-7-title .title' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .services-7-title .title,{{WRAPPER}} .section-title-5 .title,{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title',
               
            ]
        );
        $this->add_control(
            'heading_bold_text_heading1',
            [
                'label' => esc_html__( 'Normal Text', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
			'heading_bold_text_title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .title span' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .title span' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-5 .title span' => 'color: {{VALUE}};',
                  '{{WRAPPER}}  .services-7-title .title span' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_bold_text_title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .services-7-title .title span,{{WRAPPER}} .section-title-5 .title span,{{WRAPPER}} .section-title .title span,{{WRAPPER}} .section-title-4 .title span',
            
            ]
        );

        $this->add_responsive_control(
            'heading_title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title-4 .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-5 .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .services-7-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'heading_title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-5 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .services-7-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

       
        $this->end_controls_section();
        $this->start_controls_section(
			'heading_section__icon_style', [
				'label' => esc_html__( 'Heading Icon', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'block_style' => ['style3'] ],
			]
        );
        $this->add_control(
            'heading_icon_color_background', [

                'label'     => esc_html__( 'Icon background shape color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                
                'selectors' => [
                '{{WRAPPER}} .section-title-5 .icon ' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'heading_box_icon_color', [

                'label'     => esc_html__( 'Box Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .section-title-5 .icon svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .section-title-5 .icon i' => 'color: {{VALUE}};',
              
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_box_icons_typhography',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .section-title-5 .icon i,{{WRAPPER}} .section-title-5 .icon svg',
               
            ]
        );
        $this->add_responsive_control(
            'icon__box_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .section-title-5 .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
			'heading_box_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-5 .icon' => 'width: {{SIZE}}{{UNIT}};',
		
					
				],
			]
        );

        $this->add_responsive_control(
			'heading_box_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-5 .icon' => 'height: {{SIZE}}{{UNIT}};',
			
					
				],
			]
        );

        $this->end_controls_section();


        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Title color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .service-title' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .service-title',
            ]
        );
        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'section_desc_style', [
				'label' => esc_html__( 'Description', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'desc_color', [

				'label'     => esc_html__( 'Desc color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .service-desc' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .service-desc',
            ]
        );

        $this->add_responsive_control(
            'desc_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'desc_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section('box_overlay_section',
                [
                    'label' => esc_html__( 'Box overlay', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                    'condition' => [ 'block_style' => ['style1','style2'] ],
                ]
        );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                'name'     => 'view_readmore_overlay_background',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .sevices-item::before , {{WRAPPER}} .our-sevices-item::before',
                ]
            );
         
        $this->end_controls_section();
        
        $this->start_controls_section('box_view_more_section',
                [
                    'label' => esc_html__( 'View More', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                    'condition' => [ 'block_style' => ['style2'] ],
                ]
        );

        $this->add_control(
			'view_more_color', [

				'label'     => esc_html__( 'Color', 'insut-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .view-more' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'view_more_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .view-more',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name'     => 'hover_overlay_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .view-more',
            ]
         );

        $this->add_responsive_control(
            'view_more_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .view-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'view_more_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .view-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'insut-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control('box_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  
                    '{{WRAPPER}} .sevices-item ' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .our-sevices-item ' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .services-5-item ' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .services-7-item::before' => 'background: {{VALUE}};',
                            
                    ],
                ]
            );

            $this->add_control(
                'box_hv_background_heading1',
                [
                    'label' => esc_html__( 'Background Hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'block_style' => ['style4'] ],
                ]
            );
            $this->add_control('box_hv_background_color',
            [
                'label'     => esc_html__( 'Background color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style4'] ],
                'selectors' => [
                      '{{WRAPPER}} .services-7-item' => 'background: {{VALUE}};',
                            
                    ],
                ]
               
            );
            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'     => 'box_border',
                    'label'    => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .services-7-item, {{WRAPPER}} .sevices-item,{{WRAPPER}} .our-sevices-item,{{WRAPPER}} .services-5-item',
                ]
            );


            $this->add_responsive_control(
                '_box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .sevices-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .our-sevices-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .services-5-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} .services-7-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                       
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        
                        '{{WRAPPER}} .sevices-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .our-sevices-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-5-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-7-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );

            $this->add_responsive_control(
                'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .sevices-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .our-sevices-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .services-5-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .services-7-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
            );


        $this->end_controls_section();
        // main section
        $this->start_controls_section('appscred_box__main_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
         $this->add_group_control(
           \Elementor\Group_Control_Background::get_type(),
           [
              'name'     => 'main_section_background',
              'label'    => esc_html__( 'Background', 'insut-essential' ),
              'types'    => [ 'classic', 'gradient', 'video' ],
              'selector' => '{{WRAPPER}} .services-7-area.style4::before , {{WRAPPER}} .style3.main-section .services-bg ,{{WRAPPER}} .style1.main-section,{{WRAPPER}} .style2.main-section .our-services-bg',
           ]
        );
       
       $this->add_responsive_control(
        'main_box_margin',
           [
              'label'      => esc_html__( 'Margin', 'insut-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .style1.main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .style2.main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .style3.main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .services-7-area.style4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
              ],
           ]
        );

        $this->add_responsive_control(
           'main_box_padding',
           [
              'label'      => esc_html__( 'Padding', 'insut-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .style1.main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .style2.main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .style3.main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .services-7-area.style4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
              ],
           ]
        );

     $this->end_controls_section();

     $this->start_controls_section('appscred_box_media_section',
        [
        'label' => esc_html__( 'Media', 'insut-essential' ),
        'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'icon_color_background', [

                'label'     => esc_html__( 'Icon background shape color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'block_style' => ['style2','style4'] ],
                'selectors' => [
                '{{WRAPPER}} .our-sevices-item .icon::before ' => 'background: {{VALUE}};',
                '{{WRAPPER}} .services-7-item .icon ' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'box_icon_color', [

                'label'     => esc_html__( 'Box Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .our-sevices-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .sevices-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .services-5-item svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .services-7-item .icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
			'box_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .our-sevices-item svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .sevices-item svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .services-5-item svg' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .services-7-item .icon svg' => 'width: {{SIZE}}{{UNIT}};',
					
				],
			]
        );

        $this->add_responsive_control(
			'box_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .sevices-item svg' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .our-sevices-item svg' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .services-5-item svg' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .services-7-item .icon svg' => 'height: {{SIZE}}{{UNIT}};',
					
				],
			]
        );

        $this->add_responsive_control(
            'media_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .sevices-item svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .our-sevices-item svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-5-item svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-7-item .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                      
                        
                    ],
                ]
            );

            $this->add_responsive_control(
            'media_box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .our-sevices-item svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .sevices-item svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-5-item svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .services-7-item .icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );
    $this->end_controls_section();

    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
		$title        = $settings['title'];
		$title_1      = str_replace(['{', '}'], ['<span>', '</span>'], $title);
       
    ?>
   
     <?php if( $settings['block_style'] == 'style1' ): ?>
        <div class="row justify-content-center main-section style1">
                <?php foreach($settings['list'] as $item):  ?>
                    <div class="col-lg-4 col-md-6 col-sm-9">
                        <div class="sevices-item mt-30">
                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <h4 class="title service-title"><?php echo esc_html($item['list_title']); ?></h4>
                            <p class="service-desc"><?php echo esc_html($item['list_content']); ?></p>
                           <?php foreach($settings['shape_list'] as $key => $shape): ?>
                                <div class="services-overlay-<?php echo esc_attr(++$key); ?> elementor-repeater-item-<?php echo esc_attr( $shape['_id'] ) ?>">
                                    <img src="<?php echo esc_url($shape['shape']['url']); ?>" alt="<?php echo esc_attr__($shape['list_title']); ?>">
                                </div>
                                <?php if($key==3){
                                    break;
                                } ?>
                           <?php endforeach; ?> 
                        </div> <!-- services item -->
                    </div>
                <?php endforeach; ?>
            </div> <!-- row -->
      <?php endif; ?>
     
      <?php if( $settings['block_style'] == 'style2' ): ?>
          

          <!--====== OUR SERVICES PART START ======-->

           <section class="our-services-area style2 main-section">
               <div class="our-services-bg"></div>
               <div class="container">
                   <?php if($settings['show_heading'] =='yes'): ?>
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-9">
                            <div class="section-title-4">
                                <span class="top-title"><?php echo appscred_kses($settings['top_title']); ?></span>
                                <<?php echo esc_attr($settings['heading_type']); ?> class="title"><?php echo appscred_kses($title_1); ?></<?php echo esc_attr($settings['heading_type']); ?>>
                            </div> <!-- section title 4 -->
                        </div>
                    </div> <!-- row -->
                   <?php endif; ?>
                   <div class="row justify-content-center">
                   
                       <?php foreach($settings['list'] as $item):  ?>
                           <div class="col-lg-4 col-md-6 col-sm-9">
                               <div class="our-sevices-item mt-30">
                                   <div class="icon">
                                      <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                   </div>
                                   
                                   <h4 class="title service-title"><?php echo esc_html($item['list_title']); ?></h4>
                                   <p class="service-desc"><?php echo esc_html($item['list_content']); ?></p>
                                   <a target="<?php echo esc_attr( $item['list_url']['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($item['list_url']['url']) ?>" class="view-more">
                                            <?php echo esc_html( $item['list_readmore'] ); ?>
                                    </a>
                                    <?php foreach($settings['shape_list'] as $key => $shape): ?>
                                            <div class="elementor-repeater-item-<?php echo esc_attr( $shape['_id'] ) ?> serices-shape<?php echo esc_attr(++$key>1?'-'.$key:''); ?>">
                                                <img src="<?php echo esc_url($shape['shape']['url']); ?>" alt="<?php echo esc_attr__($shape['list_title']); ?>">
                                            </div>
                                            <?php 
                                                break;
                                            ?>
                                    <?php endforeach; ?> 

                               </div> <!-- services item -->
                           </div>
                       <?php endforeach; ?>
                       
                   </div> <!-- row -->
               </div>  
           </section>

           <!--====== OUR SERVICES PART ENDS ======-->

 
     <?php endif; ?>
     <?php if( $settings['block_style'] == 'style3' ): ?>
        <!--====== SERVICES 5 PART START ======-->

            <section class="services-5-area style3 main-section">
                <div class="services-bg"></div>
                <div class="container">
                    <?php if($settings['show_heading'] =='yes'): ?>
                       <div class="row justify-content-center">
                            <div class="col-lg-7 ">
                                <div class="section-title-5 text-center">
                                    <div class="icon">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['header_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                    <<?php echo esc_attr($settings['heading_type']); ?> class="title"><?php echo appscred_kses($title_1); ?></<?php echo esc_attr($settings['heading_type']); ?>>
                                </div>
                            </div>
                        </div> <!-- row -->
                    <?php endif; ?>
                    <div class="row">
                        <?php foreach($settings['list'] as $item):  ?>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="services-5-item mt-30">
                                    <div class="icon">
                                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                    <h4 class="title service-title"><?php echo esc_html($item['list_title']); ?></h4>
                                   <p class="service-desc"><?php echo esc_html($item['list_content']); ?></p>
                                </div> <!-- services-5-item -->
                            </div>
                        <?php endforeach; ?> 
                    </div> <!-- row -->
                </div>
            </section>

            <!--====== SERVICES 5 PART ENDS ======-->
     <?php endif; ?>
     <?php if( $settings['block_style'] == 'style4' ): ?>

        <section class="services-7-area style4">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-12 col-sm-8">
                        <div class="services-7-title mt-100">
                            <span class="top-title"><?php echo appscred_kses($settings['top_title']); ?></span>
                            <<?php echo esc_attr($settings['heading_type']); ?> class="title"><?php echo appscred_kses($title_1); ?></<?php echo esc_attr($settings['heading_type']); ?>>
                        </div>
                        <?php foreach($settings['list'] as $item):  ?>
                            <div class="services-7-item item-1 mt-30">
                                <?php  foreach($settings['shape_list'] as $key => $shape): ?> 
                                    <div class="services-shape<?php echo esc_attr(++$key>1?'-'.$key:''); ?> elementor-repeater-item-<?php echo esc_attr( $shape['_id'] ) ?>">
                                        <img src="<?php echo esc_url($shape['shape']['url']); ?>" alt="<?php echo esc_attr__($shape['list_title']); ?>">
                                    </div>
                                    <?php if($key == 3){
                                        break;
                                    } ?>
                                <?php endforeach; ?> 
                                <div class="icon">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </div>
                                <h4 class="title service-title"> <?php echo esc_html($item['list_title']); ?> </h4>
                                <p class="service-desc"><?php echo esc_html($item['list_content']); ?></p>
                            </div>
                           <?php 

                               break;
                               
                            ?>
                        <?php endforeach; ?> 
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-8">
                        <?php foreach($settings['list'] as $itemkey => $item):  ?>
                             <?php if($itemkey == 1 || $itemkey == 2 ): ?>
                                    <div class="services-7-item <?php echo esc_attr($itemkey==1?'mt-100':'mt-30'); ?>">
                                        <?php  foreach($settings['shape_list'] as $key => $shape): ?> 
                                            <div class="services-shape<?php echo esc_attr(++$key>1?'-'.$key:''); ?> elementor-repeater-item-<?php echo esc_attr( $shape['_id'] ) ?>">
                                                <img src="<?php echo esc_url($shape['shape']['url']); ?>" alt="<?php echo esc_attr__($shape['list_title']); ?>">
                                            </div>
                                            <?php if($key == 3){
                                                break;
                                            } ?>
                                        <?php endforeach; ?> 
                                        <div class="icon">
                                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </div>
                                        <h4 class="title service-title"> <?php echo esc_html($item['list_title']); ?> </h4>
                                        <p class="service-desc"> <?php echo esc_html($item['list_content']); ?></p>
                                    </div>
                            <?php endif; ?>    
                        <?php endforeach; ?> 
                      
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-8">
                    <?php foreach($settings['list'] as $itemkey => $item):  ?>
                             <?php if($itemkey == 3 || $itemkey == 4 ): ?>
                                    <div class="services-7-item <?php echo esc_attr($itemkey==4?'mt-30':''); ?>">
                                        <?php  foreach($settings['shape_list'] as $key => $shape): ?> 
                                            <div class="services-shape<?php echo esc_attr(++$key>1?'-'.$key:''); ?> elementor-repeater-item-<?php echo esc_attr( $shape['_id'] ) ?>">
                                                <img src="<?php echo esc_url($shape['shape']['url']); ?>" alt="<?php echo esc_attr__($shape['list_title']); ?>">
                                            </div>
                                            <?php if($key == 3){
                                                break;
                                            } ?>
                                        <?php endforeach; ?> 
                                        <div class="icon">
                                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </div>
                                        <h4 class="title service-title"> <?php echo esc_html($item['list_title']); ?> </h4>
                                        <p class="service-desc"> <?php echo esc_html($item['list_content']); ?></p>
                                    </div>
                            <?php endif; ?>    
                        <?php endforeach; ?> 
                    </div>
                </div>
            </div>
        </section>
     <?php endif; ?>

    <?php  

    }
    
    protected function _content_template() { }
}