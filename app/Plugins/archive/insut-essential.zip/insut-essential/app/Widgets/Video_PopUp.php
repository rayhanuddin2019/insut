<?php
namespace AppscredEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Video_PopUp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appscred-video-popup';
    }

    public function get_title() {
        return esc_html__( 'Video PopUp', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-video-camera";
    }

    public function get_categories() {
        return [ 'appscred-elements' ];
    }
    public function layout(){
        return[
            
            'style1' => esc_html__( 'Style 1', 'insut-essential' ),
            'style2' => esc_html__( 'Style 2', 'insut-essential' ),
            'style3' => esc_html__( 'Style 3', 'insut-essential' ),
      
        ];
    }
    protected function _register_controls() {
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );
            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Title settings', 'insut-essential'),
                'condition' => [ 'style' => ['style2','style1'] ],
            ]
        );
      
        $this->add_control(
			'title', [
				'label'       => esc_html__( 'Title text', 'insut-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Title here', 'insut-essential' ),
				'default'     => esc_html__( 'Appscred Helps You Succeed', 'insut-essential' ),
         	]
        );
  
 
      $this->add_control(
        'heading_type',
            [
                'label'   => esc_html__( 'Heading type', 'insut-essential' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'h2',
                'options' => [
                    'h1' => esc_html__( 'H1', 'insut-essential' ),
                    'h2' => esc_html__( 'H2', 'insut-essential' ),
                    'h3' => esc_html__( 'H3', 'insut-essential' ),
                    'h4' => esc_html__( 'H4', 'insut-essential' ),
                    'h5' => esc_html__( 'H5', 'insut-essential' ),
                    'h6' => esc_html__( 'H6', 'insut-essential' ),
                    'p'  => esc_html__( 'P', 'insut-essential' ),
                ],
            ]
        );

        $this->add_control(
			'column',
			[
				'label' => esc_html__( 'Column', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'6'  => esc_html__( '6 Column', 'insut-essential' ),
					'4'  => esc_html__( '4 Column', 'insut-essential' ),
					'12' => esc_html__( 'Full width', 'insut-essential' ),
					'none' => esc_html__( 'None', 'insut-essential' ),
				],
			]
        );
        
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .video-7-content' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
        $this->start_controls_section(
            'section_image_tab',
            [
                'label' => esc_html__('Images', 'insut-essential'),
            ]
        );
            $this->add_control(
                'image1',
                [
                    'label' => esc_html__( 'Choose Image one', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_video_tab',
            [
                'label' => esc_html__('Video settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'video_title', [
                    'label'       => esc_html__( 'Video Title', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video Title here', 'insut-essential' ),
                    'default'     => esc_html__( 'Watch Video', 'insut-essential' ),
                ]
            );

            $this->add_control(
                'video_detail', [
                    'label'       => esc_html__( 'Video Description', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'condition' => [ 'style' => ['style2'] ],
                    'placeholder' => esc_html__( 'Video Description here', 'insut-essential' ),
                    
                ]
            );

            $this->add_control(
                'video_url', [
                    'label'       => esc_html__( 'Video Url', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video url here', 'insut-essential' ),
                    'default'     => 'https://www.youtube.com/watch?v=WXW7ztYNlWg',
                ]
            );

            $this->add_control(
                'video_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::ICONS,
                ]
            );

            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label' => esc_html__( 'Title', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'List Title' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'list_icon',
                [
                    'label' => esc_html__( 'Choose Icon ', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $repeater->add_responsive_control(
                'list_thumb_image_section_position_top',
                [
                    'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1600,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                   
                    'selectors' => [
                        '{{WRAPPER}} .video-bg {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $repeater->add_responsive_control(
                'list_thumb_image_section_position_left',
                [
                    'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1600,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                   
                    'selectors' => [
                        '{{WRAPPER}} .video-bg {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'shape_list',
                [
                    'label' => esc_html__( 'Background Shape List', 'plugin-domain' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                    'condition' => [ 'style' => ['style2','style1'] ],
                ]
            );


        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );
                $this->add_control(
                    'bold_text_heading1',
                    [
                        'label' => esc_html__( 'Normal Text', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'normal_title_color', [

                        'label'     => esc_html__( 'Normal Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'normal_title_typho',
                        'label'    => esc_html__( 'Normal Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title span',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_intro_ttile_style', [
				'label' => esc_html__( 'Video Intro Title / Button text', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'video_title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-intro' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .intro-video' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'video_title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-intro,{{WRAPPER}} .intro-video',
                    ]
                );
                $this->add_responsive_control(
                    'video_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-intro' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .intro-video' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'video_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-intro' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .intro-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'video_title_icon_padding',
                    [
                        'label'      => esc_html__( 'Icon Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .intro-video i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section(
			'section_intro_desc_style', [
				'label' => esc_html__( 'Video desc', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'video_desc_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-content .text' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'video_desc_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-content .text',
                    ]
                );
                $this->add_responsive_control(
                    'video_desc_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-content .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'video_desc_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-content .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('appscred_icon_inner_main_section',
            [
            'label' => esc_html__( 'Video Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                $this->add_control( 
                    'video_icon_color', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-popup i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .video-popup svg path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'video_icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-popup i',
                    ]
                );
                $this->add_responsive_control(
                    'video_icon_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-popup' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name' => 'video_icon_gradient_background',
                            'label' => esc_html__( 'Background', 'insut-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .video-7-content a::before,{{WRAPPER}} .video-7-content a::after,{{WRAPPER}} .blog-list-item .blog-list-thumb a,{{WRAPPER}} .blog-list-item .blog-list-thumb a::before',
                        ]
                );

        $this->end_controls_section();
           //Image Style Section
		$this->start_controls_section(
			'section_thumb_image_style', [
				'label' => esc_html__( 'Thumb Image', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'style' => ['style2'] ],
			]
        );
 
              

                $this->add_responsive_control(
                    'thumb_image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'thumb_image_radius',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .video-thumb img' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 
              
        $this->end_controls_section();
        $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name' => 'main_sec_gradient_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-bg,{{WRAPPER}} .blog-list-item',
                    ]
            );
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-7-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .blog-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-7-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .blog-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'box_media_heading1',
                [
                    'label' => esc_html__( 'Inner Background Shape', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'style' => ['style2'] ],
                ]
            );
            
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name' => 'inner_shape_content_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-area .video-bg::before',
                       
                       'condition' => [ 'style' => ['style2'] ],
                    ]
            );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		$title     = $settings['title'];
	    $title_1   = str_replace(['{', '}'], ['<span>', '</span>'], $title);
       
    ?>
            <!--====== VIDEO 7 PART START ======-->
        <?php if($settings['style'] == 'style1'): ?>   
            <section class="video-7-area">
                <div class="video-bg">
                    <?php foreach($settings['shape_list'] as $key => $item): ?>
                        <div class="video-shape-<?php echo esc_attr( ++$key ); ?> elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                           <img src=" <?php echo esc_url($item['list_icon']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-9">
                            <div class="video-7-content">
                                <<?php echo esc_attr($settings['heading_type']); ?> class="title"> <?php echo appscred_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                                <span class="video-intro"> <?php echo esc_html($settings['video_title']); ?> </span>
                                <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>">
                                   <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
       <!--====== VIDEO 7 PART ENDS ======-->
       <?php endif; ?>
       <?php if($settings['style'] == 'style2'): ?>   
         <!--====== VIDEO PART START ======-->
            <section class="video-area">
                <div class="video-bg">
              
                    <div class="shape-1"></div>
                    <div class="shape-2"></div>
                    <div class="shape-3"></div>
                </div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="video-content text-center">
                            <<?php echo esc_attr($settings['heading_type']); ?> class="title"> <?php echo appscred_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                                <p class="text"> <?php echo esc_html($settings['video_detail']); ?> </p>
                                <a class="main-btn video-popup intro-video" href="<?php echo esc_url($settings['video_url']); ?>">
                                      <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                     <?php echo esc_html($settings['video_title']); ?>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-10">
                            <div class="video-thumb text-center mt-50">
                                <?php if($settings['image1']['url'] !=''): ?>
                                    <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!--====== VIDEO PART ENDS ======-->
       <?php endif; ?>
       <?php if($settings['style'] == 'style3'): ?>  

            <div class="blog-list-item">
                <div class="blog-list-thumb">
                    <?php if($settings['image1']['url'] !=''): ?>
                        <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','insut-essential'); ?>">
                    <?php endif; ?>
                    <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>"><i class="fas fa-play"></i></a>
                </div>
            </div>

       <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}