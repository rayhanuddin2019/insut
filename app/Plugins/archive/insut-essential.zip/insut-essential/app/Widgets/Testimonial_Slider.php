<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

class Testimonial_Slider extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-testimonial-slider';
    }

    public function get_title() {
        return esc_html__( 'Insut Testimonial Slider ', 'insut-essential' );
    }

    public function get_icon() { 
        return "fas fa-quote-left";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
    public function elementor_template() {
      $templates = \Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
      $types     = array();
      if ( empty( $templates ) ) {
          $template_lists = [ '0' => __( 'Do not Saved Templates.', 'insut-essential' ) ];
      } else {
          $template_lists = [ '0' => __( 'Select Template', 'insut-essential' ) ];
          foreach ( $templates as $template ) {
              $template_lists[ $template['template_id'] ] = $template['title'] . ' (' . $template['type'] . ')';
          }
      }
      return $template_lists;
  }
    protected function _register_controls() { 

     
 
      $this->start_controls_section(
         'section_layouts_tab',
         [
             'label' => esc_html__('Layout', 'insut-essential'),
         ]
     );

     $this->add_control(

      'block_style', [
          'label'   => esc_html__('Choose Style', 'insut-essential'),
          'type'    => Custom_Controls_Manager::RADIOIMAGE,
          'default' => 'style1',
          'options' => [

            'style1' => [
               'title'      => esc_html__( 'Style 1', 'insut-essential' ),
               'imagelarge' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'imagesmall' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'width'      => '50%',
            ],

            'style2' => [
               'title'      => esc_html__( 'Style template', 'insut-essential' ),
               'imagelarge' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'imagesmall' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'width'      => '49%',
            ],

            'style3' => [
               'title'      => esc_html__( 'Style 3', 'insut-essential' ),
               'imagelarge' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style3.png',
               'imagesmall' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style3.png',
               'width'      => '100%',
            ],

            'style4' => [
               'title'      => esc_html__( 'Style 4', 'insut-essential' ),
               'imagelarge' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style4.png',
               'imagesmall' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style4.png',
               'width'      => '50%',
            ],

            'style5' => [
               'title'      => esc_html__( 'Style 5', 'insut-essential' ),
               'imagelarge' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style5.png',
               'imagesmall' => INSUT_ESSENTIAL_IMG . '/admin/testimonial/style5.png',
               'width'      => '48%',
            ],
       
          
        ],

      ]
    ); 

    $this->end_controls_section();
    do_action( 'insut_section_slider_tab', $this , $this->get_name()); 
       
    $this->start_controls_section('section_tab',
         [
            'label' => esc_html__('Contents', 'insut-essential'),
         ]
      );

      $this->add_control(
         'template_id',
         [
             'label'     => esc_html__( 'Left Content ', 'appscred-essential' ),
             'type'      => Controls_Manager::SELECT,
             'default'   => '0',
             'options'   => $this->elementor_template(),
             'description' => esc_html__( 'Please select elementor templete from here, if not create elementor template from menu', 'insut-essential' ),
             'condition' => [ 'block_style' => ['style1'] ],
         ]
     );

      
      $repeater = new \Elementor\Repeater();

      $repeater->add_control(
			'testimonial',
			[
				'label'       => esc_html__( 'Testimonial', 'insut-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => esc_html__( 'Default testimonial', 'insut-essential' ),
				'placeholder' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing', 'insut-essential' ),
			]
      );
      
     
		$repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
		);

      $repeater->add_control(
			'client_name',
			[
				'label'       => esc_html__( 'Client name', 'insut-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Shuvas Chandra', 'insut-essential' ),
				'placeholder' => esc_html__( 'Type your client name here', 'insut-essential' ),
			]
      );

      $repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'insut-essential' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
               'url' => INSUT_ESSENTIAL_IMG.'/testimonial-1.jpg',
				],
			]
      );

    
      $repeater->add_control(
			'client_designation',
			[
				'label'       => esc_html__( 'Client designation', 'insut-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Founder at Seative Digital', 'insut-essential' ),
				'placeholder' => esc_html__( 'Type your client designation here', 'insut-essential' ),
			]
      );

      $repeater->add_control(
			'rating',
			[
				'label' => esc_html__( 'Rating', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5,
						'step' => 1,
					],
				
				],
			
			]
		);

     
  
		$this->add_control(
			'testimonial_list',
			[
				'label'       => esc_html__( 'Testimonial List', 'plugin-domain' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ client_name }}}',
			]
		);

      $this->end_controls_section();

      

      $this->start_controls_section('apps_content_style_section',
         [
            'label' => esc_html__( 'Content Style', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
     
   
      $this->add_responsive_control('box_padding_n',
         [
            'label'      => esc_html__( 'Testimonial Padding', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px' ],
            
            'selectors' => [
               '{{WRAPPER}} .testimonial__content' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
               '{{WRAPPER}} .testimonial__content' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
            ],
         ]
      );
 
      
      $this->add_control(
         'testimonial_color',
            [
                'label'     => esc_html__('Testimonial color', 'insut-essential'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial__content' => 'color: {{VALUE}};',
                ],
            ]
      );

      $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_typho',
				'label'    => esc_html__( 'Testimonial Typography', 'insut-essential' ),
				'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .testimonial__content',
			]
      );

      $this->add_control(
         'client_color',
            [
                'label'     => esc_html__('Client color', 'insut-essential'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .author__name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .blog-list-quote > span::before' => 'background: {{VALUE}};',
                ],
            ]
      );

      $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'client_typho',
				'label'    => esc_html__( 'Client Typography', 'insut-essential' ),
				'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .author__name',
			]
      );

      $this->add_responsive_control('client_margin_n',
      [
         'label'      => esc_html__( 'Client Margin', 'insut-essential' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%' ],
         
         'selectors' => [
            '{{WRAPPER}} .author__name' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
         ],
      ]
     );

      $this->add_control(
         'des_color',
            [
                'label'     => esc_html__('Designation color', 'insut-essential'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .author__designation' => 'color: {{VALUE}};',
                ],
            ]
      );

      $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'des_typho',
				'label'    => esc_html__( 'Designation Typography', 'insut-essential' ),
				'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .author__designation',
			]
      );

      $this->add_responsive_control('des_margin_n',
         [
            'label'      => esc_html__( 'Designation Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%' ],
            'selectors' => [
               '{{WRAPPER}} .author__designation' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
            ],
         ]
      );


     

      $this->end_controls_section();  
      $this->start_controls_section(
			'section__rarting_style', [
				'label' => esc_html__( 'Rating Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'block_style' => ['style4'] ],
            
			  ]
      );

      $this->add_control(
         'rating_icon_color',
            [
               'label'     => esc_html__('Color', 'insut-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
                  '{{WRAPPER}} .author-meta .stat-rating span i' => 'color: {{VALUE}};',
  
                
               ],
            ]
      );

      $this->add_control(
         'rating_icon_inactive_color',
            [
               'label'     => esc_html__('Active Color', 'insut-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
                  '{{WRAPPER}} .author-meta .stat-rating i' => 'color: {{VALUE}};',
  
                
               ],
            ]
      );
      $this->add_group_control(
         Group_Control_Typography::get_type(),
         [
            'name'     => 'rating_icon_quota_typho',
            'label'    => esc_html__( 'Typography', 'insut-essential' ),
            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            'selector' => '{{WRAPPER}} .author-meta .stat-rating i,{{WRAPPER}} .author-meta .stat-rating span i',
         ]
      );
      $this->add_responsive_control('rating_icon_margin_n',
      [
         'label'      => esc_html__( ' Margin', 'insut-essential' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%' ],
         
         'selectors' => [
            '{{WRAPPER}} .stat-rating' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
            
           
         ],
      ]
   );
      $this->end_controls_section();  
      $this->start_controls_section(
			'section_icon_style', [
				'label' => esc_html__( 'Quote Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            
			  ]
      );

            $this->add_control(
               'icon_quota_color',
                  [
                     'label'     => esc_html__('Color', 'insut-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} .quote i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .quote' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .quote-icon i' => 'color: {{VALUE}};',
                      
                     ],
                  ]
            );
            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'quote_icon_style5_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  //'condition' => [ 'block_style' => ['style5'] ],
                  'selector' => '{{WRAPPER}} .quote,{{WRAPPER}} .quote-icon',
               ]
            );
            $this->add_control(
               'icon_quota2_color',
                  [
                     'label'     => esc_html__('Quote 2 Color', 'insut-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'condition' => [ 'block_style' => ['style5'] ],
                     'selectors' => [
                        '{{WRAPPER}} .quote-bg-ion i' => 'color: {{VALUE}};',
                   
                      
                     ],
                  ]
            );

           

            $this->add_group_control(
               Group_Control_Typography::get_type(),
               [
                  'name'     => 'icon_quota_typho',
                  'label'    => esc_html__( 'Typography', 'insut-essential' ),
                  'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                  'selector' => '{{WRAPPER}} .quote i,{{WRAPPER}} .quote i,{{WRAPPER}} .quote-icon i',
               ]
            );

            
              // quote icon
         $this->add_responsive_control('image_quote_margin_n',
         [
            'label'      => esc_html__( 'Quote Image Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%' ],
            
            'selectors' => [
               '{{WRAPPER}} .quote' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
               '{{WRAPPER}} .quote-icon' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
              
            ],
         ]
      );

     
      $this->add_responsive_control(
         'quote_img_borders_radius',
         [
            'label'      => esc_html__( 'Quote Border radius', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],

            'selectors' => [
               
               '{{WRAPPER}} .quote' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               '{{WRAPPER}} .quote-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
               
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Border::get_type(),
         [
             'name'     => 'quote_image_border',
             'label'    => esc_html__( 'Quote Border', 'insut-essential' ),
             'selector' => '{{WRAPPER}} .quote,{{WRAPPER}} .quote-icon',
            
         ]
      );

      $this->end_controls_section();  

      $this->start_controls_section(
			'section_images_style', [
				'label' => esc_html__( 'Image', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      );

         $this->add_responsive_control('image_client_margin_n',
            [
               'label'      => esc_html__( 'Client Image Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],
               
               'selectors' => [
                  '{{WRAPPER}} .testimonial__author__thumb' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
               ],
            ]
         );

        
         $this->add_responsive_control(
            'client_img_borders_radius',
            [
               'label'      => esc_html__( 'Client Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               
               'selectors' => [
                  
                  '{{WRAPPER}} .testimonial__author__thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                  
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'image_border',
                'label'    => esc_html__( 'Client Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .testimonial__author__thumb',
              
            ]
         );

    
      $this->end_controls_section(); 
      $this->start_controls_section(
			'section_box_item_style', [
				'label' => esc_html__( 'Box Item', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      ); 

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'section_box_item_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .single-testimonial ,{{WRAPPER}} .single-item-testimonial,{{WRAPPER}} .testi-single-item',
               ]
            );

            $this->add_responsive_control(
               'box_item_margin',
               [
                  'label'      => esc_html__( 'Margin', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .single-testimonial' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .single-item-testimonial' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .testi-single-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_item_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .single-testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           '{{WRAPPER}} .single-item-testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           '{{WRAPPER}} .testi-single-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                         
                        ],
                  ]
            );

            $this->add_control(
               'border_box_item_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .single-testimonial' => 'border-radius: {{VALUE}}px;',
                           '{{WRAPPER}} .single-item-testimonial' => 'border-radius: {{VALUE}}px;',
                           '{{WRAPPER}} .testi-single-item' => 'border-radius: {{VALUE}}px;',
                         
                  ],
               ]
            );  

            $this->add_group_control(
               \Elementor\Group_Control_Box_Shadow::get_type(),
               [
                  'name' => 'box_item_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                  'selector' => '{{WRAPPER}} .testi-single-item,{{WRAPPER}} .single-testimonial,{{WRAPPER}} .single-item-testimonial',
               ]
            );

           

      $this->end_controls_section();  
      $this->start_controls_section('appscred_style_slider_nav',
      [
         'label' => esc_html__( 'Navigation', 'insut-essential' ),
         'tab'   => Controls_Manager::TAB_STYLE,
      ]
     );
      
      $this->add_control(
         'nav_color',
         [
            'label'     => esc_html__('Color', 'insut-essential'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
               '{{WRAPPER}} .owl-nav i' => 'color: {{VALUE}};',
             
            ],
          
         ]
      );

      $this->add_control(
       'nav_hvcolor',
       [
          'label'     => esc_html__('Hover color', 'insut-essential'),
          'type'      => Controls_Manager::COLOR,
          'selectors' => [
             '{{WRAPPER}} .owl-nav:hover i' => 'color: {{VALUE}};',
           
          ],
         
       ]
    );

    $this->add_control(
       'nav_background_heading',
       [
          'label'     => esc_html__( 'Nav background', 'insut-essential' ),
          'type'      => \Elementor\Controls_Manager::HEADING,
          'separator' => 'after',
       ]
    );
    
      $this->add_group_control(
       \Elementor\Group_Control_Background::get_type(),
          [
             'name'     => 'nav_background',
             'label'    => esc_html__( 'Background', 'insut-essential' ),
             'types'    => [ 'classic', 'gradient' ],
             'selector' => '{{WRAPPER}} .owl-carousel .owl-nav button , {{WRAPPER}} .owl-carousel .owl-dots button',
          ]
       );

      
      
       
       $this->add_control(
          'nav_hvbackground_heading',
          [
             'label'     => esc_html__( 'Nav Hover background', 'insut-essential' ),
             'type'      => \Elementor\Controls_Manager::HEADING,
             'separator' => 'after',
             
          ]
       );   
       $this->add_group_control(
       \Elementor\Group_Control_Background::get_type(),
          [
             'name'      => 'nav_hv_background',
             'label'     => esc_html__( 'Background', 'insut-essential' ),
             'types'     => [ 'classic', 'gradient' ],
             'selector'  => '{{WRAPPER}} .owl-carousel .owl-dots button.active, {{WRAPPER}} .owl-carousel .owl-nav button:hover,{{WRAPPER}} .owl-carousel .owl-nav button:after',
            
          ]
       );

      
       $this->add_control(
          'nav_width',
          [
             'label'      => esc_html__( 'Width', 'insut-essential' ),
             'type'       => Controls_Manager::SLIDER,
             'size_units' => [ 'px' ],
             'range'      => [
                'px' => [
                   'min'  => 5,
                   'max'  => 200,
                   'step' => 1,
                ],
               
             ],
            
             'selectors' => [
                '{{WRAPPER}} .owl-carousel .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .owl-carousel .owl-dots button' => 'width: {{SIZE}}{{UNIT}};',
               
               
             ],
          ]
       );
 

       $this->add_responsive_control(
          'nav_border_radius',
          [
             'label'      => esc_html__( 'Border radius', 'insut-essential' ),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => [ 'px','%'],
             'selectors'  => [
                
                '{{WRAPPER}} .owl-carousel .owl-nav button'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                '{{WRAPPER}} .owl-carousel .owl-dots button'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
             
               
                
             ],
          ]
         );

         $this->add_responsive_control(
            'nav_position_bottom',
            [
               'label'      => esc_html__( 'Bottom', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -1500,
                     'max'  => 1200,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .testimonial-slider-ele.owl-carousel .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .owl-carousel .owl-dots' => 'bottom: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );

         $this->add_responsive_control(
            'nav_position_left',
            [
               'label'      => esc_html__( 'Left', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => -1500,
                     'max'  => 1000,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .testimonial-slider-ele.owl-carousel .owl-nav' => 'left: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .owl-carousel .owl-dots' => 'left: {{SIZE}}{{UNIT}};',
                 
                 
               ],
            ]
         );

         $this->add_responsive_control(
            'box_style3_margin_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'condition' => [ 'block_style' => ['style3'] ],
               'selectors'  => [
                     '{{WRAPPER}} .owl-carousel .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
               ],
            ]
         );
       
      $this->end_controls_section(); 

      $this->start_controls_section('appscred_main_section_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
      );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'section_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .main-section',
               ]
            );
  
            $this->add_responsive_control(
               'box_margin',
               [
                  'label'      => esc_html__( 'Margin', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                  ]
            );

            $this->add_control(
               'border_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .main-section' => 'border-radius: {{VALUE}}px;',
                  ],
               ]
            );  
      $this->end_controls_section();
   }
   protected function render(){

     $settings         = $this->get_settings();
     $testimonial_list = $settings['testimonial_list'];
     
     $slide_controls = insut_widgets_owl_slider_controls_setttings($settings);
     $class_owl       = $settings['slider_enable'] == 'yes'? 'owl-carousel':'';

    
    ?>
       <?php if($settings['block_style'] =='style1'): ?>
           
           <!-- Testimonail Section Start -->
           <section class="testimonial-section main-section" >
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-5">
                       <?php if($settings['template_id'] !=''): ?>
                          <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $settings['template_id'] ); ?>
                       <?php endif; ?>
                    </div>
                     <div class="col-lg-6 col-md-7">
                        <!-- Testimonial Slider Start -->
                        <div class="testimonial-slider <?php echo esc_attr($class_owl); ?> testimonial-slider-ele" data-controls='<?php echo json_encode($slide_controls); ?>'>
                            
                            <!-- Testimonial Item Start -->
                            <?php foreach($testimonial_list as $item): ?>
                              <div class="single-testimonial">
                                 <div class="testi-author">
                                       <div class="author-thumb">
                                       <?php if($item['image']['url'] !=''): ?>
                                          <img class="testimonial__author__thumb" src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                                       <?php endif; ?>
                                          <div class="quote">
                                             
                                             <?php if( $item['list_icon']['value'] == '' ): ?>
                                                “
                                             <?php else: ?>
                                                   <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                             <?php endif; ?>

                                          </div>
                                       </div>
                                       <h5 class="title author author__name"> <?php echo esc_html($item['client_name']); ?> </h5>
                                       <p class="author__designation designation"> <?php echo esc_html($item['client_designation']); ?> </p>

                                 </div>
                                 <blockquote class="testimonial__content">
                                    <?php echo esc_html($item['testimonial']); ?>
                                 </blockquote>
                              </div>
                            <?php endforeach; ?>
                            <!-- Testimonial Item End -->

                          
                        </div>
                        <!-- Testimonial Slider End -->
                    </div>
                </div>
            </div>
           </section>
           <!-- Testimonail Section End -->

        <?php endif; ?>
        <?php if($settings['block_style'] =='style2'): ?>
           
           <!-- Testimonail Section Start -->
           <section class="testimonial-section main-section" >
            
                         <!-- Testimonial Slider Start -->
                         <div class="testimonial-slider <?php echo esc_attr($class_owl); ?> testimonial-slider-ele" data-controls='<?php echo json_encode($slide_controls); ?>'>
                            
                            <!-- Testimonial Item Start -->
                            <?php foreach($testimonial_list as $item): ?>
                              <div class="single-testimonial">
                                 <div class="testi-author">
                                       <div class="author-thumb">
                                       <?php if($item['image']['url'] !=''): ?>
                                          <img class="testimonial__author__thumb" src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                                       <?php endif; ?>
                                          <div class="quote">
                                             
                                             <?php if( $item['list_icon']['value'] == '' ): ?>
                                                “
                                             <?php else: ?>
                                                   <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                             <?php endif; ?>

                                          </div>
                                       </div>
                                       <h5 class="title author author__name"> <?php echo esc_html($item['client_name']); ?> </h5>
                                       <p class="author__designation designation"> <?php echo esc_html($item['client_designation']); ?> </p>

                                 </div>
                                 <blockquote class="testimonial__content">
                                    <?php echo esc_html($item['testimonial']); ?>
                                 </blockquote>
                              </div>
                            <?php endforeach; ?>
                            <!-- Testimonial Item End -->

                          
                        </div>
                        <!-- Testimonial Slider End -->
                
           </section>
           <!-- Testimonail Section End -->

        <?php endif; ?>
        <?php if($settings['block_style'] =='style3'): ?>
        
               <div data-nav="dot"  class="main-section testimonial-slider-two testimonial-slider-ele <?php echo esc_attr($class_owl); ?>" data-controls='<?php echo json_encode($slide_controls); ?>'>
                     <?php foreach($testimonial_list as $item): ?>
                        <div class="single-item-testimonial">
                           <div class="testimonial-author">
                                    <?php if($item['image']['url'] !=''): ?>
                                    <img class="testimonial__author__thumb" src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                                 <?php endif; ?>
                              <div class="quote-icon">
                                 
                                 <?php if( $item['list_icon']['value'] == '' ): ?>
                                    <i class="icofont-quote-left"></i>
                                 <?php else: ?>
                                       <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                 <?php endif; ?>
                              </div>
                           </div>
                           <blockquote class="testimonial__content">
                              <?php echo esc_html($item['testimonial']); ?>
                           </blockquote>
                           <h5 class="author author__name"><?php echo esc_html($item['client_name']); ?></h5>
                           <p class="designation author__designation"><?php echo esc_html($item['client_designation']); ?></p>
                        </div>
                     <?php endforeach; ?>
               </div>
        
        <?php endif; ?>
        <?php if($settings['block_style'] =='style4'): ?>
          <!-- Testimonial Slider Start -->
          <div data-nav="dot" dot-style='style4' class="testimonial-slider-three main-section testimonial-slider-ele <?php echo esc_attr($class_owl); ?>" data-controls='<?php echo json_encode($slide_controls); ?>'>
               <?php foreach($testimonial_list as $item): ?>
                  <div class="testi-single-item">
                     <div class="testi-author-area">
                        <div class="author-thumb">
                                <?php if($item['image']['url'] !=''): ?>
                                    <img class="testimonial__author__thumb" src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                                 <?php endif; ?>
                              <div class="quote-icon">
                                 
                                 <?php if( $item['list_icon']['value'] == '' ): ?>
                                    <i class="icofont-quote-left"></i>
                                 <?php else: ?>
                                       <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                 <?php endif; ?>
                              </div>
                        </div>
                        <div class="author-meta">
                              <h5 class="author author__name"> <?php echo esc_html($item['client_name']); ?> </h5>
                              <p class="designation author__designation"><?php echo esc_html($item['client_designation']); ?></p>
                              <div class="stat-rating">
                                 <?php
                                    $active = 0; 
                                    $inactive = 5; 
                                    $total = $item['rating']['size'];
                                    if( $total != '' ){
                                       $active = $total;
                                       $inactive = 5 - $total;
                                    }
                                
                                   
                                       
                                 ?>
                                 <span>
                                    <?php foreach(range(1, $active) as $i): ?>
                                       <i class="icofont-star"></i>
                                    <?php endforeach;  ?>                 
                                   
                                   
                                 </span>
                                 <?php foreach(range(1, $inactive) as $j): ?>
                                       <i class="icofont-star"></i>
                                    <?php endforeach;  ?>   
                              </div>
                        </div>
                     </div>
                     <blockquote class="testimonial__content">
                        <?php echo esc_html($item['testimonial']); ?>
                     </blockquote>
                  </div>
               <?php endforeach; ?>
            
         </div>
         <!-- Testimonial Slider End -->
        <?php endif; ?>
        <?php if($settings['block_style'] =='style5'): ?>
           <!-- Testimonial Section Start -->
        <section class="testi-page-sec-02 main-section" >
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Testimonial Slider Start -->
                        <div data-style='style5' class="testimonial-slider-four <?php echo esc_attr($class_owl); ?> testimonial-slider-ele" data-controls='<?php echo json_encode($slide_controls); ?>'>
                           <?php foreach($testimonial_list as $item): ?>
                             <!-- Testimonial Item Start -->
                            <div class="single-testimonial">
                                <div class="testi-author">
                                    <div class="author-thumb">
                                    <?php if($item['image']['url'] !=''): ?>
                                       <img class="testimonial__author__thumb" src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                                    <?php endif; ?>
                                        <div class="quote">
                                            <?php if( $item['list_icon']['value'] == '' ): ?>
                                                “
                                             <?php else: ?>
                                                   <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                             <?php endif; ?>
                                        </div>
                                    </div>
                                    <h5 class="author author__name"><?php echo esc_html($item['client_name']); ?></h5>
                                    <p class="designation author__designation"><?php echo esc_html($item['client_designation']); ?></p>
                                </div>
                                <blockquote class="testimonial__content">
                                    <?php echo esc_html($item['testimonial']); ?>
                                 </blockquote>
                                <div class="quote-bg-ion">
                                   <?php if( $item['list_icon']['value'] == '' ): ?>
                                       <i class="icofont-quote-left"></i>
                                    <?php else: ?>
                                          <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    <?php endif; ?>
                              </div>
                            </div>
                            <!-- Testimonial Item End -->
                           <?php endforeach; ?>
                        </div>
                        <!-- Testimonial Slider End -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonial Section End -->
        <?php endif; ?>


   <?php  
   }
}  