<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Insut_List extends Widget_Base {

    public $base;

    public function get_name() {
        return 'insut-list';
    }

    public function get_title() {
        return esc_html__( 'Insut List', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-bars";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Insut List settings', 'insut-essential'),
            ]
        );
      
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
        );
        
        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );
        $repeater->add_control(
            'icon_list_color', [

                'label'     => esc_html__( 'Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} i' => 'color: {{VALUE}};',
             
                ],
            ]
        );
     
         $repeater->add_control('icon_sbox_background_color',
         [
             'label'     => esc_html__( 'Background color', 'insut-essential' ),
             'type'      => Controls_Manager::COLOR,
          
             'selectors' => [
               
                 '{{WRAPPER}} {{CURRENT_ITEM}} i' => 'background: {{VALUE}};',
                   
                 ],
             ]
         );
		$this->add_control(
			'list',
			[
				'label' => esc_html__( ' List', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [

					[
						'list_title' => esc_html__( 'Title #1', 'insut-essential' ),
					],
				
				],
				'title_field' => '{{{ list_title }}}',
			]
        );
        
   
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'insut-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'insut-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'insut-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'insut-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'insut-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .service-benefit-content' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'List', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .service-benefit-content ul li' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}}  .service-benefit-content ul li',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}}  .service-benefit-content ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}}  .service-benefit-content ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_icon_style', [
				'label' => esc_html__( 'Icon', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'service_li_icon',
                    [
                        'label' => esc_html__( 'Service icon', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                       
                    ]
                );

                $this->add_responsive_control(
                    'service_list_title_s_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .service-benefit-content ul li i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                   
                        
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'icons_s_opecity',
                    [
                       'label'      => esc_html__( 'Opacity', 'insut-essential' ),
                       'type'       => Controls_Manager::SLIDER,
                       'size_units' => [ 'px' ],
                       'range'      => [
                          'px' => [
                             'min'  => 0,
                             'max'  => 1,
                             'step' => .1,
                          ],
                        
                       ],
                      
                       'selectors' => [
                          '{{WRAPPER}} .service-benefit-content ul li i' => 'opacity: {{SIZE}};',
                       ],
                     
                      
                    ]
                 );

                 $this->add_responsive_control(
                    '_box_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .service-benefit-content ul li i' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                           
                          
                        ],
                        'separator' => 'before',
                    ]
                );

                 $this->add_control(
                    'icon_color', [
    
                        'label'     => esc_html__( 'Icon color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                     
                        '{{WRAPPER}} ul li i' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} li i',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                       'name'     => 'list_post_box_shadow',
                       'label'    => esc_html__( 'Box Shadow', 'insut-essential' ),
                       'selector' => '{{WRAPPER}} ul li i',
                    ]
                 );

                 $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                       'name'     => 'list_icon_border',
                       'label'    => esc_html__( 'Border', 'insut-essential' ),
                       'selector' => '{{WRAPPER}} ul li i',
                       
                    ]
              );
            
        $this->end_controls_section();
        $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
       
         
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .service-benefit-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .service-benefit-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'service_list_section_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .service-benefit-content',
                   
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
        $list      = $settings['list'];
        
       
    ?>
  
        <div class="service-benefit-content">
                          
            <ul>
                <?php foreach( $list as $item ): ?>
                    <li class="elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                    <?php if($item['list_icon']['value'] == ''): ?>
                        <i class="icofont-check"></i>
                    <?php else: ?>    
                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>
                    <?php echo esc_html($item['list_title']); ?>
                    </li>
                <?php endforeach; ?> 
            </ul>

        </div>
    <?php  

    }
    
    protected function _content_template() { }
}