<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Insurance_Service_Grid extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-insurance-service-grid';
    }

    public function get_title() {
        return esc_html__( 'Insut Insurance Service grid', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fa fa-telegram';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
  
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'insut-essential'),
            ]
        );

                $this->add_control(

                    'style', [
                        'label'   => esc_html__('Choose Style', 'insut-essential'),
                        'type'    => Custom_Controls_Manager::RADIOIMAGE,
                        'default' => 'style1',
                        'options' => [

                                'style1' => [
                                        'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                                        'imagelarge' => INSUT_IMG . '/admin/insurance/style1.png',
                                        'imagesmall' => INSUT_IMG . '/admin/insurance/style1.png',
                                        'width'      => '100%',
                                ],
                                'style2' => [
                                    'title'      => esc_html__( 'Style 2', 'insut-essential' ),
                                    'imagelarge' => INSUT_IMG . '/admin/insurance/style2.png',
                                    'imagesmall' => INSUT_IMG . '/admin/insurance/style2.png',
                                    'width'      => '48%',
                                ],

                                'style3' => [
                                    'title'      => esc_html__( 'Style 3', 'insut-essential' ),
                                    'imagelarge' => INSUT_IMG . '/admin/insurance/style3.png',
                                    'imagesmall' => INSUT_IMG . '/admin/insurance/style3.png',
                                    'width'      => '50%',
                                ],
        

                    ],

                    ]
                ); 
                
                $this->add_control(
                    'custom_service',
                    [
                        'label'     => esc_html__('Custom Service', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => '',
                        
                    ]
                ); 

                $this->add_control(
                    'service',
                    [
                        'label' => esc_html__( 'Service_items', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT2,
                        'multiple' => true,
                        'options' => $this->get_service_list(),
                        'condition' => [ 
                            'custom_service' => ['']
                        ],
                        'show_label' => true,
                        'label_block' => true,
                    ]
                );

                $this->add_control(
                    'custom_service_ids', [
                        'label'       => esc_html__( 'Custom Service ids', 'insut-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                        'default'     => esc_html__( '1, 2' , 'insut-essential' ),
                        'placeholder' => esc_html__( '1, 2' , 'insut-essential' ),
                        'description' => esc_html__( 'post id seperate with comma' , 'insut-essential' ),
                        'show_label'  => true,
                        'condition'   => [ 
                            'custom_service' => ['yes']
                        ],
                    ]
                );

                $this->add_control(
                'post_count',
                    [
                        'label'   => esc_html__( 'Post count', 'insut-essential' ),
                        'type'    => Controls_Manager::NUMBER,
                        'default' => '6',
                    ]
                );
                $this->add_control(
                    'post_title_crop',
                    [
                    'label'   => esc_html__( 'Title limit', 'insut-essential' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => '20',
                    
                    ]
                ); 
               
                $this->add_control(
                    'show_desc',
                    [
                        'label'     => esc_html__('Show desc', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                        
                    ]
                ); 
               
                $this->add_control('desc_limit',
                    [
                      'label'     => esc_html__( 'Description limit', 'insut-essential' ),
                      'type'      => Controls_Manager::NUMBER,
                      'default'   => '40',
                      'min'       => 2,
                      'condition' => [ 
                         'show_desc' => ['yes']
                       ],
                      
                    ]
                );  
        
                $this->add_control('show_title_icon',
                    [
                        'label'     => esc_html__('Show Title Icon', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                    ]
                ); 

               
            
                $this->add_control(
                    'post_sort',
                    [
                        'label' => esc_html__( 'Sort', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'DESC',
                        'options' => [
                            'ASC'  => esc_html__( 'ASC', 'insut-essential' ),
                            'DESC' => esc_html__( 'DESC', 'insut-essential' ),
                        ],
                    ]
                );

                $this->add_control(
                    'show_more_active',
                    [
                        'label'     => esc_html__('Show show more button', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                        
                    ]
                );
                $this->add_control(
                    'show_more_text',
                    [
                        'label'   => esc_html__( 'View more text', 'insut-essential' ),
                        'type'    => Controls_Manager::TEXT,
                        'default' => esc_html__( 'View more', 'insut-essential' ),
                        'condition' => [ 
                            'style' => ['style3']
                          ],

                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Image_Size::get_type(),
                    [
                        'name' => 'thumbnail_image_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                        'exclude' => [ 'custom' ],
                        'include' => [],
                        'default' => 'large',
                    ]
                );

                $this->add_responsive_control(
                    'title_align', [
                        'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                        'type'    => Controls_Manager::CHOOSE,
                        'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'insut-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                        'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'insut-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                                'title' => esc_html__( 'Right', 'insut-essential' ),
                                'icon'  => 'fa fa-align-right',
                        
                        ],
                        'justify'	 => [

                                'title' => esc_html__( 'Justified', 'insut-essential' ),
                                'icon'  => 'fa fa-align-justify',
                        
                            ],
                        ],
                        'default' => 'justify',
                        'selectors' => [
                            '{{WRAPPER}} .single-service'   => 'text-align: {{VALUE}};',
                            '{{WRAPPER}} .single-service-box'   => 'text-align: {{VALUE}};',
                        
                        ],
                        'condition' => [ 'style' => ['style1','style3'] ],
                    ]
                );//Responsive control end

        $this->end_controls_section();

       
        $this->start_controls_section('insut__tab_content_icon',
            [
            'label' => esc_html__( 'Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            
            $this->add_control(
                'default_icon_enable',
                [
                    'label'     => esc_html__('Default Icon Enable', 'insut-essential'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'insut-essential'),
                    'label_off' => esc_html__('No', 'insut-essential'),
                    'default'   => '',
                    
                ]
            ); 

            $this->add_control(
                'tab_content_icon_color', [

                    'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .ser-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ser-box-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ser-post-icon i' => 'color: {{VALUE}};',
        
                    ],
                ]
            );

            

        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_icon_typho',
                    'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .ser-icon i,{{WRAPPER}} .ser-box-icon i,{{WRAPPER}} .ser-post-icon i',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                   'name'     => 'icon_center_style5_background',
                   'label'    => esc_html__( 'Background', 'insut-essential' ),
                   'types'    => [ 'classic', 'gradient', 'video' ],
                   'condition' => [ 'style' => ['style2','style3'] ],
                   'selector' => '{{WRAPPER}} .ser-box-icon ,{{WRAPPER}} .ser-post-icon',
                ]
             );
            
            $this->add_control(
                'tab_content_icon_view_more_heading',
                [
                    'label' => esc_html__( 'Read More Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'tab_content_border_radious',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .read-more' => 'border-radius: {{VALUE}}px;',
                        
                    ],
                ]
            ); 


            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                'name'     => 'tab_content_icon_background',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .read-more',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'     => 'readmore_icon_backgroundbox_border',
                    'label'    => esc_html__( 'Border', 'insut-essential' ),
                    'selector' => '{{WRAPPER}} .read-more',
                ]
            );
            
            $this->add_control(
                'tab_content_view_more_icon_color', [

                    'label'     => esc_html__( ' Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .read-more i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .read-more' => 'color: {{VALUE}};',
        
                    ],
                ]
            );

            $this->add_control(
                'tab_content_view_more_icon_hover_color', [

                    'label'     => esc_html__( 'Readmore Hover Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .read-more:hover i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .read-more:hover' => 'color: {{VALUE}};',
        
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'tab_content_icon_readmore_hover_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .read-more:hover',
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_view_more_icon_typho',
                    'label'    => esc_html__( ' Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .read-more i, {{WRAPPER}} .read-more',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_content_title',
            [
            'label' => esc_html__( 'Title', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_content_title_color', [

                'label'     => esc_html__( 'Title Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .ser-details h4' => 'color: {{VALUE}};',
                '{{WRAPPER}} .single-icon-service h4' => 'color: {{VALUE}};',
                '{{WRAPPER}} .single-service-box h4 a' => 'color: {{VALUE}};',
    
                ],
            ]
        );

        
        $this->add_control(
            'tab_content_title_hover_color', [

                'label'     => esc_html__( 'Title hover Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .ser-details h4:hover a' => 'color: {{VALUE}};',
                '{{WRAPPER}}  h4:hover a' => 'color: {{VALUE}};',
    
                ],
            ]
        );

    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_title_typho',
                'label'    => esc_html__( 'Title Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ser-details h4,{{WRAPPER}} .single-icon-service h4,{{WRAPPER}} .single-service-box h4 ',
            ]
        );

        
        $this->add_responsive_control(
            'teb_content_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ser-details h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-icon-service h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-service-box h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_title_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ser-details h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-icon-service h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-service-box h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_content_desc',
            [
            'label' => esc_html__( 'Desc', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'style' => ['style1'] ],
            ]
        );

        $this->add_control(
            'tab_content_desc_color', [

                'label'     => esc_html__( 'Desc Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .ser-details p ' => 'color: {{VALUE}};',

                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_desc_typho',
                'label'    => esc_html__( ' Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ser-details p ',
            ]
        );

        $this->add_control(
            'tab_content_desc_heightlight_color', [

                'label'     => esc_html__( 'Heighlight Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .ser-details p span' => 'color: {{VALUE}};',

                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_desc_heighlisig_typho',
                'label'    => esc_html__( 'Heighlight Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ser-details p span',
            ]
        );

        
        $this->add_responsive_control(
            'teb_content_desc_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ser-details p ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_desc_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ser-details p ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                ],
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();
        

        $this->start_controls_section('insut__tab_content_boxs',
            [
            'label' => esc_html__( 'Content box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_box_background_s',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .single-service,{{WRAPPER}} .front,{{WRAPPER}} .single-service-box',
            ]
        );
        $this->add_control(
            'item__box_hv_background_overlay_heading1',
            [
                'label' => esc_html__( 'Background Hover', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_hover_box_background_hover',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .single-service:hover,{{WRAPPER}} .back ,{{WRAPPER}} .single-service-box:hover',
            ]
        );
        $this->add_control(
            'back_flip_hover_bg_shape', [
                'condition' => [ 'style' => ['style2'] ],
                'label'		 => esc_html__( 'Hover Bottom Shape Color', 'insut-essential' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                '{{WRAPPER}} .back:after ' => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'teb_content_boxs_border_radious',
                [
                    'label' => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'min'   => 0,
                    'max'   => 200,
                    'step'  => 1,
                    
                    'selectors' => [
                        '{{WRAPPER}} .single-service' => 'border-radius: {{VALUE}}px;',
                        '{{WRAPPER}} .back' => 'border-radius: {{VALUE}}px;',
                        '{{WRAPPER}} .front' => 'border-radius: {{VALUE}}px;',
                        '{{WRAPPER}} .single-service-box' => 'border-radius: {{VALUE}}px;',
                      
                       
                ],
            ]
        ); 
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'teb_content_boxs_border_s',
				'label' => esc_html__( 'Border', 'insut-essential' ),
				'selector' => '{{WRAPPER}} .single-service,{{WRAPPER}} .front,{{WRAPPER}} .back,{{WRAPPER}} .single-service-box',
			]
		);
        $this->add_responsive_control(
            'tab_content_boxs_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .back' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-service-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_boxs_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .single-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .front' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .back' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .single-service-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_main_boxs_margin',
            [
                'label'      => esc_html__( 'Main box Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'condition' => [ 'style' => ['style2'] ],
                'selectors'  => [
                   
                    '{{WRAPPER}} .single-icon-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

       
        $this->start_controls_section('insut__main_section',
            [
            'label' => esc_html__( 'Main Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

  
        $this->add_responsive_control(
            'main_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'main_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'main_section_background',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .main-section',
            ]
        );

       $this->end_controls_section();

     
    } //Register control end

    protected function render( ) { 

        $settings     = $this->get_settings();

        $custom_service     = $settings['custom_service'];
        $service            = $settings['service'];
        $custom_service_ids = $settings['custom_service_ids'];
        $post_count         = $settings['post_count'];
        $post_title_crop    = $settings['post_title_crop'];
        $show_desc          = $settings['show_desc'];
        $desc_limit         = $settings['desc_limit'];
        $show_title_icon    = $settings['show_title_icon'];
 
        $post_sort          = $settings['post_sort'];
        $show_more_active   = $settings['show_more_active'];
        $show_more_text   = $settings['show_more_text'];
    
      
        $args = array(

            'posts_per_page'   => $post_count,
            'orderby'          => 'post_date',
            'order'            => 'DESC',
            'post_type'        => 'quomodo-service',
            'post_status'      => 'publish',
            'suppress_filters' => false,
        
        );
 
        $args['order'] = $post_sort;

        if($custom_service == 'yes'):

            $ids = explode(',',$custom_service_ids);
            $args['post__in'] = $ids;

        else:
             
             if( is_array($service) && count($service) ){
                $args['post__in'] = $service; 
             }
               
        endif;    
       
        $posts = new \WP_Query( $args );
       
    ?>    
          
        <?php if($settings['style'] == 'style1'): ?>
            <div class="row main-section">
               
                    <?php  if($posts->have_posts() ) : ?>
                                <!-- Tab Item 01 Start -->
                                <?php 

                                while ( $posts->have_posts() ) :
                                    $posts->the_post();

                                    $menu_slug = insut_meta_option(get_the_id(),'service_type_slug','x','insut_service_options');
                                   
                                    $title_icon = insut_meta_option(get_the_id(),'title_icon','','insut_service_options');
                                    $excerpt    = insut_meta_option(get_the_id(),'excerpt','','insut_service_options');
                                    $menu_id    = sanitize_title(get_the_title());
                                    $link       = get_the_permalink();
                                    $icon_cls   = 'fa fa-wifi';

                                    if( $menu_slug != '' ){

                                    $menu_id = $menu_slug;

                                    }
                                    if($settings['default_icon_enable'] != 'yes'){

                                        if( $title_icon != '' ){

                                            $icon_cls = $title_icon;
    
                                        }
                                    }
                                   
                                    $title_1      = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( get_the_title(), $post_title_crop,'' ) ); 
                                    $excerpt_content      = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( $excerpt , $desc_limit,'' ) );
                                ?> 
                                    <div class="col-lg-4 col-md-6">
                                        <!-- Single Service Start -->
                                        <div class="single-service">
                                            <div class="ser-thumb">
                                                <?php if(has_post_thumbnail()): ?>
                                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(null, $settings['thumbnail_image_size_size'])); ?>" alt="<?php the_title_attribute(); ?>">
                                                <?php endif; ?> 
                                                <a class="read-more" href="<?php echo esc_url( $link  ); ?>">
                                                <?php if( $show_more_active == 'yes' ):  ?> 
                                                  <i class="icofont-arrow-right"></i>
                                                <?php endif; ?> 
                                                </a>
                                            </div>
                                            <div class="ser-details">
                                                <h4><a href="<?php echo esc_url( $link  ); ?>"> <?php echo insut_kses($title_1); ?> </a></h4>
                                                <p>
                                                  <?php echo wpautop($excerpt_content); ?>
                                                </p>
                                            </div>
                                            <?php if($show_title_icon == 'yes'): ?>   
                                                <div class="ser-icon">

                                                    <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                                </div>
                                            <?php endif; ?> 
                                            
                                        </div>
                                        <!-- Single Service End -->
                                    </div>
                        <?php     
                            endwhile; 
                            wp_reset_postdata();
                    
                        ?>
                    <?php endif; ?>
                </div>
             
        <?php endif; ?>
        <?php if($settings['style'] == 'style2'): ?>
            <div class="row main-section">
                <?php  if($posts->have_posts() ) : ?>
                                <!-- Tab Item 01 Start -->
                                <?php 

                                while ( $posts->have_posts() ) :
                                    $posts->the_post();

                                    $menu_slug = insut_meta_option(get_the_id(),'service_type_slug','x','insut_service_options');
                                   
                                    $title_icon = insut_meta_option(get_the_id(),'title_icon','','insut_service_options');
                                    $image_icon2 = insut_meta_option(get_the_id(),'service_menu_icon','','insut_service_options');
                                    $excerpt    = insut_meta_option(get_the_id(),'excerpt','','insut_service_options');
                                    $menu_id    = sanitize_title(get_the_title());
                                    $link       = get_the_permalink();
                                    $icon_cls   = 'fa fa-wifi';
                                    $icon_cls2   = 'icofont-home';

                                    if( $menu_slug != '' ){

                                    $menu_id = $menu_slug;

                                    }
                                    if($settings['default_icon_enable'] != 'yes'){

                                        if( $title_icon != '' ){

                                            $icon_cls = $title_icon;
    
                                        }
                                    }

                                    if( $image_icon2 != '' ){

                                        $icon_cls2 = $image_icon2;

                                    }
                                   
                                    $title_1         = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( get_the_title(), $post_title_crop,'' ) );
                                    $excerpt_content = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( $excerpt , $desc_limit,'' ) );
                             
                             ?> 
                                <div class="col-lg-4 col-md-6 cus-column">
                                    <!-- Single Service Start -->
                                    <div class="single-icon-service">
                                        <div class="flipper">
                                            <div class="front">
                                               
                                                <?php if($show_title_icon == 'yes'): ?>   
                                                     <div class="ser-box-icon">
                                                        <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                                    </div>
                                                <?php endif; ?> 
                                                <h4><?php echo insut_kses($title_1); ?></h4>
                                                <a class="read-more" href="<?php echo esc_url( $link  ); ?>"><i class="icofont-arrow-right"></i></a>
                                            </div>
                                            <div class="back">
                                                <?php if($show_title_icon == 'yes'): ?>   
                                                     <div class="ser-box-icon">
                                                        <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                                    </div>
                                                <?php endif; ?> 
                                                <h4><a href="<?php echo esc_url( $link  ); ?>"><?php echo insut_kses($title_1); ?></a></h4>
                                                <a class="read-more" href="<?php echo esc_url( $link  ); ?>"><i class="icofont-arrow-right"></i></a>
                                                <div class="flip-back-icon">
                                                    <i class="<?php echo esc_attr($icon_cls2); ?>"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Service End -->
                                </div>
                                <?php     
                                    endwhile; 
                                    wp_reset_postdata();
                            
                                ?>
                    <?php endif; ?>
              
                </div>
        <?php endif; ?>
        <?php if($settings['style'] == 'style3'): ?>
               <div class="row main-section">
               <?php  if($posts->have_posts() ) : ?>
                                <!-- Tab Item 01 Start -->
                            <?php 

                                while ( $posts->have_posts() ) :
                                    $posts->the_post();

                                    $menu_slug = insut_meta_option(get_the_id(),'service_type_slug','x','insut_service_options');
                                   
                                    $title_icon = insut_meta_option(get_the_id(),'title_icon','','insut_service_options');
                                    $image_icon2 = insut_meta_option(get_the_id(),'service_menu_icon','','insut_service_options');
                                    $excerpt    = insut_meta_option(get_the_id(),'excerpt','','insut_service_options');
                                    $menu_id    = sanitize_title(get_the_title());
                                    $link       = get_the_permalink();
                                    $icon_cls   = 'fa fa-wifi';
                                    $icon_cls2   = 'icofont-home';

                                    if( $menu_slug != '' ){

                                    $menu_id = $menu_slug;

                                    }
                                    if($settings['default_icon_enable'] != 'yes'){

                                        if( $title_icon != '' ){

                                            $icon_cls = $title_icon;
    
                                        }
                                    }

                                    if( $image_icon2 != '' ){

                                        $icon_cls2 = $image_icon2;

                                    }
                                   
                                    $title_1         = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( get_the_title(), $post_title_crop,'' ) );
                                    $excerpt_content = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( $excerpt , $desc_limit,'' ) );
                             
                             ?>
                                    <div class="col-lg-4 col-md-6">
                                        <!-- Service Item Start -->
                                        <div class="single-service-box">
                                            <div class="service-img">
                                                <?php if(has_post_thumbnail()): ?>
                                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(null, $settings['thumbnail_image_size_size'])); ?>" alt="<?php the_title_attribute(); ?>">
                                                <?php endif; ?> 
                                            
                                                <?php if($show_title_icon == 'yes'): ?>   
                                                <div class="ser-post-icon">
                                                    <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                                </div>
                                                <?php endif; ?> 
                                            </div>
                                            <h4><a href="<?php echo esc_url( $link  ); ?>"><?php echo insut_kses($title_1); ?></a></h4>
                                            <a class="read-more" href="<?php echo esc_url( $link  ); ?>"> <?php echo esc_html($show_more_text); ?> <i class="icofont-arrow-right"></i></a>
                                        </div>
                                        <!-- Service Item End -->
                                    </div>
                            <?php     
                                endwhile; 
                                wp_reset_postdata();
                        
                            ?>
                    <?php endif; ?>
                </div>
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }

    protected function get_service_list(){
        $_list = [];
        $args = array(
              'numberposts'      => -1,
              'orderby'          => 'post_date',
              'order'            => 'DESC',
              'post_type'        => 'quomodo-service',
              'post_status'      => 'publish',
              'suppress_filters' => false
        );
  
        $services = get_posts($args);
   
        if($services):
         // Loop the posts
           foreach ($services as $feature):
             $_list[$feature->ID] = $feature->post_title; 
           endforeach;
        endif;
  
        return $_list;  
    }
}