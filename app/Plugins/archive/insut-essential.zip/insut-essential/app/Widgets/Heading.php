<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Heading extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-heading';
    }

    public function get_title() {
        return esc_html__( 'Insut Heading', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fas fa-heading';
    }

    public function get_categories() {
        return [ 'appscred-elements' ];
    }
    public function layout(){
        return[
            
            'section-title'   => esc_html__( 'Standard', 'insut-essential' ),
            'section-title-4' => esc_html__( 'Creative', 'insut-essential' ),
            'augmented'       => esc_html__( 'Augmented', 'insut-essential' ),
            'icon'            => esc_html__( 'Icon', 'insut-essential' ),
    
        ];
    }
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'section-title',
                    'options' => $this->layout(),
                ]
            );
        
            $this->add_control(
                'top_title', [
                    'label'       => esc_html__( 'Top Title', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Get in ', 'insut-essential' ),
                    'default'     => esc_html__( 'Service We Offer ', 'insut-essential' ),
                
                    
                ]
            ); 

            $this->add_control(
                'title', [
                    'label'       => esc_html__( 'Title text', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Get in ', 'insut-essential' ),
                    'default'     => esc_html__( 'Get Best {Advertiser} In Your Side Pocket ', 'insut-essential' ),
                
                    
                ]
            );

            $this->add_control(
                'sub_content', [
                    'label'       => esc_html__( 'Sub Content', 'insut-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Sub content here', 'insut-essential' ),
                    'condition' => [ 'style' => ['augmented'] ],
                
                    
                ]
            );

        $this->add_control(
            'heading_type',
                [
                    'label'   => esc_html__( 'Heading type', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'h3',
                    'options' => [
                        'h1' => esc_html__( 'H1', 'insut-essential' ),
                        'h2' => esc_html__( 'H2', 'insut-essential' ),
                        'h3' => esc_html__( 'H3', 'insut-essential' ),
                        'h4' => esc_html__( 'H4', 'insut-essential' ),
                        'h5' => esc_html__( 'H5', 'insut-essential' ),
                        'h6' => esc_html__( 'H6', 'insut-essential' ),
                        'p'  => esc_html__( 'P', 'insut-essential' ),
                    ],
                ]
            );

            $this->add_control(
                'heading_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition' => [ 'style' => ['icon'] ],
                ]
            );
     
            $this->add_responsive_control(
                'title_align', [
                    'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'insut-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'insut-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'insut-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                    ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'insut-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                    'default' => 'center',
                    'selectors' => [
                        '{{WRAPPER}} .section-title'   => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .section-title-4' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .about-7-content' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .section-title-5' => 'text-align: {{VALUE}};',
                    ],
                ]
            );//Responsive control end
        $this->end_controls_section();

       
  
        //Title Style Section
	
        $this->start_controls_section(
			'section_top_title_style', [
				'label' => esc_html__( 'Top Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
        $this->add_control(
			'left_border_color', [

				'label'		 => esc_html__( 'Left line color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title-4 > span::before' => 'background: {{VALUE}};',
                 
                ],
                'condition' => [ 'style' => ['section-title','section-title-4'] ],
			]
        );
        $this->add_control(
			'right_border_color', [

				'label'		 => esc_html__( 'Right line color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title-4 > span::after' => 'background: {{VALUE}};',
                 
                ],
                'condition' => [ 'style' => ['section-title','section-title-4'] ],
			]
        );

        $this->add_responsive_control(
			'border_line_pos',
			[
				'label' => esc_html__( 'Line Top Position', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section-title-4 > span::before' => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-title-4 > span::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [ 'style' => ['section-title','section-title-4'] ],
			]
        );
        $this->add_responsive_control(
			'border_line_gap',
			[
				'label' => esc_html__( 'Line text Gap', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-4 > span::before' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-title-4 > span::after' => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [ 'style' => ['section-title','section-title-4'] ],
			]
        );
       
        $this->add_group_control(
			Group_Control_Border:: get_type(),
			[
				'name' => 'top_title_border',
				'label' => esc_html__( 'Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title,{{WRAPPER}} .top-title',
               
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
                [
                    'name' => 'top_title_gradient_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title,{{WRAPPER}} .top-title',
                  
                   
                ]
        );

        $this->add_control(
			'top_title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .top-title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .top-title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .top-title' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'top_title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .section-title .top-title,{{WRAPPER}} .section-title-4 .top-title,{{WRAPPER}} .top-title',
            ]
        );
        $this->add_responsive_control(
            'top_title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'top_title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

       
        $this->end_controls_section();
        $this->start_controls_section(
			'section_icon_box_style', [
				'label' => esc_html__( 'Icon Box', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'style' => ['icon'] ],
			]
        );

        $this->add_control(
            'heading_icon_color_background', [

                'label'     => esc_html__( 'Icon background shape color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                
                'selectors' => [
                '{{WRAPPER}} .section-title-5 .icon ' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'heading_box_icon_color', [

                'label'     => esc_html__( 'Box Icon color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .section-title-5 .icon svg path' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .section-title-5 .icon i' => 'color: {{VALUE}};',
              
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'heading_box_icons_typhography',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .section-title-5 .icon i,{{WRAPPER}} .section-title-5 .icon svg',
               
            ]
        );
        $this->add_responsive_control(
            'icon__box_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'insut-essential' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .section-title-5 .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
			'heading_box_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-5 .icon' => 'width: {{SIZE}}{{UNIT}};',
		
					
				],
			]
        );

        $this->add_responsive_control(
			'heading_box_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'insut-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .section-title-5 .icon' => 'height: {{SIZE}}{{UNIT}};',
			
					
				],
			]
        );
        $this->end_controls_section();

        
        $this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

       
        $this->add_group_control(
			Group_Control_Border:: get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'insut-essential' ),
                'selector' => '{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title,{{WRAPPER}} .title',
               
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
                [
                    'name' => 'gradient_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title,{{WRAPPER}} .title',
                  
                   
                ]
        );

        $this->add_control(
			'title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .title' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .section-title .title,{{WRAPPER}} .section-title-4 .title,{{WRAPPER}} .title',
               
            ]
        );
        $this->add_control(
            'bold_text_heading1',
            [
                'label' => esc_html__( 'Normal Text', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
			'bold_text_title_color', [

				'label'		 => esc_html__( 'Title color', 'insut-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .section-title .title span' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .section-title-4 .title span' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'bold_text_title_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .section-title .title span,{{WRAPPER}} .section-title-4 .title span,{{WRAPPER}} .title span',
            
            ]
        );

        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title-4 .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

       
        $this->end_controls_section();

        $this->start_controls_section(
			'section_sub_title_style', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'style' => ['augmented'] ],
			]
        );

            $this->add_control(
                'sub_title_color', [

                    'label'		 => esc_html__( 'Color', 'insut-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sub-content' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'sub_title_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .sub-content',
                
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} .sub-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} .sub-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('appscred__main_section',
            [
            'label' => esc_html__( 'Main Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

  
        $this->add_responsive_control(
            'main_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .about-7-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'main_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .about-7-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .section-title-5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'main_section_background',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .section-title-5,{{WRAPPER}} .about-7-content,{{WRAPPER}} .section-title-4,{{WRAPPER}} .section-title',
            ]
        );

$this->end_controls_section();

     
    } //Register control end

    protected function render( ) { 

		$settings     = $this->get_settings();
		$title        = $settings['title'];
		$title_1      = str_replace(['{', '}'], ['<span>', '</span>'], $title);
       
    ?>    
          
        <?php if($settings['style'] == 'augmented'): ?>
                    <div class="about-7-content">
                        <?php if($settings['top_title'] !=''): ?>
                           <span class="top-title"><?php echo appscred_kses($settings['top_title']); ?></span>
                        <?php endif; ?>
                        <<?php echo esc_attr($settings['heading_type']); ?> class="title">
                           <?php echo appscred_kses($title_1); ?>
                        </<?php echo esc_attr($settings['heading_type']); ?>>
                        <?php if($settings['sub_content'] !=''): ?>
                           <p class="sub-content"> <?php echo appscred_kses($settings['sub_content']); ?> </p>
                        <?php endif; ?>
                    </div> <!-- about 7 content -->
        <?php elseif($settings['style'] == 'icon'): ?>
            <div class="section-title-5">
                <div class="icon">
                    <?php \Elementor\Icons_Manager::render_icon( $settings['heading_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
                <<?php echo esc_attr($settings['heading_type']); ?> class="title"><?php echo appscred_kses($title_1); ?></<?php echo esc_attr($settings['heading_type']); ?>>
            </div>            
        <?php else: ?>
            <div class="<?php echo esc_attr($settings['style']); ?>">
               <span class="top-title"><?php echo appscred_kses($settings['top_title']); ?></span>
               <<?php echo esc_attr($settings['heading_type']); ?> class="title"><?php echo appscred_kses($title_1); ?></<?php echo esc_attr($settings['heading_type']); ?>>
            </div> <!-- SECTION TITLE --> 
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}