<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class Intro_Banner extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-intro-banner';
    }

    public function get_title() {
        return esc_html__( 'Intro Banner Form', 'insut-essential' );
    }

    public function get_icon() { 
        return "fab fa-adversal";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );
            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Form Tab Slide', 'insut-essential' ),
                       
            
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__('Intro Banner Content', 'insut-essential'),
            ]
        );
 
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_nav', [
				'label' => esc_html__( 'Tab Menu', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Nav Title' , 'insut-essential' ),
				'label_block' => true,
			]
        );
        
        

        $repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_content', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'List Content' , 'insut-essential' ),
				'show_label' => true,
			]
        );


		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Content List', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( 'Title #1', 'insut-essential' ),
						
					],
					
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

      $this->end_controls_section();
      $this->start_controls_section(
            'section_content_form_tab',
            [
                'label' => esc_html__('Form Fields', 'insut-essential'),
            ]
        );

        
            $this->add_control(
                'form_action', [
                    'label' => esc_html__( 'Find Page Url', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'form_agents', [
                    'label' => esc_html__( 'Agents', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => esc_html__( 'agent 1, agent 2' , 'insut-essential' ),
                    'show_label' => true,
                ]
            );
            $this->add_control(
                'form_location_placeholder', [
                    'label' => esc_html__( 'Location Placeholder', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Rosebelt Street ,USA' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );
        
            $this->add_control(
                'form_submit_text', [
                    'label' => esc_html__( 'Submit text', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Find' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'form_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                ]
            );

      $this->end_controls_section();

      $this->start_controls_section(
            'section_slider_tab',
            [
                'label' => esc_html__('Slider', 'insut-essential'),
            
            ]
        );

        $this->add_control(
            'autoplay', [
                'label'     => esc_html__('AutoPlay', 'insut-essential'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__('Yes', 'insut-essential'),
                'label_off' => esc_html__('No', 'insut-essential'),
            ]
        );

        $this->add_control(
            'autoplay_speed', [
                'label' => esc_html__( 'Autoplay spead', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'label_block' => false,
                'show_label' => true,
            ]
        );

        $this->add_control(
            'progressbar', [
                'label'     => esc_html__('Progressbar', 'insut-essential'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__('Yes', 'insut-essential'),
                'label_off' => esc_html__('No', 'insut-essential'),
            ]
        );


      $this->end_controls_section();

       //Nav Style Section
		$this->start_controls_section(
			'section_tab_nav_style', [
				'label' => esc_html__( 'Nav', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );

        $this->add_control(
            'nav_menu_color', [

                'label'     => esc_html__( 'Nav color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .slider-nav-tab.slick-initialized .slick-slide li' => 'color: {{VALUE}};',
                '{{WRAPPER}} .slider-nav-tab.slick-initialized .slick-slide:after' => 'background: {{VALUE}};',
      
                ],
            ]
        );

        $this->add_control(
            'nav_menu_active_color', [

                'label'     => esc_html__( 'Active color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .slider-nav-tab.slick-initialized .slick-slide.slick-current.slick-center li' => 'color: {{VALUE}};',
      
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'nav_menu_typho',
                'label'    => esc_html__( 'Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .slider-nav-tab.slick-initialized .slick-slide li',
            ]
        );

        $this->add_responsive_control(
            'nav_menun_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .slider-nav-tab.slick-initialized .slick-slide li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'nav_menun_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .slick-slider .slick-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator' => 'before',
            ]
        );

      $this->end_controls_section();

      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-slider-item h2' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .hero-slider-item h2',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Sub Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-slider-item p' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .hero-slider-item p',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        
        // button 
        $this->start_controls_section(
			'section_form_select_style', [
				'label' => esc_html__( 'Form Style', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
               
			]
        );
                $this->add_control(
                    'agent_color1', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .agent-address input[type="search"]' => 'color: {{VALUE}};',
                            '{{WRAPPER}} .select-agent .select2-container--default .select2-selection--single .select2-selection__rendered' => 'color: {{VALUE}};',
                            '{{WRAPPER}} .select2-container--default .select2-selection--single .select2-selection__arrow b' => 'border-color: {{VALUE}} transparent transparent transparent;; ',
                           
                        ],
                    ]
                );

               
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho1',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .select-agent .select2-container--default .select2-selection--single .select2-selection__rendered ,.agent-address input[type="search"]',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding1',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item .insut-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin1',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-slider-item .insut-form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading1',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background1',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .hero-slider-item .insut-form',
                    ]
                );
             

              
                $this->add_control(
                    'button_section_border_radius1',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .hero-slider-item .insut-form' => 'border-radius: {{VALUE}}px;',
                              
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border1',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .hero-slider-item .insut-form',
                    ]
                );


        $this->end_controls_section();

        $this->start_controls_section(
			'section_submit_button_style', [
				'label' => esc_html__( ' Submit Button ', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
            ]
            
        );
                $this->add_control(
                    'button_color2', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .agent-address .insut-btn ' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv2', [

                        'label'     => esc_html__( 'Hover color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .agent-address .insut-btn:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho2',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .agent-address .insut-btn ',
                    ]
                );

                $this->add_control(
                    'button_icon_color2', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .agent-address .insut-btn i' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_icon_typho2',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .agent-address .insut-btn i',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .agent-address .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .agent-address .insut-btn',
                    ]
                );
                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Background hover color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input__section_hv_background_2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .agent-address .insut-btn:after',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .agent-address .insut-btn' => 'border-radius: {{VALUE}}px;',
                               
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border2',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .agent-address .insut-btn',
                    ]
                );


        $this->end_controls_section();
        
        $this->start_controls_section('insut_progressbar_section',
            [
            'label' => esc_html__( 'Progress', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'progressbar_background_2',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .hero-slider .slick-dots ',
            ]
        );
        $this->add_control(
            'progress__heading__2',
            [
                'label' => esc_html__( 'Background active', 'insut-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'progressbar_background_active_23',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .hero-slider .slick-dots li.slick-active:after',
            ]
        );

        $this->add_responsive_control(
            'progressbar__margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero-slider .slick-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
        
      
		
        $this->start_controls_section('appscred_box_section',
            [
            'label' => esc_html__( ' Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

     $this->end_controls_section();
      
    } //Register control end

    protected function render( ) { 

		$settings                  = $this->get_settings();
		$list                      = $settings['list'];
		$form_agents               = $settings['form_agents'];
		$form_location_placeholder = $settings['form_location_placeholder'];
		$form_submit_text          = $settings['form_submit_text'];
		$form_action               = $settings['form_action'];
		$form_icon                 = $settings['form_icon'];
	
		$form_agent_option  = $form_agents == ''?[]:explode(',',$form_agents); 
        $slide_controls = [
            'autoplay'       => $settings['autoplay']=='yes'?true:false,
            'progressbar'    => $settings['progressbar']=='yes'?true:false,
            'autoplay_speed' => $settings['autoplay_speed']==''?2000:$settings['autoplay_speed'],
        ];
       
    
    ?>
        <!--====== BANNER PART START ======-->
    <?php if($settings['layout'] == 'style1'): ?>
       <!-- Slider Section Start -->
       <section class="slider-01 main-section" >
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-10">
                        <ul class="slider-nav-tab">

                            <?php foreach($list as $nav): ?>
                                <li role="presentation"> <?php echo esc_html( $nav['list_nav'] ); ?> </li>
                            <?php endforeach; ?>
                           
                        </ul>
                        <div class="hero-slider" data-progressbar='<?php echo esc_attr($slide_controls['progressbar']); ?>' data-autoplay='<?php echo esc_attr($slide_controls['autoplay']); ?>' data-speed='<?php echo esc_attr($slide_controls['autoplay_speed']); ?>'>
                            <?php foreach($list as $item): ?>
                                <div class="hero-slider-item">
                                    <h2> <?php echo esc_html($item['list_title']); ?> </h2>
                                    <p>
                                        <?php echo esc_html($item['list_content']); ?>
                                    <p>
                                    <form class="insut-form" action="<?php echo esc_url($form_action); ?> " method="post">
                                        <input type="hidden" name="type" value="agent-address">
                                        <div class="select-agent">
                                            <select name="agent">
                                                <?php foreach($form_agent_option as $k_valeu => $option): ?>
                                                    <option value="<?php echo esc_attr( $option ); ?>"> <?php echo esc_html( $option ); ?> </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="agent-address">
                                            <input type="search" name="c_search" placeholder="<?php echo esc_attr( $form_location_placeholder ); ?>">
                                            <button class="insut-btn" type="submit">
                                                <?php if( $form_icon['value'] == '' ): ?>
                                                    <i class="icofont-airplane"></i>
                                                <?php else: ?>   
                                                    <?php \Elementor\Icons_Manager::render_icon( $form_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                <?php endif; ?>   
                                               
                                                <?php echo esc_html( $form_submit_text ) ?></button>
                                        </div>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>  
        <!-- Slider Section End -->
   
    <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}