<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use AppscredEssential\Base\Repository\Post_Slider_Model;
if ( ! defined( 'ABSPATH' ) ) exit;

class Block_Slider extends Widget_Base {

  public $base;

    public function get_name() {
        return 'insut-post-block-slider';
    }

    public function get_title() {
        return esc_html__( 'Block Slider', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fa fa-sliders';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'insut-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                  'title'      => esc_html__( 'Style 1', 'insut-essential' ),
                  'imagelarge' => INSUT_IMG . '/admin/layouts/sliders/block-slider-1.png',
                  'imagesmall' => INSUT_IMG . '/admin/layouts/sliders/block-slider-1.png',
                  'width'      => '100%',
               ],

              
         
           ],

         ]
       ); 
       $this->end_controls_section();
       
        $this->start_controls_section('appscred_blockp_title_section',
        [
           'label'     => esc_html__( 'Heading', 'insut-essential' ),
           'condition' => [ 'block_style' => ['style','style4','style5','style7'] ]
        ]
       );
            $this->add_control(
               'heading',
               [
               'label'   => esc_html__( 'Title', 'insut-essential' ),
               'type'    => Controls_Manager::TEXT,
               'default' => esc_html__( 'Slider Post', 'insut-essential' ),
               
               ]
            );
            $this->add_control(
               'show_heading_border',
               [
                   'label'     => esc_html__('Hide border', 'insut-essential'),
                   'type'      => Controls_Manager::SWITCHER,
                   'label_on'  => esc_html__('Yes', 'insut-essential'),
                   'label_off' => esc_html__('No', 'insut-essential'),
                   'default'   => '',
                   'condition' => [ 'block_style' => ['style1'] ],
                   'selectors' => [
                     '{{WRAPPER}} .widget-title:before' => 'display: none;',
                    
                  ],
               ]
           );
       $this->end_controls_section();

       do_action( 'appscred_section_slider_tab', $this , $this->get_name()); 
       do_action( 'appscred_section_general_block_slider_tab', $this, $this->get_name() );
       do_action( 'appscred_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'appscred_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'appscred_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'appscred_section_sort_tab', $this , $this->get_name());  
       do_action( 'appscred_section_sticky_tab', $this , $this->get_name());  
       
        // Style
            $this->start_controls_section('appscred_style_heading_section',
            [
               'label'     => esc_html__( 'Heading', 'insut-essential' ),
               'tab'       => Controls_Manager::TAB_STYLE,
               'condition' => [ 'block_style' => ['style'] ]
            ]
            );

                  $this->add_group_control(
                     \Elementor\Group_Control_Background:: get_type(),
                     [
                        'name'        => 'heading_border_background',
                        'label'       => esc_html__( 'Background', 'insut-essential' ),
                        'types'       => [ 'gradient' ],
                        'selector'    => '{{WRAPPER}} .widget-title:before',
                        'condition'   => [ 'block_style' => ['style1'] ],
                        'label_block' => true
                     ]
                  );

                  $this->add_responsive_control(
                     'heading_border_height',
                     [
                        'label'      => esc_html__( 'Border height', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'condition'  => [ 'block_style' => ['style1'] ],
                        'size_units' => [ 'px' ],
                        'range'      => [
                           'px' => [
                              'min'  => 0,
                              'max'  => 50,
                              'step' => 1,
                           ],
                        
                        
                        ],
                     
                        'selectors' => [
                           '{{WRAPPER}} .widget-title:before' => 'height: {{SIZE}}{{UNIT}};',
                        
                        ],
                     ]
                  );

                  $this->add_responsive_control(
                     'heading_border_width',
                     [
                        'label'      => esc_html__( 'Border width', 'insut-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'condition'  => [ 'block_style' => ['style1'] ],
                        'size_units' => [ 'px' ],
                        'range'      => [
                           'px' => [
                              'min'  => 0,
                              'max'  => 50,
                              'step' => 1,
                           ],
                        ],
                     
                        'selectors' => [
                           '{{WRAPPER}} .widget-title:before' => 'width: {{SIZE}}{{UNIT}};',
                        
                        ],
                     ]
                  );
      
                  $this->add_control(
                     'block_heading_color',
                     [
                        'label'   => esc_html__('Color', 'insut-essential'),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '',
                     
                        'selectors' => [
                           '{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
                        ],
                     ]
                  );

                
                  $this->add_group_control(
                     Group_Control_Typography:: get_type(),
                     [
                        'name'     => 'post_heading_typography',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .widget-title',
                     ]
                  );
                  $this->add_responsive_control(
                  'heading_margin',
                  [
                     'label'      => esc_html__( 'Title Margin', 'insut-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}}  .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
                  );
                  $this->add_responsive_control(
                     'heading_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
                  );
            $this->end_controls_section();
        $this->start_controls_section('appscred_style_title_section',
        [
           'label' => esc_html__( 'Title', 'insut-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'insut-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .theme-4 .single_international .title a'   => 'color: {{VALUE}};',
                     '{{WRAPPER}} .theme-4 .single_post_text .title a ' => 'color: {{VALUE}};',
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'insut-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .theme-4 .single_international .title a:hover'       => 'color: {{VALUE}};',
                     '{{WRAPPER}} .theme-4 .single_post_text .title a:hover' => 'color: {{VALUE}};',
                
                  ],
               ]
            );
            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'insut-essential' ),
                  'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                  'selector' => '{{WRAPPER}} .title a',
                 
               ]
            );
            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}} .theme-4 .single_international .title'       => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   '{{WRAPPER}} .theme-4 .single_post_text .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
             ]
            );
            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .theme-4 .single_international .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     '{{WRAPPER}} .theme-4 .single_post_text .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                  ],
               ]
            );
      $this->end_controls_section();

      $this->start_controls_section('appscred__post_content_section',
         [
            'label'     => esc_html__( 'Content ', 'insut-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'block_style' => ['style1','style44'] ]
         ]
     );

         $this->add_control(
            'block_content_color',
            [
               'label'   => esc_html__('Color', 'insut-essential'),
               'type'    => Controls_Manager::COLOR,
               'default' => '',
               
               'selectors' => [
                  '{{WRAPPER}} .theme-4 .single_international p' => 'color: {{VALUE}};',
               ],
            ]
         );

        
         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'post_content_typography',
               'label'    => esc_html__( 'Typography', 'insut-essential' ),
               'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
               'selector' => '{{WRAPPER}} .theme-4 .single_international p',
            ]
         );
         $this->add_responsive_control(
         'content_margin',
         [
            'label'      => esc_html__( 'Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .theme-4 .single_international p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'content_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .theme-4 .single_international p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();
      $this->start_controls_section('appscred_style_pcontent_section',
      [
         'label'     => esc_html__( 'Post meta', 'insut-essential' ),
         'tab'       => Controls_Manager::TAB_STYLE,
         'condition' => [ 'block_style' => ['style1','style2','style3','style6','style7'] ]
      ]
     );
         $this->add_control(
               'show_post_meta',
               [
                  'label'     => esc_html__('Show meta', 'insut-essential'),
                  'type'      => Controls_Manager::SWITCHER,
                  'label_on'  => esc_html__('Yes', 'insut-essential'),
                  'label_off' => esc_html__('No', 'insut-essential'),
                  'default'   => 'yes',
                  'condition' => [ 'block_style' => ['style1','style2','style3'] ]
               ]
         );

         $this->add_control(
            'post_meta_color',
               [
                  'label'     => esc_html__('Author and date color', 'insut-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'condition' => [ 'block_style' => ['style2','style3'] ],
                  'selectors' => [
                     '{{WRAPPER}} .single_post_text .meta span' => 'color: {{VALUE}};',
                     
                 
                  ],
               ]
            ); 
 
            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'      => 'meta_other_typography',
                  'condition' => [ 'block_style' => ['style2','style3'] ],
                  'label'     => esc_html__( ' Date and author Typography', 'insut-essential' ),
                  'scheme'    => Scheme_Typography::TYPOGRAPHY_1,
                  'selector'  => '{{WRAPPER}} .single_post_text .meta span , {{WRAPPER}} .single_post_text .meta2 a.date , {{WRAPPER}} .single_post_text .meta4 a.date',
               
               ]
         );  

         $this->add_control(
            'meta_border_background_label',
            [
               'label'     => esc_html__( 'Meta Border Background', 'insut-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
               'condition' => [ 'block_style' => ['style1','style2'] ],
            ]
         );
         $this->add_control(
            'show_meta__border',
            [
                'label'     => esc_html__('Hide Meta Border', 'insut-essential'),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__('Yes', 'insut-essential'),
                'label_off' => esc_html__('No', 'insut-essential'),
                'default'   => '',
                'condition' => [ 'block_style' => ['style2','style3'] ],
                'selectors' => [
                  '{{WRAPPER}} .theme-4 .meta.meta_style4:after' => 'display: none;',
                  '{{WRAPPER}} .theme-4 .meta.before:before' => 'display: none;',
                 
               ],
            ]
        );
         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'meta_border_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'gradient' ],
               'selector' => '{{WRAPPER}} .theme-4 .meta.meta_style4:after,{{WRAPPER}} .theme-4 .meta.before:before',
               
               'label_block' => true
            ]
         );

         $this->add_responsive_control(
            'meta_border_height',
            [
               'label'      => esc_html__( 'Border height', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'condition'  => [ 'block_style' => ['style1','style2','style3'] ],
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .theme-4 .meta.meta_style4:after' => 'height: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .meta.before:before' => 'height: {{SIZE}}{{UNIT}};',
                 
               ],
            ]
         );

         $this->add_responsive_control(
            'meta_border_width',
            [
               'label'      => esc_html__( 'Border width', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'condition'  => [ 'block_style' => ['style1','style2','style3'] ],
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 50,
                     'step' => 1,
                  ],
                
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .theme-4 .meta.meta_style4:after' => 'width: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .meta.before:before' => 'width: {{SIZE}}{{UNIT}};',
                 
               ],
            ]
         );

         $this->add_control(
            'post_category_color',
               [
                  'label'     => esc_html__('Category Color', 'insut-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [

                     '{{WRAPPER}} .theme-4 .single_international a.cat' => 'color: {{VALUE}};',
                     '{{WRAPPER}} .theme-4 .single_post_text a.cat'     => 'color: {{VALUE}};',
                 
                  ],
               ]
         ); 

         $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'meta_category_typography',
                  'label'    => esc_html__( 'Category Typography', 'insut-essential' ),
                  'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                  'selector' => '{{WRAPPER}} a.cat',
               
                  
               ]
         );

            $this->add_responsive_control(
               'post__meta_margin',
               [
                  'label'      => esc_html__( 'Footer Meta Margin', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  
                  'selectors' => [
                     '{{WRAPPER}} .business_carousel_items .like_cm' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                  ],
                  'condition' => [ 'block_style' => 'style1' ],
               ]
         );

         $this->add_control(
            'view_reaction_icon_color',
            [
               'label'     => esc_html__('Footer Icon Color', 'insut-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
                  '{{WRAPPER}}  .business_carousel_items .like_cm li i' => 'color: {{VALUE}};',
              
               
               ],
               'condition' => [ 'block_style' => 'style1' ],
            ]
         );
         $this->add_control(
            'view_reaction_icon_hv_color',
            [
               'label'     => esc_html__('Footer Icon Hover Color', 'insut-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
                  '{{WRAPPER}} .business_carousel_items .like_cm li:hover i' => 'color: {{VALUE}};',
               
               ],
               'condition' => [ 'block_style' => 'style1' ],
            ]
         );
      

         $this->add_control(
            'view_reaction_color',
            [
               'label'     => esc_html__('Footer meta Color', 'insut-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
                  '{{WRAPPER}} .business_carousel_items .like_cm li' => 'color: {{VALUE}};',
               
               ],
               'condition' => [ 'block_style' => 'style1' ],
            ]
         );

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'      => 'video_post_text_typography',
               'label'     => esc_html__( 'Footer meta Typography', 'insut-essential' ),
               'scheme'    => Scheme_Typography::TYPOGRAPHY_1,
               'selector'  => '{{WRAPPER}} .business_carousel_items .like_cm li',
               'condition' => [ 'block_style' => 'style1' ],
            ]
         );

         $this->add_responsive_control(
            'post_text_meta_margin',
               [
                  'label'      => esc_html__( 'Margin', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'condition'  => [ 'block_style' => 'style2' ],
                  'selectors'  => [
                     '{{WRAPPER}} .theme-4 .meta.meta_style4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  ],
               ]
         );

         $this->add_responsive_control(
            'post_text_meta_padding',
               [
                  'label'      => esc_html__( 'Padding', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'condition'  => [ 'block_style' => 'style2' ],
                  'selectors'  => [
                     '{{WRAPPER}} .theme-4 .meta.meta_style4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  ],
               ]
         );
     
     $this->end_controls_section();
 
      $this->start_controls_section('appscred_image_section',
         [
            'label' => esc_html__( 'Image / Number', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
      $this->add_responsive_control(
         'image_margin',
         [
            'label'      => esc_html__( ' Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .theme-4 .single_international img'     => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               '{{WRAPPER}} .theme-4 .image_carousel .post_img img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               '{{WRAPPER}} .theme-4 .owl-carousel .owl-item img'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .theme-4 .single_international img'     => 'height: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .image_carousel .post_img img' => 'height: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .owl-carousel .owl-item img'   => 'height: {{SIZE}}{{UNIT}};',
               ],
               
            ]
         );
         
         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image width', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
               'selectors' => [
                  '{{WRAPPER}} .theme-4 .single_international img'     => 'width: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .image_carousel .post_img img' => 'width: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .owl-carousel .owl-item img'   => 'width: {{SIZE}}{{UNIT}};',
               ],
              
            ]
         ); 
         $this->add_responsive_control(
            'img_borders__radius',
            [
               'label'      => esc_html__( 'Image Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .theme-4 .single_international img'      => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .image_carousel .post_img img'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .owl-carousel .owl-item img'    => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .owl-carousel .border-radious7' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                  
               ],
            ]
         );

         $this->add_control(
            'post_image_overlay_c_heading',
            [
               'label'     => __( 'Overlay color', 'insut-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
               'condition' => [ 'block_style' => ['style2','style3'] ]
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
               'name'      => 'post_image_overlay_color',
               'label'     => esc_html__( 'Background', 'insut-essential' ),
               'types'     => [ 'gradient' ],
               'selector'  => '{{WRAPPER}}  .single_post .gradient1::after',
               'condition' => [ 'block_style' => ['style2','style3'] ]
            ]
         );
         
         $this->add_control(
            'post_image_overlay_opecity',
            [
               'label'      => esc_html__( 'Opacity', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 1,
                     'step' => .1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}}  .single_post .gradient1::after' => 'opacity: {{SIZE}};',
               ],
               'condition' => [ 'block_style' => ['style2','style3'] ]
              
            ]
         );
      $this->end_controls_section();

      $this->start_controls_section('appscred_single_box_section',
         [
            'label'     => esc_html__( 'Post box item', 'insut-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
          
         ]
      );

         $this->add_responsive_control(
            'item_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               
               'selectors' => [
                  
                  '{{WRAPPER}} .single__blog__post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                  
               ],
            ]
         );
  
         $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow:: get_type(),
            [
               'name'     => 'single_post_box_shadow',
               'label'    => esc_html__( 'Box Shadow', 'insut-essential' ),
               'selector' => '{{WRAPPER}} .single__blog__post',
            ]
         );
      
         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'single_box_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .single__blog__post,{{WRAPPER}} .signle__blog__content ',
            ]
         );
      
        $this->add_responsive_control(
         'single_box_margin',
         [
            'label'      => esc_html__( 'Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .single__blog__post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );

         $this->add_responsive_control(
            'single_box_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .single__blog__post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

         
      $this->end_controls_section();

      $this->start_controls_section('appscred_box_section',
         [
            'label' => esc_html__( ' Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
      $this->add_control(
         'show_border',
         [
             'label'     => esc_html__('Show border bottom', 'insut-essential'),
             'type'      => Controls_Manager::SWITCHER,
             'label_on'  => esc_html__('Yes', 'insut-essential'),
             'label_off' => esc_html__('No', 'insut-essential'),
             'default'   => 'no',
             'condition' => [ 'block_style' => ['style5'] ]
         ]
     );
      $this->add_group_control(
         \Elementor\Group_Control_Border:: get_type(),
         [
             'name'      => 'border_post_bottom',
             'label'     => esc_html__( 'Border', 'insut-essential' ),
             'selector'  => '{{WRAPPER}} .border_black',
             'condition' => [ 'show_border' => 'yes','block_style'=> ['style5'] ]
         ]
      );

         $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        


        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );
         $this->add_responsive_control(
            'item_borders__radius',
            [
               'label'      => esc_html__( ' Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                 
                  '{{WRAPPER}} .theme-4 .single_post ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                  
               ],
               'condition' => [ 'block_style' => 'style2' ]
            ]
         );
      $this->end_controls_section();

      $this->start_controls_section('appscred_style_slider_nav',
        [
           'label' => esc_html__( 'Navigation', 'insut-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
        
        $this->add_control(
           'nav_color',
           [
              'label'     => esc_html__('Color', 'insut-essential'),
              'type'      => Controls_Manager::COLOR,
              'selectors' => [
                 '{{WRAPPER}} .owl-nav i' => 'color: {{VALUE}};',
               
              ],
              'condition' => [ 'block_style' => ['style1','style2'] ]
           ]
        );

        $this->add_control(
         'nav_hvcolor',
         [
            'label'     => esc_html__('Hover color', 'insut-essential'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
               '{{WRAPPER}} .owl-nav:hover i' => 'color: {{VALUE}};',
             
            ],
            'condition' => [ 'block_style' => ['style1','style2'] ]
         ]
      );

      $this->add_control(
			'nav_background_heading',
			[
				'label'     => esc_html__( 'Nav background', 'insut-essential' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
      );
      
        $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'nav_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient' ],
               'selector' => '{{WRAPPER}} .owl-nav div,{{WRAPPER}} .owl-nav div,{{WRAPPER}} .theme-4 .dots_style1 .owl-dots > div',
            ]
         );

         $this->add_control(
            'nav_active_background_heading',
            [
               'label'     => esc_html__( 'Nav Active background', 'insut-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'after',
               'condition' => [ 'block_style' => ['style3'] ]
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'      => 'navactiv_background',
                  'label'     => esc_html__( 'Background', 'insut-essential' ),
                  'types'     => [ 'classic', 'gradient' ],
                  'selector'  => '{{WRAPPER}} .theme-4 .dots_style1 .owl-dots div.active',
                  'condition' => [ 'block_style' => ['style3'] ]
               ]
            );
         
         $this->add_control(
            'nav_hvbackground_heading',
            [
               'label'     => esc_html__( 'Nav Hover background', 'insut-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'after',
               'condition' => [ 'block_style' => ['style1','style2'] ]
            ]
         );   
         $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'      => 'nav_hv_background',
               'label'     => esc_html__( 'Background', 'insut-essential' ),
               'types'     => [ 'classic', 'gradient' ],
               'selector'  => '{{WRAPPER}}  .owl-nav div:hover',
               'condition' => [ 'block_style' => ['style1','style2'] ]
            ]
	   	);
 
        
         $this->add_control(
            'nav_width',
            [
               'label'      => esc_html__( 'Width', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 5,
                     'max'  => 200,
                     'step' => 1,
                  ],
                 
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .owl-nav div '                          => 'width: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .theme-4 .dots_style1 .owl-dots > div ' => 'width: {{SIZE}}{{UNIT}};',
                 
               ],
            ]
         );
   

         $this->add_responsive_control(
            'nav_border_radius',
            [
               'label'      => esc_html__( 'Border radius', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .owl-nav div'                          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                  '{{WRAPPER}} .theme-4 .dots_style1 .owl-dots > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                 
                  
               ],
            ]
           );
         
        $this->end_controls_section();
        $this->start_controls_section('appscred_slider_content_nav',
        [
           'label'     => esc_html__( 'Slider Section', 'insut-essential' ),
           'tab'       => Controls_Manager::TAB_STYLE,
           'condition' => [ 'block_style' => ['style4'] ]
        ]
       );
        
        $this->add_responsive_control(
         'nav_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .single_post2_carousel' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'slider_content_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'selector' => '{{WRAPPER}}  .single_post2_carousel',
               ]
            );
        $this->end_controls_section();
        $this->start_controls_section('appscred_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'insut-essential' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
                  'condition' => [ 'block_style' => ['style7'] ]
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'insut-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .readmore' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .readmore' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border:: get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'insut-essential' ),
                     'selector' => '{{WRAPPER}} .readmore',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .readmore',
               ]
            );
            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'insut-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .readmore' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'insut-essential' ),
                     'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                     'selector' => '{{WRAPPER}} .readmore',
                     
               ]
            );

      $this->end_controls_section();

    }

    protected function render( ) { 
      
        $settings       = $this->get_settings();
        
        $slide_controls = ahsot_widgets_slider_controls_setttings($settings);
        $data           = new Post_Slider_Model($settings);
        $query          = $data->get();

        
        if( !$query ){
          return;  
        }
       
      
     ?>
 
     
  
      <?php  
    }
    

    
}