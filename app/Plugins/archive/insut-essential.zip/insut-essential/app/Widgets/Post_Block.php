<?php
namespace AppscredEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use AppscredEssential\Base\Repository\Base_Modal;
if ( ! defined( 'ABSPATH' ) ) exit;

class Post_Block extends Widget_Base {

  public $base;

    public function get_name() {
        return 'ahost-post-block';
    }

    public function get_title() {
        return esc_html__( 'Post Block', 'insut-essential' );
    }

    public function get_icon() { 
        return 'eicon-nav-menu';
    }

    public function get_categories() {
        return [ 'ahost-elements' ];
    }

    protected function _register_controls() {

      
       do_action( 'appscred_section_general_tab', $this, $this->get_name() );
       do_action( 'appscred_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'appscred_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'appscred_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'appscred_section_sort_tab', $this , $this->get_name());  
       do_action( 'appscred_section_sticky_tab', $this , $this->get_name());  
        // Style
          
        $this->start_controls_section('appscred_style_title_section',
        [
           'label' => esc_html__( 'Title', 'insut-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'insut-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'color: {{VALUE}};',
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'insut-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a:hover' => 'color: {{VALUE}};',
                
                  ],
               ]
            );
            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'insut-essential' ),
                  'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                  'selector' => '{{WRAPPER}} .signle__blog__content .title a',
               ]
            );
            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}} .signle__blog__content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
             ]
            );
            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'insut-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                  ],
               ]
            );
      $this->end_controls_section();

      $this->start_controls_section('appscred__post_content_section',
         [
            'label'     => esc_html__( 'Content ', 'insut-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
           
         ]
     );

         $this->add_control(
            'block_content_color',
            [
               'label'   => esc_html__('Color', 'insut-essential'),
               'type'    => Controls_Manager::COLOR,
               'default' => '',
               
               'selectors' => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'color: {{VALUE}};',
               ],
            ]
         );

        
         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'post_content_typography',
               'label'    => esc_html__( 'Typography', 'insut-essential' ),
               'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
               'selector' => '{{WRAPPER}} .signle__blog__content .post-desc',
            ]
         );
         $this->add_responsive_control(
         'content_margin',
         [
            'label'      => esc_html__( 'Margin', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}}  .signle__blog__content .post-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'content_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();
      $this->start_controls_section('appscred_style_pcontent_section',
      [
         'label'     => esc_html__( 'Post meta', 'insut-essential' ),
         'tab'       => Controls_Manager::TAB_STYLE,
        
      ]
     );
  
     $this->add_control(
       'post_meta_date_color',
         [
             'label' => esc_html__('Date color', 'insut-essential'),
             'type'  => Controls_Manager::COLOR,
             
             'selectors' => [
                 '{{WRAPPER}} .single__blog__meta .meta__date'    => 'color: {{VALUE}};',
             
             ],
         ]
       ); 
 
       $this->add_group_control(
         Group_Control_Typography:: get_type(),
         [
             'name'     => 'meta_other_typography',
             'label'    => esc_html__( ' Date Typography', 'insut-essential' ),
             'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
             'selector' => '{{WRAPPER}} .single__blog__meta .meta__date',
           
         ]
     );  

     // author
     
      $this->add_control(
         'post_meta_author_color',
         [
               'label' => esc_html__('Author color', 'insut-essential'),
               'type'  => Controls_Manager::COLOR,
               
               'selectors' => [
                  '{{WRAPPER}} .single__blog__meta .meta__author a'    => 'color: {{VALUE}};',
               
               ],
         ]
         ); 

         $this->add_group_control(
         Group_Control_Typography:: get_type(),
         [
               'name'     => 'meta_author_typography',
               'label'    => esc_html__( ' Author Typography', 'insut-essential' ),
               'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
               'selector' => '{{WRAPPER}} .single__blog__meta .meta__author',
            
         ]
      ); 
     //cat
     $this->add_control(
      'post_category_color',
      [
         'label'     => esc_html__('Category Color', 'insut-essential'),
         'type'      => Controls_Manager::COLOR,
         'default'   => '',
         'selectors' => [

            '{{WRAPPER}} .single__blog__meta .meta__category .cat' => 'color: {{VALUE}};',
      
         ],
      ]
      ); 
      $this->add_group_control(
         Group_Control_Typography:: get_type(),
         [
             'name'     => 'meta_category_typography',
             'label'    => esc_html__( 'Category Typography', 'insut-essential' ),
             'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
             'selector' => '{{WRAPPER}} .single__blog__meta .meta__category .cat',
             
         ]
     );
      $this->add_responsive_control(
         'post__meta_margin',
         [
             'label'      => esc_html__( 'Margin', 'insut-essential' ),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => [ 'px','%'],
             'selectors'  => [
                   '{{WRAPPER}} .single__blog__meta'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
             ],
         ]
     );
     
     $this->end_controls_section();
 
      $this->start_controls_section('appscred_image_section',
         [
            'label' => esc_html__( 'Image', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );

      $this->add_responsive_control(
         'image_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .single__blog__post__thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

            $this->add_control(
               'post_image_overlay_c_heading',
               [
                  'label'     => esc_html__( 'Overlay color', 'insut-essential' ),
                  'type'      => \Elementor\Controls_Manager::HEADING,
                  'separator' => 'before',
               ]
            );
   
         
            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'      => 'post_image_overlay_color',
                  'label'     => esc_html__( 'Background', 'insut-essential' ),
                  'types'     => [ 'gradient' ],
                  'selector'  => '{{WRAPPER}} .gradient1::after',
                 
               ]
            );
            
            $this->add_control(
               'post_image_overlay_opecity',
               [
                  'label'      => esc_html__( 'Opacity', 'insut-essential' ),
                  'type'       => Controls_Manager::SLIDER,
                  'size_units' => [ 'px' ],
                  'range'      => [
                     'px' => [
                        'min'  => 0,
                        'max'  => 1,
                        'step' => .1,
                     ],
                   
                  ],
                 
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__post__thumb::after' => 'opacity: {{SIZE}};',
                  ],
               ]
            );
  
         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ,'%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .single__blog__post__thumb img' => 'height: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image Width', 'insut-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .single__blog__post__thumb img' => 'width: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
      
          
      $this->end_controls_section();

      $this->start_controls_section('appscred_single_box_section',
         [
            'label' => esc_html__( 'Post item', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
   
      $this->add_responsive_control(
         'item_borders_radius',
         [
            'label'      => esc_html__( 'Border radius', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            
            'selectors' => [
               
               '{{WRAPPER}} .single__blog__post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Box_Shadow:: get_type(),
         [
            'name'     => 'single_post_box_shadow',
            'label'    => esc_html__( 'Box Shadow', 'insut-essential' ),
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );
   
      $this->add_group_control(
         \Elementor\Group_Control_Background:: get_type(),
         [
            'name'     => 'single_box_background',
            'label'    => esc_html__( 'Background', 'insut-essential' ),
            'types'    => [ 'classic', 'gradient', 'video' ],
            'selector' => '{{WRAPPER}} .single__blog__post,{{WRAPPER}} .signle__blog__content ',
         ]
      );
   
     $this->add_responsive_control(
      'single_box_margin',
      [
         'label'      => esc_html__( 'Margin', 'insut-essential' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%'],
         'selectors'  => [
            '{{WRAPPER}} .single__blog__post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
         ],
      ]
      );

      $this->add_responsive_control(
         'single_box_padding',
         [
            'label'      => esc_html__( 'Padding', 'insut-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .single__blog__post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section('appscred_box_section',
         [
            'label' => esc_html__( ' Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
    
      $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'insut-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        
        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'insut-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );
      $this->end_controls_section();

    
   
      
        $this->start_controls_section('appscred_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'insut-essential' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
                 
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'insut-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border:: get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'insut-essential' ),
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'insut-essential' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'selector' => '{{WRAPPER}} .readmore__btn',
               ]
            );
            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'insut-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .readmore__btn' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'insut-essential' ),
                     'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
               ]
            );
            $this->add_control(
               'readmore_bottom_border_hide',
               [
                  'label' => esc_html__( 'Border hide', 'insut-essential' ),
                  'type' => \Elementor\Controls_Manager::SELECT,
                  'default' => 'solid',
                  'options' => [
                     'block'  => esc_html__( 'Show', 'insut-essential' ),
                     'none' => esc_html__( 'None', 'insut-essential' ),
                  ],
                  'selectors' => [
                     '{{WRAPPER}} a.readmore__btn:before' => 'display: {{VALUE}};',
               
                  ],
               ]
            );
            $this->add_control(
               'readmore_bottom_border_color',
                  [
                     'label'     => esc_html__('Bottom border Color', 'insut-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} a.readmore__btn:before' => 'background: {{VALUE}};',
                  
                     ],
                  ]
            ); 

      $this->end_controls_section();

    }

    protected function render( ) { 
      
        $settings       = $this->get_settings();
        
        $data           = new Base_Modal($settings);
        $query          = $data->get();
        
        if( !$query ){
          return;  
        }


      
     ?>
         <!--::::: BLOG AREA START :::::::-->
                  <div class="row justify-content-center main-section" >
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                           <div class="col-md-6 col-lg-4">
                              <div class="single__blog__post">
                                    <?php if(has_post_thumbnail()): ?>
                                       <div class="single__blog__post__thumb gradient1">
                                          <a href="<?php the_permalink() ?>"> 
                                             <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                                          </a>
                                       </div>
                                    <?php endif; ?>
                                    <div class="signle__blog__content">
                                       <div class="single__blog__meta">
                                          <?php if($settings['show_cat'] =='yes'): ?>
                                             <div class="meta__category">
                                                <?php
                                                   $categories = get_the_category();
                                                      if ( ! empty( $categories) ) {
                                                         echo '<a class="cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                                                      }
                                                   ?>
                                             </div>
                                          <?php endif; ?>
                                          <?php if($settings['show_author'] =='yes'): ?>
                                             <div class="meta__author"> 
                                                <?php
                                                   printf(
                                                      '<a class="post_author" href="%1$s">%2$s</a>',
                                                      esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ), 
                                                      get_the_author()
                                                   );
                                                ?>
                                             </div>  
                                          <?php endif; ?>
                                          <?php if($settings['show_date'] == 'yes'): ?>   
                                          <div class="meta__date">
                                             <?php echo get_the_date(get_option( 'date_format' )); ?>
                                          </div>
                                          <?php endif; ?>
                                       </div>
                                       <h3 class="title">
                                          <a href="<?php the_permalink() ?>"><?php echo esc_html(wp_trim_words( get_the_title(),$settings['post_title_crop'] )); ?></a>
                                       </h3>
               
                                       <?php if($settings['show_content'] =='yes'): ?>
                                          <p class="post-desc"> <?php echo esc_html(wp_trim_words( get_the_excerpt(), $settings['post_content_crop'],'' )); ?> </p>
                                       <?php endif; ?>
                                       <?php if($settings['show_readmore'] == 'yes'): ?>
                                             <a href="<?php the_permalink() ?>" class="readmore__btn"> <?php echo esc_html($settings['readmore_text']); ?> </a>
                                       <?php endif; ?>
                                    
                                    </div>
                              </div>
                           </div>
                        <?php endwhile; wp_reset_postdata(); ?> 
                  </div>
         <!--::::: BLOG AREA END :::::::-->
      <?php  
    }
    

    
}