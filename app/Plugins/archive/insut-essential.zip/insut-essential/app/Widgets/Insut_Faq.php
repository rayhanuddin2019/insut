<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Insut_Faq extends Widget_Base {

    public $base;

    public function get_name() {
        return 'insut-faq';
    }

    public function get_title() {
        return esc_html__( 'Insut Faq', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-bars";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
    function array_pluck($array, $key) {

        return array_map(function($v) use ($key) {
          return trim(is_object($v) ? $v->$key : $v[$key]);
        }, $array);
    }
 
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Insut Faq settings', 'insut-essential'),
            ]
        );
      
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Question', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'insut-essential' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_content', [
				'label' => esc_html__( 'Answer', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'List Content' , 'insut-essential' ),
				'show_label' => false,
			]
		);

	

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Faq List', 'insut-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);

     
        $this->end_controls_section();
  
       
        $this->start_controls_section(
			'section_menu_content_style', [
				'label' => esc_html__( 'Tab content', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'tab_content_box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .singleFaq',
                    ]
                );

                $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'tab_content__section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .singleFaq',
                    ]
                );
                $this->add_control(
                    'title_content_tag_color', [

                        'label'     => esc_html__( 'Title Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .singleFaq .card-header .btn' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_tag_typho',
                        'label'    => esc_html__( 'Title Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .singleFaq .card-header .btn',
                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'title_content__section_background',
                            'label'    => esc_html__( 'Background', 'insut-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .singleFaq .card-header',
                        ]
                    );

                    $this->add_control(
                        'title_icon_tag_color', [
    
                            'label'     => esc_html__( 'Title icon Color', 'insut-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .singleFaq .card-header .btn:after' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                   
                    $this->add_group_control(
                        \Elementor\Group_Control_Background:: get_type(),
                            [
                                'name'     => 'title_icon_section_background',
                                'label'    => esc_html__( 'Background', 'insut-essential' ),
                                'types'    => [ 'classic', 'gradient', 'video' ],
                                'selector' => '{{WRAPPER}} .singleFaq .card-header .btn:after',
                            ]
                        );
                    
    
                    $this->add_group_control(
                        \Elementor\Group_Control_Border::get_type(),
                        [
                            'name' => 'itemcontent_box_border',
                            'label' => esc_html__( 'Title Border', 'insut-essential' ),
                            'selector' => '{{WRAPPER}} .singleFaq .card-header .btn:after',
                        ]
                    );
                 // content       
                $this->add_control(
                    'content_text_color', [

                        'label'     => esc_html__( 'Content Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .card-body p' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_text_typho',
                        'label'    => esc_html__( 'Content Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .card-body p',
                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => '_content__section_background',
                            'label'    => esc_html__( 'Background', 'insut-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .card-body',
                        ]
                    );

            

        $this->end_controls_section();

        $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'insut-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
       
         
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'service_list_section_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-section',
                   
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings       = $this->get_settings();
		$faq_items      = $settings['list'];
	
       
    ?>
     
       
    <!--====== FAQ PART START ======-->

            <div id="accordion" class="insut-faq main-section">
                <?php foreach($faq_items as $key => $faq): ?> 
                    <!-- Faq Item -->
                    <div class="singleFaq sf <?php echo esc_attr($key==0?'active':''); ?>">
                        <div class="card-header" id="faq-<?php echo esc_attr( $key ) ?>">
                            <h5 class="mb-0">
                                <button class="btn btn-link <?php echo esc_attr($key==0?'':'collapsed'); ?>" data-toggle="collapse" data-target="#accordion-<?php echo esc_attr( $key ) ?>" aria-expanded="false" aria-controls="accordion-<?php echo esc_attr( $key ) ?>">
                                      <?php echo esc_html($faq['list_title']); ?>
                                </button>
                            </h5>
                        </div>
                        <div id="accordion-<?php echo esc_attr( $key ) ?>" class="collapse <?php echo esc_attr($key==0?'show':''); ?>" aria-labelledby="faq-<?php echo esc_attr( $key ) ?>" data-parent="#accordion">
                            <div class="card-body">
                            <?php echo insut_kses($faq['list_content']); ?>
                            </div>
                        </div>
                    </div>
                    <!-- Faq Item -->
                <?php endforeach; ?> 
              
            </div>

    <!--====== FAQ PART ENDS ======-->
       
       
    <?php  

    }
    
    protected function _content_template() { }
}