<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class Finder extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-contact-finder';
    }

    public function get_title() {
        return esc_html__( 'Contact Finder', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-search";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Form Contact', 'insut-essential' ),
                       
            
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__(' Content', 'insut-essential'),
            ]
        );
  

                $this->add_control(
                    'list_title', [
                        'label' => esc_html__( 'Title', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Title' , 'insut-essential' ),
                        'label_block' => true,
                    ]
                );


      $this->end_controls_section();
      $this->start_controls_section(
            'section_content_form_tab',
            [
                'label' => esc_html__('Form Fields', 'insut-essential'),
            ]
        );

            $this->add_control(
                'show_form',
                [
                    'label' => esc_html__( 'Enable Form', 'insut-essentia' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Show', 'insut-essentia' ),
                    'label_off' => esc_html__( 'Hide', 'insut-essentia' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );   

            $this->add_control(
                'form_action', [
                    'label' => esc_html__( 'Find Page Url', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'agent', [
                    'label'     => esc_html__('Agents', 'insut-essential'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'insut-essential'),
                    'label_off' => esc_html__('No', 'insut-essential'),
                    'return_value' => 'yes',
				    'default' => 'yes',
                ]
            );

            $this->add_control(
                'branch', [
                    'label'     => esc_html__('Branch', 'insut-essential'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'insut-essential'),
                    'label_off' => esc_html__('No', 'insut-essential'),
                    'return_value' => 'yes',
				    'default' => 'yes',
                ]
            );

            $this->add_control(
                'provider', [
                    'label'     => esc_html__('Provider', 'insut-essential'),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__('Yes', 'insut-essential'),
                    'label_off' => esc_html__('No', 'insut-essential'),
                    'return_value' => 'yes',
				    'default' => 'yes',
                ]
            );

            $this->add_control(
                'form_location_placeholder', [
                    'label' => esc_html__( 'Location Placeholder', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Rosebelt Street ,USA' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );
        
            $this->add_control(
                'form_submit_text', [
                    'label' => esc_html__( 'Submit text', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Find' , 'insut-essential' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'form_icon',
                [
                    'label' => esc_html__( 'Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                ]
            );

      $this->end_controls_section();

   

        $this->start_controls_section(
            'section_contact_branch_tab',
            [
                'label' => esc_html__(' Icon ', 'insut-essential'),
            
            ]
        );

                $this->add_control(
                    'mid_icon',
                    [
                        'label' => esc_html__( 'Icon', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::ICONS,
                    ]
                );
                
        $this->end_controls_section();

           
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

       
        // button 
        $this->start_controls_section(
			'section_form_select_style', [
				'label' => esc_html__( 'Form Style', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
               
			]
        );
                $this->add_control(
                    'agent_color1', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .find-form input[type="search"]::placeholder' => 'color: {{VALUE}};',
                         
                        ],
                    ]
                );
        
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho1',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .find-form input[type="search"]',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding1',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .find-form input[type="search"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin1',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .find-form input[type="search"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading1',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background1',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .find-form input[type="search"]',
                    ]
                );
             

              
                $this->add_control(
                    'button_section_border_radius1',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .find-form input[type="search"]' => 'border-radius: {{VALUE}}px;',
                              
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border1',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .find-form input[type="search"]',
                    ]
                );
             


        $this->end_controls_section();
        $this->start_controls_section(
			'section_nav_tab_button_style', [
				'label' => esc_html__( 'Nav Button ', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                $this->add_control(
                    'nav_tab_button_color2', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .find-form-title li a' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_control(
                    'nav_tab_btn_color_hv2', [

                        'label'     => esc_html__( 'Hover color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .find-form-title li a:hover' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'nav_tab_button_typho2',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .find-form-title li a',
                    ]
                );

                $this->add_control(
                    'nav_tab_button_icon_color2', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .find-form-title li a i' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'nav_tab_button_icon_typho2',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .find-form-title li a i',
                    ]
                );

                $this->add_responsive_control(
                    'nav_tab)button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .find-form-title li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'nav_tab_btn_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'nav_button_inp_section_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .find-form-title li a:after',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'nav_hover_btn_bborder',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .find-form-title li a:after',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section(
			'section_submit_button_style', [
				'label' => esc_html__( 'Submit Button ', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                $this->add_control(
                    'button_color2', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv2', [

                        'label'     => esc_html__( 'Hover color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho2',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );

                $this->add_control(
                    'button_icon_color2', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn i' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_icon_typho2',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .insut-btn i',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );
                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Background hover color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input__section_hv_background_2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .insut-btn::after',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .insut-btn' => 'border-radius: {{VALUE}}px;',
                               
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border2',
                        'label' => esc_html__( 'Border', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .insut-btn',
                    ]
                );


        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_shape_image_style', [
				'label' => esc_html__( 'Shape Image / Icon', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
               
                $this->add_control(
                    'shape_icon_a_color',
                    [
                        'label' => esc_html__('color', 'insut-essential'),
                        'type'  => Controls_Manager::COLOR,
                       // 'condition' => [ 'block_style' => ['style1','style3'] ],
                        'selectors' => [
                           
                            '{{WRAPPER}} .find-icon i'    => 'color: {{VALUE}};',
                        
                        ],
                    ]
                ); 
        
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'shape_icon_typography',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .find-icon i',
                      //  'condition' => [ 'block_style' => ['style1','style3'] ],
                    ]
                ); 
              
                $this->add_responsive_control(
                    'shape_image_section_position_top',
                    [
                        'label'      => esc_html__( 'Position Top', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .find-icon' => 'top: {{SIZE}}{{UNIT}};',
                          
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_left',
                    [
                        'label'      => esc_html__( 'Position Left', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .find-icon' => 'left: {{SIZE}}{{UNIT}};',
                         
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'shape_image_section_position_bottom',
                    [
                        'label'      => esc_html__( 'Position bottom', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => -500,
                                'max' => 1000,
                                'step' => 5,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                       
                        'selectors' => [
                            '{{WRAPPER}} .find-icon' => 'bottom: {{SIZE}}{{UNIT}};',
                          
                           
                        ],
                    ]
                );
               
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shapebackground',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                     
                        'selector' => '{{WRAPPER}} .find-icon',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                       'name'     => 'mid_icon_border',
                       'label'    => esc_html__( 'Border', 'insut-essential' ),
                       'selector' => '{{WRAPPER}} .find-icon',
                       
                    ]
                );

                $this->add_control(
                    'icon_backhround_heading',
                    [
                       'label'     => esc_html__( 'Icon background', 'insut-essential' ),
                       'type'      => \Elementor\Controls_Manager::HEADING,
                       'separator' => 'after',
                      // 'condition' => [ 'block_style' => ['style3'] ],
                    ]
                 );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_background',
                        'label' => esc_html__( 'Background', 'insut-essential' ),
                        'types' => [ 'classic', 'gradient' ],
                        'condition' => [ 'block_style' => ['style3'] ],
                        'selector' => '{{WRAPPER}} .find-icon',
                    ]
                );
               
                $this->add_responsive_control(
                    'shape_imageopacity',
                        [
                            'label' => esc_html__( 'Opacity', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 1,
                            'step'  => 0.1,
                           
                            'selectors' => [
                                
                                '{{WRAPPER}} .find-icon' => 'opacity: {{VALUE}};',
                         
                        ],
                    ]
                ); 
         
       

        $this->end_controls_section();
        
      
		
        $this->start_controls_section('appscred_box_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

     $this->end_controls_section();
     

     $this->start_controls_section('insut_inner_box_section',
            [
            'label' => esc_html__( 'Form Inner Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'inner_box_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .find-form-area',
                    ]
                );
            
                $this->add_responsive_control(
                'inner_box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .find-form-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'inner_box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .find-form-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'inner_box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'insut-essential' ),
                        'selector' => '{{WRAPPER}} .find-form-area',
                    ]
                );
     $this->end_controls_section();
      
    } //Register control end

    protected function render( ) { 

		$settings                  = $this->get_settings();
	
		$form_location_placeholder = $settings['form_location_placeholder'];
		$form_submit_text          = $settings['form_submit_text'];
		$form_action               = $settings['form_action'];
		$form_icon                 = $settings['form_icon'];

    ?>
        <!--====== BANNER PART START ======-->
    <?php if($settings['layout'] == 'style1'): ?>
     
        <div class="find-wrapper main-section">
                           <?php if($settings['show_form'] == 'yes'): ?>
                            <div class="row">
                              <?php if($settings['list_title'] !=''): ?>
                                    <div class="col-lg-6 col-md-6">
                                        <h3 class='title'>
                                            <?php echo esc_html($settings['list_title']); ?> 
                                        </h3>
                                    </div>
                              <?php endif; ?>
                                <div class="<?php echo esc_attr($settings['list_title'] ==''?'col-lg-12 col-md-12':'col-lg-6 col-md-6'); ?>">
                                    <div class="find-form-area">
                                        <!-- Tab Title Start -->
                                        <ul class="find-form-title nav nav-tabs">

                                            <?php if( $settings['agent'] == 'yes' ): ?>
                                                 <li><a class="active" href="#agent" data-toggle="tab"><i class="insut-Icon5"></i> <?php echo esc_html__( 'Agent', 'insut-essential' ) ?> </a></li>
                                            <?php endif; ?>
                                            <?php if( $settings['branch'] == 'yes' ): ?>
                                                  <li><a href="#branch" data-toggle="tab"><i class="insut-Icon3"></i> <?php echo esc_html__( 'Branch', 'insut-essential' ) ?></a></li>
                                            <?php endif; ?>
                                            <?php if( $settings['provider'] == 'yes' ): ?>
                                                <li><a href="#medical-provider" data-toggle="tab"><i class="insut-Icon3"></i><?php echo esc_html__( 'Medical Provider', 'insut-essential' ) ?></a></li>
                                            <?php endif; ?>
                                           
                                            
                                        </ul>
                                        <!-- Tab Title End -->

                                        <!-- Tab Content Start -->
                                        <div class="tab-content">
                                            <div class="tab-pane fade in" id="agent" role="tabpanel">
                                               
                                                <form class="find-form" action="<?php echo esc_url($form_action); ?>" method="post">
                                                  
                                                    <div>
                                                      <input type="search" name="c_search" placeholder="<?php echo esc_attr($form_location_placeholder); ?>">
                                                      <input type="hidden" name="type" value="agent">
                                                    </div>
                                                    
                                                    <button type="submit" class="insut-btn">
                                                        <?php if( $form_icon['value'] == '' ): ?>
                                                            <i class="insut-Icon11">
                                                                    <span class="path3"></span>
                                                            </i>
                                                            <?php else: ?>   
                                                                <?php \Elementor\Icons_Manager::render_icon( $form_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                            <?php endif; ?>   
                                                        
                                                        <?php echo esc_html( $form_submit_text ) ?>
                                                    </button>

                                                </form>
                                            </div>
                                            <div class="tab-pane fade show in active" id="branch" role="tabpanel">
                                                <form class="find-form" action="<?php echo esc_url($form_action); ?>" method="post">
                                                   
                                                    <div>
                                                         
                                                          <input type="hidden" name="type" value="branch">
                                                          <input type="search" name="c_search" placeholder="<?php echo esc_attr($form_location_placeholder); ?>">
                                                    </div>
                                                    
                                                    <button type="submit" class="insut-btn">
                                                        <?php if( $form_icon['value'] == '' ): ?>
                                                            <i class="insut-Icon11">
                                                                    <span class="path3"></span>
                                                            </i>
                                                            <?php else: ?>   
                                                                <?php \Elementor\Icons_Manager::render_icon( $form_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                            <?php endif; ?>   
                                                        
                                                        <?php echo esc_html( $form_submit_text ) ?>
                                                     </button>
                                                </form>
                                            </div>
                                            <div class="tab-pane fade in" id="medical-provider" role="tabpanel">
                                                <form class="find-form" action="<?php echo esc_url($form_action); ?>" method="post">
                                                    
                                                    <div>
                                                      <input type="hidden" name="type" value="provider">
                                                      <input type="search" name="c_search" placeholder="<?php echo esc_attr($form_location_placeholder); ?>">
                                                    </div>
                                                    
                                                    <button type="submit" class="insut-btn">
                                                        <?php if( $form_icon['value'] == '' ): ?>
                                                            <i class="insut-Icon11">
                                                                    <span class="path3"></span>
                                                            </i>
                                                        <?php else: ?>   
                                                            <?php \Elementor\Icons_Manager::render_icon( $form_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                        <?php endif; ?>   
                                                    
                                                        <?php echo esc_html( $form_submit_text ) ?>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- Tab Content End -->
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?> 
                            <!-- Middle Icon -->
                            <div class="find-icon">
                           
                                <?php if( $settings['mid_icon']['value'] == '' ): ?>
                                    <i class="icofont-home"></i>
                                <?php else: ?>   
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['mid_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif; ?> 

                             </div>
                        </div>

    <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}