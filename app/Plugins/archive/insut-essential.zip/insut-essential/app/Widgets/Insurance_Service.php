<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Insurance_Service extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-insurance-service';
    }

    public function get_title() {
        return esc_html__( 'Insut Insurance Service', 'insut-essential' );
    }

    public function get_icon() { 
        return 'fa fa-telegram';
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }
    public function layout(){
        return[
            
            'style1'   => esc_html__( 'Standard', 'insut-essential' ),
            'style2' => esc_html__( 'Creative', 'insut-essential' ),
        
    
        ];
    }
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'insut-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'insut-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
                
                $this->add_control(
                    'custom_service',
                    [
                        'label'     => esc_html__('Custom Service', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => '',
                        
                    ]
                ); 

                $this->add_control(
                    'service',
                    [
                        'label' => esc_html__( 'Service_items', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT2,
                        'multiple' => true,
                        'options' => $this->get_service_list(),
                        'condition' => [ 
                            'custom_service' => ['']
                        ],
                        'show_label' => true,
                        'label_block' => true,
                    ]
                );

                $this->add_control(
                    'custom_service_ids', [
                        'label'       => esc_html__( 'Custom Service ids', 'insut-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                        'default'     => esc_html__( '1, 2' , 'insut-essential' ),
                        'placeholder' => esc_html__( '1, 2' , 'insut-essential' ),
                        'description' => esc_html__( 'post id seperate with comma' , 'insut-essential' ),
                        'show_label'  => true,
                        'condition'   => [ 
                            'custom_service' => ['yes']
                        ],
                    ]
                );

                $this->add_control(
                'post_count',
                    [
                        'label'   => esc_html__( 'Post count', 'insut-essential' ),
                        'type'    => Controls_Manager::NUMBER,
                        'default' => '6',
                    ]
                );
                $this->add_control(
                    'post_title_crop',
                    [
                    'label'   => esc_html__( 'Title limit', 'insut-essential' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => '20',
                    
                    ]
                ); 
               
                $this->add_control(
                    'show_desc',
                    [
                        'label'     => esc_html__('Show desc', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                        
                    ]
                ); 
               
                $this->add_control('desc_limit',
                    [
                      'label'     => esc_html__( 'Description limit', 'insut-essential' ),
                      'type'      => Controls_Manager::NUMBER,
                      'default'   => '40',
                      'min'       => 2,
                      'condition' => [ 
                         'show_desc' => ['yes']
                       ],
                      
                    ]
                );  
        
                $this->add_control('show_title_icon',
                    [
                        'label'     => esc_html__('Show Title Icon', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                    ]
                ); 

                $this->add_control('show_menu_icon',
                    [
                        'label'     => esc_html__('Show Menu Icon', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                    ]
                );
            
                $this->add_control(
                    'post_sort',
                    [
                        'label' => esc_html__( 'Sort', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'DESC',
                        'options' => [
                            'ASC'  => esc_html__( 'ASC', 'insut-essential' ),
                            'DESC' => esc_html__( 'DESC', 'insut-essential' ),
                        ],
                    ]
                );

                $this->add_control(
                    'show_more_active',
                    [
                        'label'     => esc_html__('Show show more button', 'insut-essential'),
                        'type'      => Controls_Manager::SWITCHER,
                        'label_on'  => esc_html__('Yes', 'insut-essential'),
                        'label_off' => esc_html__('No', 'insut-essential'),
                        'default'   => 'yes',
                        
                    ]
                );

                $this->add_control(
                    'show_more_text',
                    [
                        'label'   => esc_html__( 'View more text', 'insut-essential' ),
                        'type'    => Controls_Manager::TEXT,
                        'default' => esc_html__( 'View more', 'insut-essential' ),

                    ]
                );

                $this->add_control(
                    'show_more_icon',
                    [
                        'label' => esc_html__( 'Show More Icon', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::ICONS,
                       
                    ]
                );
        

                $this->add_responsive_control(
                    'title_align', [
                        'label'   => esc_html__( 'Alignment', 'insut-essential' ),
                        'type'    => Controls_Manager::CHOOSE,
                        'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'insut-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                        'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'insut-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                                'title' => esc_html__( 'Right', 'insut-essential' ),
                                'icon'  => 'fa fa-align-right',
                        
                        ],
                        'justify'	 => [

                                'title' => esc_html__( 'Justified', 'insut-essential' ),
                                'icon'  => 'fa fa-align-justify',
                        
                            ],
                        ],
                        'default' => 'left',
                        'selectors' => [
                            '{{WRAPPER}} .tab-content-box'   => 'text-align: {{VALUE}};',
                        
                        ],
                    ]
                );//Responsive control end

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_menu_nav',
            [
            'label' => esc_html__( 'Tab Menu nav', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ] 
        );

                $this->add_control(
                    'nav_menu_color', [

                        'label'     => esc_html__( 'Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .service-tab-title li a' => 'color: {{VALUE}};',
            
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'nav_menu_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .service-tab-title li a',
                    ]
                );

                $this->add_control(
                    'nav_menu_icon_color', [

                        'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .service-tab-title li a i' => 'color: {{VALUE}};',
            
                        ],
                    ]
                );

                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'nav_menu_icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .service-tab-title li a i',
                    ]
                );

                $this->add_control(
                    'nav_menu_border_radious',
                        [
                            'label' => esc_html__( 'Border radius', 'insut-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .service-tab-title li a' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .service-tab-title li a:after' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 
            
                $this->add_control(
                    'nav_menu_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'nav_menu_background2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .service-tab-title li a',
                    ]
                );

                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Hover Background color', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );


                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'tab_nav_hover_background_2',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .service-tab-title li a:after',
                    ]
                );

                $this->add_control(
                    'nav_menu_active_border_color', [

                        'label'     => esc_html__( 'Active Border Color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .service-tab-title li a:before' => 'border-left-color: {{VALUE}};',
            
                        ],
                    ]
                );    
                
                $this->add_responsive_control(
                    'nav_menu_item_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .service-tab-title li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'nav_menu_item_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .service-tab-title li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'nav_menu_item_height',
                    [
                        'label' => esc_html__( 'Height', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [

                            'px' => [
                                'min' => 0,
                                'max' => 300,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .service-tab-title li a' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'nav_menu_item_width',
                    [
                        'label' => esc_html__( 'Width', 'insut-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            
                            'px' => [
                                'min' => 0,
                                'max' => 300,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .service-tab-title li a' => 'width: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('insut__tab_content_icon',
            [
            'label' => esc_html__( 'Teb Content Icon', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'tab_content_icon_color', [

                    'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .service-icon i' => 'color: {{VALUE}};',
        
                    ],
                ]
            );

        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_icon_typho',
                    'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .service-icon i',
                ]
            );

            $this->add_control(
                'tab_content_border_radious',
                    [
                        'label' => esc_html__( 'Border radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .service-icon' => 'border-radius: {{VALUE}}px;',
                        
                    ],
                ]
            ); 


            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                'name'     => 'tab_content_icon_background',
                'label'    => esc_html__( 'Background', 'insut-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .service-icon',
                ]
            );

            $this->add_control(
                'tab_content_icon_backgrounds_dot_color', [

                    'label'     => esc_html__( 'Icon Dot Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .service-icon:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .service-icon:after' => 'background: {{VALUE}};',
        
                    ],
                ]
            );

            $this->add_control(
                'tab_content_icon_view_more_heading',
                [
                    'label' => esc_html__( 'View More Icon', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'tab_content_view_more_icon_color', [

                    'label'     => esc_html__( 'Icon Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .insut-btn i' => 'color: {{VALUE}};',
        
                    ],
                ]
            );

        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_view_more_icon_typho',
                    'label'    => esc_html__( 'Icon Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .insut-btn i',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_content_title',
            [
            'label' => esc_html__( 'Teb Content Title', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_content_title_color', [

                'label'     => esc_html__( 'TItle Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .content-top h3' => 'color: {{VALUE}};',
    
                ],
            ]
        );

    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_title_typho',
                'label'    => esc_html__( 'Title Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .content-top h3 ',
            ]
        );

        
        $this->add_responsive_control(
            'teb_content_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-top h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_title_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-top h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('insut_tab_content_desc',
            [
            'label' => esc_html__( 'Teb Content Desc', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_content_desc_color', [

                'label'     => esc_html__( 'Desc Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .tab-content-box p ' => 'color: {{VALUE}};',

                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_desc_typho',
                'label'    => esc_html__( ' Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .tab-content-box p ',
            ]
        );

        $this->add_control(
            'tab_content_desc_heightlight_color', [

                'label'     => esc_html__( 'Heighlight Color', 'insut-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .tab-content-box span' => 'color: {{VALUE}};',

                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'teb_content_desc_heighlisig_typho',
                'label'    => esc_html__( 'Heighlight Typography', 'insut-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .tab-content-box span',
            ]
        );

        
        $this->add_responsive_control(
            'teb_content_desc_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .tab-content-box p ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_desc_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .tab-content-box p ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                ],
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();
        $this->start_controls_section('tab_content_view_more_btn',
            [
            'label' => esc_html__( 'Tab content View more', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'tab_content_view_more__btn_color', [

                    'label'     => esc_html__( 'Color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .insut-btn' => 'color: {{VALUE}};',

                    ],
                ]
            );


            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'teb_content_view_more_btn',
                    'label'    => esc_html__( ' Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .insut-btn',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'teb_content_view_more_btn_background',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .insut-btn',
                ]
            );

            $this->add_control(
                'teb_content_view_more_btn_heading',
                [
                    'label' => esc_html__( 'Hover', 'insut-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'teb_content_view_more_btn_background_hover',
                    'label' => esc_html__( 'Background', 'insut-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .insut-btn:after',
                ]
            );

            $this->add_control(
                'teb_content_view_more_border_radious',
                    [
                        'label' => esc_html__( 'Border Radius', 'insut-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .insut-btn' => 'border-radius: {{VALUE}}px;',
                            '{{WRAPPER}} .insut-btn::after' => 'border-radius: {{VALUE}}px;',
                           
                    ],
                ]
            ); 
            $this->add_responsive_control(
                'tab_content_view_more_s_padding',
                [
                    'label'      => esc_html__( 'Padding', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .insut-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );
    
            $this->add_responsive_control(
                'teb_content_view_more_s_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .insut-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('insut__tab_content_boxs',
            [
            'label' => esc_html__( 'Content box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'teb_content_box_background_hover',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .tab-content-box',
            ]
        );

        $this->add_control(
            'teb_content_boxs_border_radious',
                [
                    'label' => esc_html__( 'Border Radius', 'insut-essential' ),
                    'type'  => \Elementor\Controls_Manager::NUMBER,
                    'min'   => 0,
                    'max'   => 200,
                    'step'  => 1,
                    
                    'selectors' => [
                        '{{WRAPPER}} .tab-content-box' => 'border-radius: {{VALUE}}px;',
                      
                       
                ],
            ]
        ); 
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'teb_content_boxs_border_s',
				'label' => esc_html__( 'Border', 'insut-essential' ),
				'selector' => '{{WRAPPER}} .tab-content-box',
			]
		);
        $this->add_responsive_control(
            'tab_content_boxs_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .tab-content-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'teb_content_boxs_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .tab-content-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

       
        $this->start_controls_section('insut__main_section',
            [
            'label' => esc_html__( 'Main Box', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

  
        $this->add_responsive_control(
            'main_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'main_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'insut-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'main_section_background',
                'label' => esc_html__( 'Background', 'insut-essential' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .main-section',
            ]
        );

       $this->end_controls_section();

     
    } //Register control end

    protected function render( ) { 

        $settings     = $this->get_settings();

        $custom_service     = $settings['custom_service'];
        $service            = $settings['service'];
        $custom_service_ids = $settings['custom_service_ids'];
        $post_count         = $settings['post_count'];
        $post_title_crop    = $settings['post_title_crop'];
        $show_desc          = $settings['show_desc'];
        $desc_limit         = $settings['desc_limit'];
        $show_title_icon    = $settings['show_title_icon'];
        $show_menu_icon     = $settings['show_menu_icon'];
        $post_sort          = $settings['post_sort'];
        $show_more_active   = $settings['show_more_active'];
        $show_more_text     = $settings['show_more_text'];
        
        $args = array(

            'posts_per_page'   => $post_count,
            'orderby'          => 'post_date',
            'order'            => 'DESC',
            'post_type'        => 'quomodo-service',
            'post_status'      => 'publish',
            'suppress_filters' => false,
        
        );
 
        $args['order'] = $post_sort;

        if($custom_service == 'yes'):

            $ids = explode(',',$custom_service_ids);
            $args['post__in'] = $ids;

        else:

             if(count($service)){
                $args['post__in'] = $service; 
             }
               
        endif;    
       
        $posts = new \WP_Query( $args );
       
    ?>    
          
        <?php if($settings['style'] == 'style1'): ?>

                <div class="row main-section">
                    <div class="col-lg-3 col-md-4">
                        <!-- Tab Title Start -->
                        <?php  if($posts->have_posts() ) : ?>
                            <ul class="service-tab-title nav nav-tabs">
                                <?php 

                                    while ( $posts->have_posts() ) :
                                        $posts->the_post();

                                        $menu_slug         = insut_meta_option(get_the_id(),'service_type_slug','x','insut_service_options');
                                        $service_type      = insut_meta_option(get_the_id(),'service_type','','insut_service_options');
                                        $service_menu_icon = insut_meta_option(get_the_id(),'service_menu_icon','','insut_service_options');
                                    
                                        $menu_id           = sanitize_title(get_the_title());
                                        $icon_cls          = 'icofont-home';

                                        if( $menu_slug != '' ){

                                        $menu_id = $menu_slug;

                                        }

                                        if( $service_menu_icon != '' ){

                                            $icon_cls = $service_menu_icon;

                                        }

                                    ?>  

                                        <li>
                                            <a href="#<?php echo esc_attr($menu_id); ?>" data-toggle="tab">
                                            <?php if($show_menu_icon == 'yes'): ?>   
                                                <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                            <?php endif; ?> 
                                            <?php echo esc_html($service_type); ?>
                                            </a>
                                        </li>

                                    <?php     
                                    endwhile; 
                                    wp_reset_postdata();
                            
                                ?>
                            
                                
                            </ul>
                        <?php endif; ?>
                        <!-- Tab Title End -->
                    </div>
                    <div class="col-lg-9 col-md-8">
                        <!-- Tab Content Start -->
                        <div class="tab-content">
                            <?php  if($posts->have_posts() ) : ?>
                                <!-- Tab Item 01 Start -->
                                <?php 

                                while ( $posts->have_posts() ) :
                                    $posts->the_post();

                                    $menu_slug = insut_meta_option(get_the_id(),'service_type_slug','x','insut_service_options');
                                   
                                    $title_icon = insut_meta_option(get_the_id(),'title_icon','','insut_service_options');
                                    $excerpt    = insut_meta_option(get_the_id(),'excerpt','','insut_service_options');
                                    $menu_id    = sanitize_title(get_the_title());
                                    $link       = get_the_permalink();
                                    $icon_cls   = 'icofont-skull-danger';

                                    if( $menu_slug != '' ){

                                    $menu_id = $menu_slug;

                                    }

                                    if( $title_icon != '' ){

                                        $icon_cls = $title_icon;

                                    }
                                    $title_1      = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( get_the_title(), $post_title_crop,'' ) ); 
                                    $excerpt_content      = str_replace(['{', '}'], ['<span>', '</span>'], wp_trim_words( $excerpt , $desc_limit,'' ) ); 
                                ?> 
                                <div class="tab-pane fade in <?php echo esc_attr($posts->current_post ==0?'show  active':''); ?>" id="<?php echo esc_attr($menu_id); ?>" role="tabpanel">
                                    <div class="tab-content-box">
                                        <div class="content-top">
                                           <?php if($show_title_icon == 'yes'): ?>   
                                                <div class="service-icon">
                                                    <i class="<?php echo esc_attr($icon_cls); ?>"></i>
                                                </div>
                                            <?php endif; ?> 
                                            <h3>
                                                <?php echo insut_kses($title_1); ?>
                                            </h3>
                                        </div>
                                         <div class="desc">  
                                           <?php echo wpautop($excerpt_content); ?>
                                         </div>
                                        <?php if( $show_more_active == 'yes' ):  ?> 
                                        <a class="insut-btn" href="<?php echo esc_url( $link  ); ?>">
                                        <?php if( $settings['show_more_icon']['value'] == '' ): ?>
                                          <i class="icofont-ui-user"></i>
                                        <?php else: ?> 
                                          <?php \Elementor\Icons_Manager::render_icon( $settings['show_more_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif; ?> 
                                        <?php echo esc_html($show_more_text);  ?></a>

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php     
                                    endwhile; 
                                    wp_reset_postdata();
                            
                                ?>
                                <!-- Tab Item 01 End -->
                            <?php endif; ?>
                 
                        </div>
                        <!-- Tab Content End -->
                    </div>
                </div>
            
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }

    protected function get_service_list(){
        $_list = [];
        $args = array(
              'numberposts'      => -1,
              'orderby'          => 'post_date',
              'order'            => 'DESC',
              'post_type'        => 'quomodo-service',
              'post_status'      => 'publish',
              'suppress_filters' => false
        );
  
        $services = get_posts($args);
   
        if($services):
         // Loop the posts
           foreach ($services as $feature):
             $_list[$feature->ID] = $feature->post_title; 
           endforeach;
        endif;
  
        return $_list;  
    }
}