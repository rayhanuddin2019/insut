<?php
namespace InsutEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use InsutEssential\Base\Repository\Contacts_Model;

if ( ! defined( 'ABSPATH' ) ) exit;


class Contacts_Search extends Widget_Base {


    public $base;

    public function get_name() {
        return 'insut-contact-search';
    }

    public function get_title() {
        return esc_html__( 'Contact Search Result', 'insut-essential' );
    }

    public function get_icon() { 
        return "fa fa-search";
    }

    public function get_categories() {
        return [ 'insut-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'insut-essential'),
            ]
        );

            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Style1', 'insut-essential' ),
                       
            
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__(' Content', 'insut-essential'),
            ]
        );
  

                $this->add_control(
                    'search_title', [
                        'label' => esc_html__( 'Search Result Query Title', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Search Result Found for %s' , 'insut-essential' ),
                        'description' => esc_html__( 'You can use %s for variable search query' , 'insut-essential' ),
                        'label_block' => true,
                    ]
                );
                
                $this->add_control(
                    'post_count', [
                        'label' => esc_html__( 'Post Limit', 'insut-essential' ),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'default' => 10,
                        'label_block' => true,
                    ]
                );


      $this->end_controls_section();
           
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_search_result_style', [
				'label' => esc_html__( 'Search result title', 'insut-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'search_title_color', [

                        'label'     => esc_html__( 'Title color', 'insut-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .search-result' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'search_title_typho',
                        'label'    => esc_html__( 'Typography', 'insut-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .search-result',
                    ]
                );

                $this->add_responsive_control(
                    'search_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .search-result' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'search_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .search-result' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section('insut_serial_color_section',
            [
            'label' => esc_html__( 'Serial number', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'serial_number_background',
                    'label'    => esc_html__( 'Background', 'insut-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .contact-search-item > span',
                ]
            );

            $this->add_control(
                'serial_colorsearch_title_color', [

                    'label'     => esc_html__( 'Title color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .contact-search-item > span' => 'color: {{VALUE}};',
          
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'serial_ityen_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .contact-search-item > span',
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section('insut_label_section',
            [
            'label' => esc_html__( 'Label', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'label_colorsearch_title_color', [

                    'label'     => esc_html__( 'Title color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .contact-search-item ul li span' => 'color: {{VALUE}};',
        
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'label_ityen_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .contact-search-item ul li span',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('insut_content_section',
            [
            'label' => esc_html__( 'Content', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'content_colorsearch_title_color', [

                    'label'     => esc_html__( 'Title color', 'insut-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .contact-search-item ul li' => 'color: {{VALUE}};',
        
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'content_ityen_typho',
                    'label'    => esc_html__( 'Typography', 'insut-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .contact-search-item ul li',
                ]
            );


            $this->add_responsive_control(
            'content_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'insut-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .contact-search-item ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section('insut_items_section',
            [
            'label' => esc_html__( 'Item', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'item_section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .contact-search-item',
                    ]
                );
            
                $this->add_responsive_control(
                'item_box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .contact-search-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'item_box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .contact-search-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

        $this->end_controls_section();
        
        $this->start_controls_section('insut_box_section',
            [
            'label' => esc_html__( 'Section', 'insut-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'insut-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'insut-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

     $this->end_controls_section();
    
      
    } //Register control end

    protected function render( ) { 

        $settings     = $this->get_settings();
        $search_title = $settings['search_title'];
       // $q = $_REQUEST['c_search'];
 
        $contacts_model  = new Contacts_Model();
        $contacts_model->setSettings($settings);
       // $contacts_model->setSearch_Query($_REQUEST['c_search']);
        //$contacts_model->setSearch_Query('Ibn');
        //$contacts_model->setType('branch');
         
        $data =  $contacts_model->get_posts();

	    
    ?>
        

        <section class="contact-search-area main-section">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h3 class="search-result"> 
                                    <?php

                                        if(isset($_REQUEST['c_search'])): 
                                        echo sprintf($search_title,$_REQUEST['c_search']);
                                        else:   
                                            echo esc_html__('Nothing search','insut'); 
                                        endif;

                                    ?>       
                            </h3>  
                            <?php foreach($data as $contact): ?>  
                                <div class="contact-search-item">
                                <span>1</span>
                                    <h3 class="title"> <?php echo esc_html(get_the_title($contact)); ?> </h3>
                                    <ul>
                                        <li><span><?php echo esc_html__('Address:','insut-essential'); ?> </span> <?php echo esc_html(get_post_meta($contact->ID,'insut_address',true)); ?> </li>
                                        <li><span><?php echo esc_html__('Email:','insut-essential'); ?> </span> <a href="mailto:<?php echo esc_attr(get_post_meta($contact->ID,'insut_email',true)); ?>"><?php echo esc_html(get_post_meta($contact->ID,'insut_email',true)); ?></a></li>
                                        <li><span><?php echo esc_html__('Telephone:','insut-essential'); ?> </span> <?php echo esc_html(get_post_meta($contact->ID,'insut_phone',true)); ?></li>
                                        <li><span><?php echo esc_html__('Working Hours:','insut-essential'); ?> </span> <?php echo esc_html(get_post_meta($contact->ID,'insut_working_hours',true)); ?></li>
                                    </ul>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </section>
   
    <?php  
  
    }
    
    protected function _content_template() { }
}