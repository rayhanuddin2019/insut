<?php
/**
 * @package  Appscres-essential
 * Load header footer template
 */
namespace InsutEssential\Modules\Header_Footer\Settings;
use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Page {

    public function register() {

	    if ( !file_exists( WP_PLUGIN_DIR . '/elementor/elementor.php' ) ) {
         return;
        }

        add_action( 'carbon_fields_loaded', array( $this, 'set_page_settings' ) );
	
    }

    public function set_page_settings(){

        Container::make( 'theme_options', 'Settings' )
        ->set_icon( 'dashicons-admin-tools' )
        ->set_page_parent( 'edit.php?post_type=qheader-footer' ) // reference to a top level container
        ->add_fields(
             array(
            Field::make( 'select', 'quomodo_hf_module_activate', __( 'Activate Header Footer Builder' ) )
            ->set_options( array(
                '--' => esc_html__( 'None', 'insut-essential' ),
                'yes' => esc_html__( 'Yes', 'insut-essential' ),
                'no'  => esc_html__( 'No', 'insut-essential' ),
                 
            ) ),
            // header
            Field::make( 'select', 'quomodo_hf_module_header_activate', __( 'Activate Header Builder' ) )
   
            ->set_options( array(
                '--' => esc_html__( 'None', 'insut-essential' ),
                'yes' => esc_html__( 'Yes' , 'insut-essential' ),
                'no'  => esc_html__( 'No' ,'insut-essential'),
                 
            ) ),
            // footer
            Field::make( 'select', 'quomodo_hf_module_footer_activate', __( 'Activate Footer Builder' ) )
            ->set_options( array(
                '--' => esc_html__( 'None', 'insut-essential' ),
                'yes' => esc_html__( 'Yes', 'insut-essential' ),
                'no'  => esc_html__( 'No', 'insut-essential' ),
                 
            ) )
        ) );
	

    }

    
}