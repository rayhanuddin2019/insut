<?php
/**
 * @package  Appscres-essential
 * Load header footer template
 */
namespace InsutEssential\Modules\Header_Footer\Base;


class Template {

    public function register() {

	    if ( !file_exists( WP_PLUGIN_DIR . '/elementor/elementor.php' ) ) {
         return;
		}
		
		if(get_option('_quomodo_hf_module_activate') != 'yes') {
           return; 
		}
		
        add_action( 'wp', array( $this, 'hooks' ) );
		add_action( 'wp_head', array( $this, 'wp_head' ) );
		add_action( 'quomodo_header_builder', array( $this, 'header_template' ), 10 );	
		
        // Get Footer Template
    	add_action( 'quomodo_footer_builder', array( $this, 'footer_template' ), 10 );
    	add_filter( 'quomodo_header_page_override', array( $this, 'header_page_override' ), 10 );
    	add_filter( 'quomodo_footer_page_override', array( $this, 'footer_page_override' ), 10 );

	}
	
	public function header_page_override(){
		
		$id                    = '--';
		$page_id               = '--';
		
		// page override
		if(is_page()){

			$page_id = insut_meta_option( get_the_ID(), 'builder_header_layout_style','--' );
		}
		
		if( is_numeric( $page_id ) ){

		   return $page_id;
		}else{

			$builder_header_layout = insut_option('builder_header_layout','0');
	    
			if( $builder_header_layout == '0' ){
	
				return false;
			}
	
			$id = insut_option('builder_header_layout_style','--');
		   
			if( $id == '--' ){
				return false;
			}

		}
		return $id;
	}

	public function footer_page_override(){
		//
		$id                    = '--';
		$page_id               = '--';
		
		// page override
		if(is_page()){

			$page_id = insut_meta_option( get_the_ID(), 'builder_footer_layout_style','--' );
		}
		
		if( is_numeric( $page_id ) ){

		   return $page_id;
		}else{

			$builder_header_layout = insut_option('builder_footer_layout','0');
			
			if( $builder_header_layout == '0' ){
	
				return false;
			}
	
			$id = insut_option('builder_footer_layout_style','--');
			
			if( $id == '--' ){
				return false;
			}

		}

		return $id;
	}

    public function hooks() {

		if( get_option( '_quomodo_hf_module_header_activate' ) == 'yes' ) {  

			add_action( 'get_header', array( $this, 'render_header' ) );
    	}
		
		if( get_option( '_quomodo_hf_module_footer_activate' ) == 'yes' ) {  

			add_action( 'get_footer', array( $this, 'render_footer' ) );
		}
		
	}

	public function wp_head() {
		wp_reset_postdata();
    }

    public function header_template() {
        
		if( get_option('_quomodo_hf_module_header_activate') != 'yes' ) { 
            return;
		}

		$path  = INSUT_ESSENTIAL_PLUGIN_PATH . 'app/Modules/Header_Footer/Templates/content/content-header.php';
        
        $header = $this->display_template( );
        $this->render( $header, $path );
		
    }

    public function footer_template() {
		
		if( get_option('_quomodo_hf_module_footer_activate') != 'yes' ) { 
            return;
		}
	
		$path   = INSUT_ESSENTIAL_PLUGIN_PATH . 'app/Modules/Header_Footer/Templates/content/content-footer.php';
		$footer = $this->display_template( 'all' ,'footer');
        $this->render( $footer, $path );
	
    }
    
    public function render( $header, $path ) {

		if ( $header->have_posts() ) {

			while ( $header->have_posts() ) {
				$header->the_post();
				load_template( $path );
			}

			wp_reset_postdata();
		}
	}
    
    /**
	 * Get Header Site.
	 *
	 * @return Header Site.
	 */
	public function render_header() {

        $header_id = $this->template_header_id();
      	if ( $header_id ) {

			require INSUT_ESSENTIAL_PLUGIN_PATH . 'app/Modules/Header_Footer/Templates/default/header.php';
			$templates   = array();
			$templates[] = 'header.php';
			// Avoid running wp_head hooks again.
			remove_all_actions( 'wp_head' );
			ob_start();
			
			locate_template( $templates, true );
			ob_get_clean();

		}
	}

	/**
	 * Get Footer Site.
	 *
	 * @return Footer Site.
	 */
	public function render_footer() {

        $footer_id = $this->template_footer_id();
        
		if ( $footer_id ) {

            require INSUT_ESSENTIAL_PLUGIN_PATH . 'app/Modules/Header_Footer/Templates/default/footer.php';
			$templates   = array();
			$templates[] = 'footer.php';
			// Avoid running wp_footer hooks again.
			remove_all_actions( 'wp_footer' );
			ob_start();
			locate_template( $templates, true );
			ob_get_clean();

		}
    }
    
    /**
	 * Get Header Template ID.
	 *
	 * @return Mixed (int) $id or (Boolean) false | ID Header Teamplate or false if not found
	 */
	public function template_header_id() {
		    
		   $header = $this->display_template(); 
		   if( !$header ){
			   return false;
		   }
			while ( $header->have_posts() ) {
				$header->the_post();
				$id = get_the_ID();
			}
			wp_reset_postdata();

			return $id;
		
    }

    public function template_footer_id( ) {
		    
        $footer = $this->display_template($page_type='all', $type = 'footer'); 
		
		if(! $footer ){
		  return false;	 
		 }

         while ( $footer->have_posts() ) {
             $footer->the_post();
             $id = get_the_ID();
		 }
		 
         wp_reset_postdata();

         return $id;
     
	}
	
	

    public function display_template( $page_type = 'all' , $type = 'header' ) {
		
		if ( empty( $page_type ) ) {
			return false;
		}
		
		$args = [
			'post_type' => 'nothing'
		];

		$override = false;

		if($type == 'header'){
			
			$override = apply_filters("quomodo_header_page_override",false); 
			
			if( $override ){

				$args = array(
					'p'         => $override, 
					'post_type' => 'qheader-footer'
				);
	
			} 

		}
		
		if($type == 'footer'){
			
			$override = apply_filters("quomodo_footer_page_override",false); 

			if( $override ){

				$args = array(
					'p'         => $override, 
					'post_type' => 'qheader-footer'
				);
	
			}  

		}
		
		
		
		$header = new \WP_Query( $args );

		if ( $header->have_posts() ) {

			return $header;
		} else {
			return false;
		}
	}
    
}