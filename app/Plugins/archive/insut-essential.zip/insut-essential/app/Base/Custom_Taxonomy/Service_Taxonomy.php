<?php
/**
 * @package  insut-essential
 */
namespace InsutEssential\Base\Custom_Taxonomy;
use InsutEssential\Api\Callbacks\Custom_Taxonomy;

class Service_Taxonomy extends Custom_Taxonomy
{

    public $name         = 'service-cat';
    public $menu         = 'Service Category';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = false;
    public $slug         = 'service-cats';
    public $search       = true;

	public function register() {

    	add_action( 'init', array( $this, 'create_taxonomy' ) );
    }
    
    public function create_taxonomy(){

        $this->init('service-cat', esc_html__('Category','insut-essential'), esc_html__('Category','insut-essential'), 'quomodo-service');

       $this->register_taxonomy();
    }
}