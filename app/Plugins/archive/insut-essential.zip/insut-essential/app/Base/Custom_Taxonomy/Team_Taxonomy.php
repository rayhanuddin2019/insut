<?php
/**
 * @package  Appscres-essential
 */
namespace InsutEssential\Base\Custom_Taxonomy;
use InsutEssential\Api\Callbacks\Custom_Taxonomy;

class Team_Taxonomy extends Custom_Taxonomy
{

    public $name         = 'teams';
    public $menu         = 'teams';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = false;
    public $slug         = 'team';
    public $search       = true;

	public function register() {

    	add_action( 'init', array( $this, 'create_taxonomy' ) );
    }
    
    public function create_taxonomy(){

        $this->init('team-cat', esc_html__('Category','insut-essential'), esc_html__('Category','insut-essential'), 'qomodo-teams');

       $this->register_taxonomy();
    }
}