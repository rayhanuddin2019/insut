<?php
namespace InsutEssential\Base\Repository;

Class Contacts_Model {

    
    public $args = [
        'post_type'  => 'quomodo-contacts',
        'post_status'      => 'publish',
        'suppress_filters' => false,
    ];
    public $settings = [];
    public function setSettings($settings=[]){
      
        if( !is_array( $settings ) ){
            return; 
        }  
        $this->settings = $settings;
        $this->args['posts_per_page'] = $settings['post_count'];
    }
    
    public function setSearch_Query($s = null){

        $this->args['s'] = $s;
    }

    public function setType($type = 'branch'){
        
        $this->args['meta_query'][] = array(
            'key'   => 'insut_contacts_type',
            'value' => $type,
        );
    }

    public function get(){
      
        $query = new \WP_Query( $this->args );
       
        if( $query->have_posts() ) {
            return $query;
        } else {

            return false;
        } 

    }
    public function get_posts($single=false){

        $this->args['numberposts'] = $this->settings['post_count'];
       
        $query = get_posts( $this->args );
        if($single==true){
            return isset($query[0])?$query[0]:false;
        }
        return $query;

    } 
}