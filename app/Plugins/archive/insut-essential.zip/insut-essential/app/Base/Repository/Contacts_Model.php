<?php
namespace InsutEssential\Base\Repository;

Class Contacts_Model {

    
    public $type = 'branch';
    public $agent = null;
    public $address = null;
    public $post_count = '10';
    public $q = '';
    public $settings = [];
    public function setSettings($settings=[]){
      
        if( !is_array( $settings ) ){
            return; 
        }  

        $this->post_count = isset($settings['post_count'])?$settings['post_count']:10;
       
    }
    
    public function setSearch_Query($s = null){

        $this->q = esc_sql($s);
    }

    public function setType($type = 'branch'){
        
       $this->type = esc_sql($type);
    }

    public function setAddress($address = null){
        
        $this->address = esc_sql($address);
     }

    public function setAgent($agent = null){
        
        $this->agent = esc_sql($agent);
    }  

    public function get_posts($single=false){

        try {
            global $wpdb;
             

             if(is_null( $this->address) ){
                    $querystr = "
                    SELECT $wpdb->posts.* 
                    FROM $wpdb->posts, $wpdb->postmeta
                    WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id 
                    AND $wpdb->postmeta.meta_key = 'insut_contacts_type' 
                    AND $wpdb->postmeta.meta_value = '{$this->type}' 
                    AND $wpdb->posts.post_title LIKE '%{$this->q}%' 
                    AND $wpdb->posts.post_status = 'publish' 
                    AND $wpdb->posts.post_type = 'quomodo-contacts'
                    ORDER BY $wpdb->posts.post_date DESC LIMIT {$this->post_count}
                ";
             }else{
                
                $querystr = "
                SELECT $wpdb->posts.* 
                FROM $wpdb->posts, $wpdb->postmeta
                WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id 
                AND $wpdb->postmeta.meta_key = 'insut_address' 
                AND $wpdb->postmeta.meta_value LIKE '%{$this->address}%' 
                AND $wpdb->posts.post_title LIKE '%{$this->agent}%' 
                AND $wpdb->posts.post_status = 'publish' 
                AND $wpdb->posts.post_type = 'quomodo-contacts'
                ORDER BY $wpdb->posts.post_date DESC LIMIT {$this->post_count}
            "; 
              
             } 

            $pageposts = $wpdb->get_results($querystr, OBJECT);
            return $pageposts;

        } catch (Exception $e) {
             return false;
        }  
        
    } 
}