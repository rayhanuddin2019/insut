<?php 
/**
 * @package  quomodo
 */
namespace InsutEssential\Base;

class BaseController
{
	public $plugin_path;

	public $plugin_url;

	public $plugin;

	public function __construct() {
		$this->plugin_path = INSUT_ESSENTIAL_PLUGIN_PATH;
		$this->plugin_url  = INSUT_ESSENTIAL_PLUGIN_URL;
		$this->plugin      = INSUT_ESSENTIAL_PLUGIN;
	}
}