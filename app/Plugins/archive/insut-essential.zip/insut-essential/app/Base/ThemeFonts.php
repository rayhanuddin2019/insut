<?php
namespace InsutEssential\Base;

/**
 * Fonts.
 * credited by Sabberworm
 */
class ThemeFonts
{
     /**
	 * register default hooks and actions for WordPress
	 * @return
	 */
	public function register()
	{
  
        add_filter( 'csf_field_icon_add_icons', [$this,'csf_ico_font_icons'] );
     
    }
   

    function csf_ico_font_icons($icons){
        
        $new_icons = [
            'insut-Icon5',
            'insut-Icon8',
            'insut-Icon9',
            'insut-Icon10',
            'insut-Icon12',
            'insut-Icon13',
            'insut-Icon14',
            'insut-Icon15',
            'insut-Icon16',
            'insut-Icon17',
            'insut-Icon18',
            'insut-Icon3',
            'insut-Icon4',
        ];

        $icons[]  = array(
            'title' => esc_html__('Icofonts','insut-essential'),
            'icons' => $this->insut_csf_get_icons_lists()
        );
        
        $icons[]  = array(
            'title' => esc_html__('Custom Icon','insut-essential'),
            'icons' => $new_icons
        );

        //
        // Move custom icons to top of the list.
        $icons = array_reverse( $icons );

        return $icons;
    }
    function insut_csf_get_icons_lists() {
   
       
        $exclude_prefix2 = ':before';
        $exclude_prefix3 = '::before';
        $exclude_prefix4 = '.';
      
        $exclude_prefix5 = ':root';
        $parse_icons      = new \Sabberworm\CSS\Parser(file_get_contents(INSUT_CSS_DIR . '/icofont.min.css'));
        $parseDocument    = $parse_icons->parse();
        $data            = [];
      
        $pattern = "/class/i";
    
        foreach($parseDocument->getAllDeclarationBlocks() as $oBlock) {
            foreach($oBlock->getSelectors() as $oSelector) {
    
                if(!preg_match($pattern, $oSelector)){
    
                     $data[] = str_replace([$exclude_prefix2,$exclude_prefix3,$exclude_prefix4], ['','','',''], $oSelector->getSelector()); 
               
                } 
               
            }
        }
    
        return $data;
    }


}


