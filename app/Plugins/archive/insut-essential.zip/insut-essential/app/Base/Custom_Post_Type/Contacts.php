<?php
/**
 * @package  insut-essential
 */
namespace InsutEssential\Base\Custom_Post_Type;
use InsutEssential\Api\Callbacks\Custom_Post;

class Contacts extends Custom_Post
{

    public $name         = 'Contacts';
    public $menu         = 'Contacts';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = true;
    public $slug         = 'quomodo-contacts';
    public $search       = true;

	public function register() {

        $this->textdomain = 'insut-essential';
        $this->posts      = array();

		add_action( 'init', array( $this, 'create_post_type' ) );
    }
    
    public function create_post_type(){
         
       
        if( insut_option('contacts_name') !='' ){
            $this->name = insut_option('contacts_name');    
        }
        
        if( insut_option('contacts_menu') !='' ){
            $this->menu = insut_option('contacts_menu');    
        }
        
        if( insut_option('contacts_exclude_from_search') ){
            $this->search = true;    
        }else{
            $this->search = false;    
        } 
        
        if( insut_option('contacts_details_page') ){
            $this->public_quary = true;    
        }else{
            $this->public_quary = false;    
        }

        if(insut_option('contacts_slug_name') !=''){
            $this->slug = insut_option('contacts_slug_name');    
        }
         
        $this->init( 'quomodo-contacts', $this->name, $this->menu, array( 'menu_icon' => 'dashicons-admin-users',
          
            'supports'            => array( 'title'),
            'rewrite'             => array( 'slug' => $this->slug ),
            'exclude_from_search' => $this->search,
            'has_archive'         => false,                                            // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
        ) 

       );

       $this->register_custom_post();
    }
}