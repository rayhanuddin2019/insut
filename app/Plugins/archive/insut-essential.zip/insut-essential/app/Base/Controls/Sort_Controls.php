<?php 
namespace InsutEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use InsutEssential\Base\BaseController;

class Sort_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('insut_section_sort_tab' , array( $this, 'settings_section' ),10,2 );
	}

	public function settings_section( $ele,$widget ) 
	{
           $ele->start_controls_section(
            'section_sort_tab',
                [
                    'label' => esc_html__('Sort / order', 'insut-essential'),
                ]
            );
                
            $ele->add_control(
                'post_sortby',
                [
                    'label'     =>esc_html__( 'Post sort by', 'insut-essential' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'latestpost',
                    'options'   => [
                            'latestpost'    => esc_html__( 'Latest', 'insut-essential' ),
                            'popularposts'  => esc_html__( 'Popular / most view', 'insut-essential' ),
                            'mostdiscussed' => esc_html__( 'Most discussed', 'insut-essential' ),
                            'fb_share'      => esc_html__( 'Most fb share', 'insut-essential' ),
                            'tranding'      => esc_html__( 'Tranding', 'insut-essential' ),
                        ],
                ]
            );
    
            $ele->add_control(
                'post_order',
                [
                    'label'     =>esc_html__( 'Post order', 'insut-essential' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'DESC',
                    'options'   => [
                            'DESC'      =>esc_html__( 'Descending', 'insut-essential' ),
                            'ASC'       =>esc_html__( 'Ascending', 'insut-essential' ),
                        ],
                ]
            );
            do_action( 'insut_section_sort_tab_extra_control', $ele, $widget );    
            $ele->end_controls_section();	
	}
}