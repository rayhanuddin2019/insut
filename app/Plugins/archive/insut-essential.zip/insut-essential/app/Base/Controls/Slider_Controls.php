<?php 
namespace InsutEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use InsutEssential\Base\BaseController;

class Slider_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('insut_section_slider_tab' , array( $this, 'settings_section' ), 10 , 2 );
	}

	public function settings_section( $ele,$widget ) 
	{
           $ele->start_controls_section(
            'section_slider_tab',
                [
                    'label' => esc_html__('Slider Controls', 'insut-essential'),
                ]
            );
            
            $ele->add_control(
                'slider_enable',
                [
                    'label'        => esc_html__( 'Enable Slider', 'insut-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'insut-essential' ),
                    'label_off'    => esc_html__( 'No', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                   
                ]
            );
            $ele->add_responsive_control(
                'insut_slider_items',
                [
                    'label'   => esc_html__( 'Items', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 20,
                    'step'    => 1,
                    'default' => 1
                   
                ]
            );

            $ele->add_control(
                'insut_slider_loop',
                    [
                    'label'        => esc_html__( 'Loop', 'insut-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'insut-essential' ),
                    'label_off'    => esc_html__( 'No', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'no'
                    ]
            );

            $ele->add_control(
                'insut_slider_autoplay',
                    [
                    'label'        => esc_html__( 'Autoplay', 'insut-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'insut-essential' ),
                    'label_off'    => esc_html__( 'No', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'no'
                    ]
            );
     
            $ele->add_control(
                'insut_slider_autoplay_timeout',
                [
                    'label'   => esc_html__( 'Autoplay timeout', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 20000,
                    'step'    => 1,
                   
                ]
            );
        
            $ele->add_control(
                'insut_slider_smart_speed',
                [
                    'label'   => esc_html__( 'Smart Speed', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 20000,
                    'step'    => 1,
                   
                ]
            );
             
            $ele->add_control(
                'insut_slider_nav_show',
                    [
                    'label'        => esc_html__( 'Nav', 'insut-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'insut-essential' ),
                    'label_off'    => esc_html__( 'No', 'insut-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes'
                    ]
            );

            $ele->add_control(
                'insut_slider_padding',
                [
                    'label'   => esc_html__( 'Padding', 'insut-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 200,
                    'step'    => 1,
                   
                ]
            );

            $ele->add_responsive_control(
                'slick_slide_image_width',
                [
                   'label'      => esc_html__( 'Item Width', 'insut-essential' ),
                   'type'       => Controls_Manager::SLIDER,
                   'size_units' => [ 'px'],
                   'range'      => [
                      'px' => [
                         'min'  => 50,
                         'max'  => 800,
                         'step' => 1,
                      ],
                   
                   ],
                
                   'selectors' => [
                      '{{WRAPPER}} .slick-slide' => 'width: {{SIZE}}{{UNIT}} !important;',
                   ],
                ]
             );
    
         
            do_action( 'insut_section_slider_tab_extra_control', $ele, $widget );    
            $ele->end_controls_section();	
	}
}