<?php
namespace InsutEssential\Base;

/**
 * Fonts.
 * credited by Sabberworm
 */
class Custom_Fonts
{
     /**
	 * register default hooks and actions for WordPress
	 * @return
	 */
	public function register()
	{

        add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'insut_the_ico_fonts_icons' ) );
        add_filter( 'csf_field_icon_add_icons', [$this,'csf_ico_font_icons'] );
 
    }
    function csf_ico_font_icons($icons){
     
        $icons[]  = array(
            'title' => esc_html__('Icofonts','insut-essential'),
            'icons' => $this->insut_csf_get_icons_lists()
        );

        //
        // Move custom icons to top of the list.
        $icons = array_reverse( $icons );

        return $icons;
        }
    function insut_csf_get_icons_lists() {
   
       
        $exclude_prefix2 = ':before';
        $exclude_prefix3 = '::before';
        $exclude_prefix4 = '.';
      
        $exclude_prefix5 = ':root';
        $parse_icons      = new \Sabberworm\CSS\Parser(file_get_contents(INSUT_CSS_DIR . '/icofont.min.css'));
        $parseDocument    = $parse_icons->parse();
        $data            = [];
      
        $pattern = "/class/i";
    
        foreach($parseDocument->getAllDeclarationBlocks() as $oBlock) {
            foreach($oBlock->getSelectors() as $oSelector) {
    
                if(!preg_match($pattern, $oSelector)){
    
                     $data[] = str_replace([$exclude_prefix2,$exclude_prefix3,$exclude_prefix4], ['','','',''], $oSelector->getSelector()); 
               
                } 
               
            }
        }
    
        return $data;
    }
    function insut_get_icons_lists() {
   
        $exclude_prefix  = '.icofont-';
        $exclude_prefix2 = ':before';
        $exclude_prefix3 = '::before';
        $exclude_prefix4 = '.';
        $exclude_prefix5 = ':root';
        $parse_icons      = new \Sabberworm\CSS\Parser(file_get_contents(INSUT_ESSENTIAL_CSS_DIR . '/icofont.min.css'));
        $parseDocument    = $parse_icons->parse();
        $data            = [];
      
        $pattern = "/class/i";
    
        foreach($parseDocument->getAllDeclarationBlocks() as $oBlock) {
            foreach($oBlock->getSelectors() as $oSelector) {
    
                if(!preg_match($pattern, $oSelector)){
    
                     $data[] = str_replace([$exclude_prefix, $exclude_prefix2,$exclude_prefix3,$exclude_prefix4,$exclude_prefix5], ['','', '','',''], $oSelector->getSelector()); 
               
                } 
               
            }
        }
    
        return $data;
    }

   

    function insut_the_ico_fonts_icons( $tabs = array() ) {

        // Append new icons
        $new_icons = $this->insut_get_icons_lists();
        
        $tabs['insut-icofont-icon'] = array(
            'name'          => 'insut-icofont-icon',
            'label'         => esc_html__( 'Ico Fonts', 'insut' ),
            'labelIcon'     => 'fas fa-user',
            'prefix'        => 'icofont-',
            'displayPrefix' => 'icofont',
            'url'           => INSUT_ESSENTIAL_CSS.'/icofont.min.css',
            'icons'         => $new_icons,
            'ver'           => '1.0.0',
        );
    
        return $tabs;
    }

}


