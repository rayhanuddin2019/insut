<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Custom_Controls_Manager extends Controls_Manager {
    const RADIOIMAGE = 'radioimage';
  
} 