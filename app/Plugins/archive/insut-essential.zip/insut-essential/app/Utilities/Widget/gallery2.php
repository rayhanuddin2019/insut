<?php

if( class_exists( 'CSF' ) ) {

  //
  // Create a gallery widget
  //
  CSF::createWidget( 'insut_widget_gallery_two', array(
    'title'       => esc_html__( 'Insut Gallery 2', 'insut-essential' ),
    'classname'   => 'widget-instagram',
    'description' => esc_html__( 'Insut Gallery 2', 'insut-essential' ),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
          ),

          array(

            'id'     => 'image_list',
            'type'   => 'repeater',
            'title'   => esc_html__( 'Image list' , 'insut-essential' ),
            'fields' => array(
          
                 array(
                    'id'      => 'title',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
                ),
                array(
                  'id'           => 'image',
                  'type'         => 'upload',
                  'title'        => esc_html__( 'Image Upload' , 'insut-essential' ),
                  'library'      => 'image',
                  'placeholder'  => 'http://',
                  'button_title' => esc_html__( 'Add Image', 'insut-essential' ),
                  'remove_title' => esc_html__( 'Remove Image', 'insut-essential' ),
                ),
           
                array(
                    'id'      => 'link',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Link' , 'insut-essential' ),
                ),

                array(
                    'id'      => 'open_in_new_tab',
                    'type'    => 'checkbox',
                    'title'   =>  esc_html__( 'Open In Tab ' , 'insut-essential' ),
                    'label'   => esc_html__( 'Check link Open in new tab' , 'insut-essential' ),
                    'default' => true // or false
                  ),
              
            ),
        ),

      

    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'insut_widget_gallery_two' ) ) {
    function insut_widget_gallery_two( $args, $instance ) {
      
      echo $args['before_widget'];
    
      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }
      ?>
       <?php if(is_array( $instance['image_list'])): ?>
                <div class="insta-shots clearfix">
                    <?php foreach($instance['image_list'] as $item): ?>
                      
                        <a target="<?php echo esc_attr($item['open_in_new_tab']?'_blank':'_self'); ?>" href="<?php echo esc_url($item['link']) ?>">
                            <?php if($item['image'] !=''): ?>
                              <img src=" <?php echo esc_url($item['image']) ?>" alt=" <?php echo esc_attr($item['title']) ?>">
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?> 
     <?php
   

      echo $args['after_widget'];

    }
  }

}
