<?php

if( class_exists( 'CSF' ) ) {

  //
  // Create a cta widget
  //
  CSF::createWidget( 'insut_widget_cta_button', array(
    'title'       => esc_html__( 'Insut CTA Widget', 'insut-essential' ),
    'classname'   => 'footer-cta',
    'description'       => esc_html__( 'Insut CTA button with title', 'insut-essential' ),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
          ),

        array(
            'id'      => 'content',
            'type'    => 'textarea',
            'title'   =>  esc_html__( 'Content' , 'insut-essential' ),
        ),

        array(
            'id'    => 'icon',
            'type'  => 'icon',
            'title'   => esc_html__( 'Button Icon' , 'insut-essential' ),
        ),

        array(
              'id'      => 'link',
              'type'    => 'text',
              'title'   =>  esc_html__( 'Button Link' , 'insut-essential' ),
        ),

        array(
            'id'      => 'button_text',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Button text' , 'insut-essential' ),
        ),

      

    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'insut_widget_cta_button' ) ) {
    function insut_widget_cta_button( $args, $instance ) {
       $content = str_replace(['{', '}'], ['<span>', '</span>'], $instance['content']);
      echo $args['before_widget'];
    
      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }
      ?>
       <h3 class="sec-title">
           <?php echo insut_kses( $content ); ?>  
        </h3>
        <a class="insut-btn" href="<?php echo esc_url($instance['link']); ?>">
            <i class="<?php echo esc_attr($instance['icon']); ?>"></i>
            <?php echo esc_html($instance['button_text']); ?>
        </a>
     <?php
   

      echo $args['after_widget'];

    }
  }

}
