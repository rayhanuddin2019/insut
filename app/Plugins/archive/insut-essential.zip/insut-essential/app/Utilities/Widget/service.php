<?php

if( class_exists( 'CSF' ) ) {

  //
  // Create a service widget
  //
  CSF::createWidget( 'insut_widget_service_list', array(
    'title'       => esc_html__( 'Insut Service', 'insut-essential' ),
    'classname'   => 'service-list',
    'description' => esc_html__( 'Insut Service list', 'insut-essential' ),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
          ),
          array(

            'id'     => 'service_list',
            'type'   => 'repeater',
            'title'   => esc_html__( 'Service Menu' , 'insut-essential' ),
            'fields' => array(
          
                array(
                    'id'    => 'icon',
                    'type'  => 'icon',
                    'title'   => esc_html__( 'Icon' , 'insut-essential' ),
                ),
                
                array(
                    'id'      => 'title',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Title' , 'insut-essential' ),
                ),

                array(
                    'id'      => 'link',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Link' , 'insut-essential' ),
                ),
                array(
                    'id'      => 'open_in_new_tab',
                    'type'    => 'checkbox',
                    'title'   =>  esc_html__( 'Open In Tab ' , 'insut-essential' ),
                    'label'   => 'Yes, Please do it.',
                    'default' => true // or false
                  ),
              
            ),
        ),

      

    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'insut_widget_service_list' ) ) {
    function insut_widget_service_list( $args, $instance ) {
      
      echo $args['before_widget'];
    
      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }
      ?>
       <?php if(is_array( $instance['service_list'])): ?>
                <ul>
                    <?php foreach($instance['service_list'] as $item): ?>
                        <li>
                            <a target="<?php echo esc_attr($item['open_in_new_tab']?'_blank':'_self'); ?>" href="<?php echo esc_url($item['link']) ?>">
                                <?php if($item['icon'] !=''): ?>
                                <i class=" <?php echo esc_attr($item['icon']) ?> "></i>
                                <?php else: ?> 
                                    <i class="icofont-arrow-right"></i>
                                <?php endif; ?> 
                                <?php echo esc_html($item['title']) ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?> 
     <?php
   

      echo $args['after_widget'];

    }
  }

}
