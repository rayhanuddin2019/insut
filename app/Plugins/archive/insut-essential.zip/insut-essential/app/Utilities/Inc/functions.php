<?php 


if(!function_exists('insut_return')):
    function insut_return($str){
        return $str;
    }
endif;

/**
 * 
 *
 * get widgets class list
 *
 * @since 1.0
 * @return array
 */
if(!function_exists('insut_widgets_class_list')):

    function insut_widgets_class_list($dir){
       $classes = [];
        foreach (glob("$dir/*.php") as $filename) {
            if(!is_null(basename( $filename))){
                $classes[] = strtok( basename($filename),'.') ;
            }
           
        }
        return $classes;
    }
    
endif;


function insut_errors(){
    static $wp_error; // Will hold global variable safely
    return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
}

// get theme setting option
if( !function_exists('insut_carbon_option')):
    function insut_carbon_option( $key, $default_value = '', $method = 'option' ) {
        
        if ( defined( 'QTRP' ) ) {
            switch ( $method ) {
             
                case 'option':
                    $value = carbon_get_theme_option( $key );
                    break;
                default:
                    $value = '';
                    break;
            }
            return (!isset($value) || $value == '') ? $default_value :  $value;
        }
        return $default_value;
    }
endif;
// get theme post ,page meta option
if( !function_exists('insut_carbon_meta_option')): 
    function insut_carbon_meta_option( $postid, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_post_meta($postid, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get user meta option
if( !function_exists('insut_user_meta_option')): 
    function insut_user_meta_option( $user_id, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_user_meta($user_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get comment meta option
if( !function_exists('insut_comment_meta_option')): 
    function insut_comment_meta_option( $comment_id, $key, $default_value = '' ) {

        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_comment_meta($comment_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;

    }
endif;

 if(!function_exists('insut_get_post_category')) {
    function insut_get_post_category($tax = 'category') {

        static $list = [];
        if( !count( $list ) ) {
         
            $categories = get_terms( $tax, array(
                    'orderby'       => 'name', 
                    'order'         => 'DESC',
                    'hide_empty'    => false,
                    'number'        => 200
            
            ) );
        
            foreach( $categories as $category ) {
            $list[$category->term_id] = $category->name;
            }
        }
       
        return $list;
    }
 }

 if( !function_exists('insut_get_post_tags') ){

    function insut_get_post_tags($tax = 'post_tag') {
   
        static $list = [];

        if( !count( $list ) ) {
           $categories = get_terms( $tax, array(
              'orderby'       => 'name', 
              'order'         => 'DESC',
              'hide_empty'    => false,
              'number'        => 200
             
          ) );
     
          foreach( $categories as $category ) {
             $list[$category->term_id] = $category->name;
          }
          
        }
      
        return $list;
    }
 }

 if(!function_exists('insut_get_post_author')){

    function insut_get_post_author(){
        static $list = [];

        if( !count( $list ) ) {
           $authors = get_users(
                array( 
                    'fields' => array( 'display_name','ID' ) ) 
            );
     
          foreach( $authors as $author ) {
             $list[$author->ID] = $author->display_name;
          }
          
        }
      
        return $list;
    }

 }

 if(!function_exists('insut_get_posts')) {

    function insut_get_posts(){
        static $list = [];

        if( !count( $list ) ) {
           $posts = get_posts(
                [
                'numberposts' => -1,
                'post_status' => 'publish'
                ]
            );
     
          foreach( $posts as $post ) {
             $list[$post->ID] = $post->post_title;
          }
          
        }
      
        return $list;
    }

 }

 function insut_current_theme_supported_post_format(){
   
    static $list = [];

    if( !count( $list ) ) {

        $post_formats = get_theme_support( 'post-formats' );
        
        if(isset($post_formats[0])) {
            $post_formats = $post_formats[0];
        }else{
            return $list;
        }
        
        foreach( $post_formats as $format ) {
            $list['post-format-'.$format] = $format;
        }
      
    }
   
    return $list;
   
 }

 /* elementor Slider control  */

 function insut_widgets_slider_controls_setttings($settings){
    
    $return_controls = [];

    $slider_controls = [
        'insut_slider_items',
        'slider_enable',
        'insut_slider_items_tablet',
        'insut_slider_items_mobile',
        'insut_slider_autoplay',
        'insut_slider_autoplay_timeout',
        'insut_slider_smart_speed',
        'insut_slider_dot_nav_show',
        'insut_slider_nav_show',
        'insut_slider_padding',
        'insut_slider_loop'
    ];   
    
    
    foreach($settings as $key=> $item){

       if(in_array($key,$slider_controls) ){
          $return_controls[$key] = $item;
       } 
      
    }
    
   return $return_controls;
 }
  // get all user created menu list
 function insut_get_all_menus(){

    $list = [];
    $menus = wp_get_nav_menus(); 
    
    foreach($menus as $menu){
        $list[$menu->slug] = $menu->name;
    }
    $list['empty'] = esc_html__('Empty','insut-essential');
    return $list;

 }

 function insut_get_border_style(){

    $borders_class = [
        'border_white_right'  => esc_html__( 'Right', 'insut-essential' ),
        'border_white_left'   => esc_html__( 'Left', 'insut-essential'),
        'border_white_bottom' => esc_html__( 'Bottom', 'insut-essential'),
        'border_white_top'    => esc_html__( 'Top', 'insut-essential'),
        'border_none'         => esc_html__( 'None', 'insut-essential' ),
    ];

    return $borders_class;
 }

    
    if(!function_exists('insut_meta_option')){
        function insut_meta_option( $postid, $key, $default_value = '', $parent_key = 'insut_post_options' ) {
           
           $post_key = $parent_key;
           // page meta
           if(is_singular( 'page' )){
              $post_key = 'insut_page_options';
           }
            // post meta
           if(is_singular('post')){
              $post_key = 'insut_post_options';
           }
           // custom post meta
     
     
           if( class_exists( 'CSF' ) ){
              $options = get_post_meta( get_the_ID(), $post_key, true );
              return ( isset( $options[$key] ) ) ? $options[$key] : $default_value; 
              
           }
           
           return $default_value;
        }
     }
   

    

     if( !function_exists('insut_term_option')):
        
        function insut_term_option( $termid, $key, $default_value = '', $taxomony = 'category') {
           
           if ( defined( 'FW' ) ) {
                $value = fw_get_db_term_option($termid, $taxomony, $key);
            }
           
           return (!isset($value) || $value == '') ? $default_value :  $value;
        }

    endif;