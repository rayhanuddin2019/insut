<?php 
  /*************************************
/*******  Theme svg file support  ********
**************************************/
    if(!function_exists('insut_mime_types')){

        function insut_mime_types($mimes) {
            $mimes['svg'] = 'image/svg+xml';
            return $mimes;
        }
        
    }
   
add_filter('upload_mimes', 'insut_mime_types');
/*************************************
/*******  Contact Form 7 Auto p  ********
**************************************/
add_filter('wpcf7_autop_or_not', '__return_false');

/*************************************
/*******  Load More widget Blog  ********
**************************************/


function insut_blog_post_widget_ajax_loading_cb()
{   
    $data = $_POST['ajax_json_data'];
    $arg  = $data['args'];
   
    $allpostloding = new WP_Query($arg);
    extract($data['settings']);

    if ( $allpostloding->have_posts() ) :

        while($allpostloding->have_posts()){
            
            $allpostloding->the_post(); 
            include INSUT_ESSENTIAL_PLUGIN_PATH.'/app/Widgets/Content/blog.php'; 
        
        }

    else:

       echo wp_send_json(['found'=>$allpostloding->found_posts]);     

    endif;

    wp_reset_postdata();
    wp_die();
  
}

add_action( 'wp_ajax_nopriv_insut_post_widget_ajax_loading', 'insut_blog_post_widget_ajax_loading_cb' );
add_action( 'wp_ajax_insut_post_widget_ajax_loading', 'insut_blog_post_widget_ajax_loading_cb' );

