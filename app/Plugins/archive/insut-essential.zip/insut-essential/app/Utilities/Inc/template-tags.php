<?php
/*
* here add template part file like html part  
*/

function author(){
   echo "<div>";
     echo "<h3> author </h3>";
   echo "</div>";
}