<?php
/**
 * @package  Appscres-essential
 */
namespace InsutEssential;
use InsutEssential\Modules\Header_Footer\Init as Header_Footer;

final class Init
{
	/**
	 * Store all the classes inside an array
	 * @return array Full list of classes
	 */
	public static function get_services() 
	{
		return [
		
			Base\Enqueue::class,
			Api\ElementorQuomodoEssentialExtension::class,
			Controls\Custom_Css::class,
			Base\SettingsLinks::class,
			Base\ThemeOption::class,
			Base\SignUp::class,
			Base\SignIn::class,
			// custom post
			Base\Custom_Post_Type\Service::class,
			
			
			//elementor
			Base\Controls\Generel_Controls::class,
			Base\Controls\Slider\Generel_Controls::class,
			Base\Controls\Data_Exclude_Controls::class,
			Base\Controls\Date_Filter_Controls::class,
			Base\Controls\Taxonomy_Filter_Controls::class,
			Base\Controls\Sort_Controls::class,
			Base\Controls\Slider_Controls::class,
			Base\Controls\Sticky_Controls::class,
		
			// WP widgets
			Base\WPWidgets\Socials::class,
			Base\WPWidgets\Author::class,
			Base\WPWidgets\Instragram::class,
			Base\WPWidgets\Recent_Post::class,
			Base\WPWidgets\Category::class,
	
			
		

			
		];
	}

	/**
	 * Loop through the classes, initialize them, 
	 * and call the register() method if it exists
	 * @return
	 */
	public static function register_services() 
	{
		foreach ( self::get_services() as $class ) {
			$service = self::instantiate( $class );
			if ( method_exists( $service, 'register' ) ) {
				$service->register();
			}
		}
	}

	public static function register_modules(){
		
			Header_Footer::register_services();
		
		
	}

	/**
	 * Initialize the class
	 * @param  class $class    class from the services array
	 * @return class instance  new instance of the class
	 */
	private static function instantiate( $class )
	{
		$service = new $class();

		return $service;
	}
}



