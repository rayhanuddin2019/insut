<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class Counter extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodo-marketplace-counter';
    }

    public function get_title() {
        return esc_html__( 'Quomodo Market Counter', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Quomodo Market Counter settings', 'quomodo-market-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'quomodo-market-essential' ),
					//'style2' => esc_html__( 'Style 2', 'quomodo-market-essential' ),
				],
			]
		);
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'quomodo-market-essential' ),
				'label_block' => true,
			]
		);
     
		$repeater->add_control(
			'list_number', [
				'label'      => esc_html__( 'Number', 'quomodo-market-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '25' , 'quomodo-market-essential' ),
				'show_label' => true,
			]
        );

        $repeater->add_control(
			'list_number_suffix', [
				'label'      => esc_html__( 'Number Suffix', 'quomodo-market-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '+' , 'quomodo-market-essential' ),
				'show_label' => true,
			]
        );

        $repeater->add_control(
			'list_number_days', [
				'label'      => esc_html__( 'Days', 'quomodo-market-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '7' , 'quomodo-market-essential' ),
				'show_label' => false,
			]
        );
      
		$repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );
        
        $repeater->add_control(
			'list_image',
			[
				'label' => esc_html__( 'Image', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				
				
			]
		);
     
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Counter List', 'quomodo-market-essential' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 

 
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
                ],
                
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .product-counter-item' => 'text-align: {{VALUE}};',
                     

				],
			]
        );//Responsive control end
        $this->end_controls_section();
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .counter-title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_control(
                    'title_hover_color', [

                        'label'     => esc_html__( 'Title Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .product-counter-item:hover .counter-title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .counter-title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .counter-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Number', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .counter-number' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                $this->add_control(
                    'number_hover_color', [

                        'label'     => esc_html__( 'Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .product-counter-item:hover .counter-number' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_number_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .counter-number',
                    ]
                );

                
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .counter-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .counter-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section('appscred_item_icon_box_style',
            [
            'label' => esc_html__( 'Icon Box', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_box_color', [

                'label'     => esc_html__( 'Icon Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .product-counter-item i' => 'color: {{VALUE}};',
                '{{WRAPPER}} .product-counter-item svg path' => 'fill: {{VALUE}};',
                
                ],
            ]
        );
 
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'icon_box_typho',
                'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .product-counter-item .icon i',
                'selector' => '{{WRAPPER}} .product-counter-item icon svg',
            ]
        );
     
        $this->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'icon_border_hv_background',
                'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .product-counter-item .icon',
            ]
        );
   
        $this->add_responsive_control(
            'icon_box_n_padding',
            [
                'label'      => esc_html__( 'Icon Padding', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .product-counter-item .icon img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .product-counter-item .icon svg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .product-counter-item .icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            '_icon_npx_m_margin',
            [
                'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .product-counter-item .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section('appscred_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_responsive_control(
                '_item_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .product-counter-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .product-counter-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );   
     
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => '_item_section_border_background',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .product-counter-item',
                    ]
            );

        $this->end_controls_section();

       
        $this->start_controls_section('appscred_main_section',
                [
                'label' => esc_html__( 'Section', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
	    $list  = $settings['list'];
    ?>
        <?php if($settings['style'] == 'style1'): ?>

            <div class="main-section" >
              <div class="row justify-content-center">
                <?php foreach($list as $item): ?> 
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="product-counter-item mt-30">
                            <div class="icon">
                                <?php if($item['list_image']['url'] !=''): ?>
                                    <img src=" <?php echo esc_url($item['list_image']['url']); ?> " alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                               <?php else: ?>
                                <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                               <?php endif; ?>
                            </div>
                            <h4 class="title counter-number"> 
                                <span class="count"><?php echo esc_html($item['list_number']); ?></span><?php echo esc_html($item['list_number_suffix']); ?>
                                <?php if($item['list_number_days']): ?>
                                 <span class="count"><?php echo esc_html($item['list_number_days']); ?>
                                 </span>
                                <?php endif; ?>
                             </h4>
                            <span class="counter-title"><?php echo esc_html($item['list_title']); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?> 
                </div>
            </div>
                
        <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}