<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Team extends Widget_Base {

    public $base;

    public function get_name() {
        return 'quomodo-marketplace-team';
    }

    public function get_title() {
        return esc_html__( 'Insut Team', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-users";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Insut Team', 'quomodo-market-essential'),
            ]
        );

        $this->add_control(

            'style', [
                'label'   => esc_html__('Choose Style', 'quomodo-market-essential'),
                'type'    => Custom_Controls_Manager::RADIOIMAGE,
                'default' => 'style1',
                'options' => [
                        'style1' => [
                                'title'      => esc_html__( 'Style 1', 'quomodo-market-essential' ),
                                'imagelarge' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/team/style2.png',
                                'imagesmall' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/team/style2.png',
                                'width'      => '50%',
                        ],
                   
                ],

            ]
        ); 

        $this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );

        $this->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'quomodo-market-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Name here', 'quomodo-market-essential' ),
				'default'     => esc_html__( 'Adam', 'quomodo-market-essential' ),
               
				
			]
        );
      
        $this->add_control(
			'designation', [
				'label'       => esc_html__( 'Designation', 'quomodo-market-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Designation here', 'quomodo-market-essential' ),
				'default'     => esc_html__( 'CEO & Founder', 'quomodo-market-essential' ),
               
				
			]
        );

   
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                    
                     '{{WRAPPER}} .team-item' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Content', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .member-name' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .member-name',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .member-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
           
           //  designation
            $this->add_control(
                'designation_color', [

                    'label'     => esc_html__( 'Designation color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .member-designation' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'designation_typho',
                    'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .member-designation',
                ]
            );

            $this->add_responsive_control(
                'designation_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .member-designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'designation_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .member-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );    

        $this->end_controls_section();
      

        $this->start_controls_section('appscred_image_section',
                [
                'label' => esc_html__( 'Image', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_responsive_control(
                'image_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-item img'   => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                       
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'image_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .team-item img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                      
                    ],
                    'separator' => 'before',
                ]
            );
            $this->end_controls_section();  
            
            $this->start_controls_section('appscred_box__main_section',
                [
                'label' => esc_html__( 'Box', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
       
         
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .team-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .team-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                      
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'service_list_section_background',
                    'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .team-item',
                   
                ]
            );

            $this->add_control(
                '_section_box_radius',
                    [
                        'label' => esc_html__( 'Border radius', 'quomodo-market-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                       
                        'selectors' => [
           
                            '{{WRAPPER}} .team-item' => 'border-radius: {{VALUE}}px;',
                    ],
                ]
            ); 
    
            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'main_section_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
                    'selector' => '{{WRAPPER}} .team-item',
              
                ]
            );

           $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'section_item_content_section_border',
                    'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
                    'selector' => '{{WRAPPER}} .team-item',
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings    = $this->get_settings();
       
    ?>
         <?php if($settings['style'] == 'style1'): ?>
            <div class="team-item  mt-30 animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="0ms">
                <img class="member-img" src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                <h4 class="title member-name"><?php echo esc_html($settings['name'] ); ?></a></h4>
                <?php if($settings['designation'] !=''): ?>
                <span class="member-designation"><?php echo esc_html($settings['designation'] ); ?></span>
                <?php endif; ?>
            </div>   
         <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}