<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class Intro_Banner extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodo-marketplace-intro-banner';
    }

    public function get_title() {
        return esc_html__( 'Intro Banner', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fab fa-adversal";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'quomodo-market-essential'),
            ]
        );
            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'quomodo-market-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Style1', 'quomodo-market-essential' ),
                       
            
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__('Intro Banner Content', 'quomodo-market-essential'),
            ]
        );
 

        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'quomodo-market-essential' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'content', [
				'label' => esc_html__( 'Content', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'List Content' , 'quomodo-market-essential' ),
				'show_label' => true,
			]
        );

        $this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );
        
        $this->add_control(
            'button_text', [
                'label'       => esc_html__( 'Button text', 'quomodo-market-essential' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'button_url', [
                'label'       => esc_html__( 'Button Url', 'quomodo-market-essential' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
            ]
        );


	

      $this->end_controls_section();
    
     
      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
              
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Sub Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .content' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .content',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        
        

        $this->start_controls_section(
			'section_submit_button_style', [
				'label' => esc_html__( 'Button ', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                $this->add_responsive_control(
                    'input_submit_width',
                    [
                        'label'      => esc_html__( 'Width', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0,
                                'max'  => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .main-btn' => 'width:{{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
                $this->add_responsive_control(
                    'input_submit_height',
                    [
                        'label'      => esc_html__( 'Height', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'max' => 150,
                            ],
                        ],
                    
                        'selectors' => [
                            '{{WRAPPER}} .main-btn' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_control(
                    'button_color2', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .main-btn' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv2', [

                        'label'     => esc_html__( 'Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .main-btn:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho2',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );

               
                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading_2',
                    [
                        'label' => esc_html__( 'Background color', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background2',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-btn::before',
                    ]
                );
                $this->add_control(
                    'button_background_hv__heading__2',
                    [
                        'label' => esc_html__( 'Background hover color', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input__section_hv_background_2',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'quomodo-market-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .main-btn' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .main-btn::before' => 'border-radius: {{VALUE}}px;',
                               
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border2',
                        'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );


        $this->end_controls_section();
        
        
      
		
        $this->start_controls_section('appscred_box_section',
            [
            'label' => esc_html__( ' Section', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .hero-area::before',
                    ]
                );

                $this->add_control(
                    'manin_section_ovberlay_color', [

                        'label'     => esc_html__( 'Background overlay color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-area' => 'background: {{VALUE}};',
                        ],
                    ]
                );
                
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

     $this->end_controls_section();
      
    } //Register control end

    protected function render( ) { 

		$settings    = $this->get_settings();
        $banner_title      = str_replace(['{', '}'], ['<span>', '</span>'], $settings['title']);
        $button_url  = $settings['button_url'];
        $button_text = $settings['button_text'];
    
    ?>
        <!--====== BANNER PART START ======-->
    <?php if($settings['layout'] == 'style1'): ?>
        <section class="hero-area main-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="hero-content">
                            <h1 class="title animated wow fadeInDown" data-wow-duration="3000ms" data-wow-delay="0ms"> <?php echo quomodo_market_kses($banner_title); ?> </h1>
                            <?php if($settings['content'] !=''): ?>
                                <p class=" animated wow fadeInLeft content" data-wow-duration="3000ms" data-wow-delay="300ms"> <?php echo esc_html($settings['content']); ?> </p>
                            <?php endif; ?>
                            <?php  if( $settings['button_text'] !='' ): ?> 
                                <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>" data-wow-duration="3000ms" data-wow-delay="600ms"  href="<?php echo esc_url($button_url['url']) ?>" class="quomodo-marketplace-btn main-btn animated wow fadeInUp">
                                    <?php echo esc_html( $settings['button_text'] ); ?>
                                </a>
                            <?php endif; ?> 

                        </div>
                    </div>
                </div>
            </div>
            <?php if($settings['image']['url'] !=''): ?>
                <div class="hero-thumb">
                    <img src=" <?php echo esc_url($settings['image']['url']); ?> " alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                </div>
            <?php endif; ?>
    </section>
   
    <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}