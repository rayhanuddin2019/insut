<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use QuomodoMarketEssential\Base\Repository\Base_Modal;
if ( ! defined( 'ABSPATH' ) ) exit;

class Post_Block extends Widget_Base {

  public $base;

    public function get_name() {
        return 'quomodo-marketplace-post-block';
    }

    public function get_title() {
        return esc_html__( 'Insut Blog ', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return 'eicon-nav-menu';
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

         $this->start_controls_section(
               'section_layouts_tab',
               [
                  'label' => esc_html__('Layout', 'quomodo-market-essential'),
               ]
         );

            $this->add_control(

               'block_style', [
                  'label'   => esc_html__('Choose Style', 'quomodo-market-essential'),
                  'type'    => Custom_Controls_Manager::RADIOIMAGE,
                  'default' => 'style1',
                  'options' => [
                     'style1' => [
                        'title'      => esc_html__( 'Style 1', 'quomodo-market-essential' ),
                        'imagelarge' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/blog/style1.png',
                        'imagesmall' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/blog/style1.png',
                        'width'      => '100%',
                     ],
                     'style2' => [
                        'title'      => esc_html__( 'Style 2', 'quomodo-market-essential' ),
                        'imagelarge' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/blog/style2.png',
                        'imagesmall' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/blog/style2.png',
                        'width'      => '100%',
                     ],
    
               ],

               ]
            ); 

      $this->end_controls_section();

       do_action( 'quomodomarket_section_general_tab', $this, $this->get_name() );
       do_action( 'quomodomarket_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'quomodomarket_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'quomodomarket_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'quomodomarket_section_sort_tab', $this , $this->get_name());  
       do_action( 'quomodomarket_section_sticky_tab', $this , $this->get_name());  
        // Style
          
        $this->start_controls_section('quomodomarket_style_title_section',
        [
           'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'quomodo-market-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .title a' => 'color: {{VALUE}};',
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'quomodo-market-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}}  .title a:hover' => 'color: {{VALUE}};',
                
                  ],
               ]
            );
            $this->add_group_control(
               Group_Control_Typography::get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                  'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                  'selector' => '{{WRAPPER}} .title a',
               ]
            );
            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}}  .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
             ]
            );
            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}}  .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                  ],
               ]
            );
      $this->end_controls_section();

      $this->start_controls_section('quomodomarket__post_content_section',
         [
            'label'     => esc_html__( 'Content ', 'quomodo-market-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'block_style' => ['style2'] ],   
         ]
     );

         $this->add_control(
            'block_content_color',
            [
               'label'   => esc_html__('Color', 'quomodo-market-essential'),
               'type'    => Controls_Manager::COLOR,
               'default' => '',
               
               'selectors' => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'color: {{VALUE}};',
               ],
            ]
         );

        
         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
               'name'     => 'post_content_typography',
               'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
               'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
               'selector' => '{{WRAPPER}} .signle__blog__content .post-desc',
            ]
         );
         $this->add_responsive_control(
         'content_margin',
         [
            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}}  .signle__blog__content .post-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'content_padding',
            [
               'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();
      $this->start_controls_section('quomodomarket_style_pcontent_section',
      [
         'label'     => esc_html__( 'Post meta', 'quomodo-market-essential' ),
         'tab'       => Controls_Manager::TAB_STYLE,
        
      ]
     );
  
     $this->add_control(
       'post_meta_date_color',
         [
             'label' => esc_html__('Date color', 'quomodo-market-essential'),
             'type'  => Controls_Manager::COLOR,
             
             'selectors' => [
                 '{{WRAPPER}} .meta__date'    => 'color: {{VALUE}};',
             
             ],
         ]
       ); 
 
       $this->add_group_control(
         Group_Control_Typography::get_type(),
         [
             'name'     => 'meta_other_typography',
             'label'    => esc_html__( ' Date Typography', 'quomodo-market-essential' ),
             'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
             'selector' => '{{WRAPPER}} .meta__date',
           
         ]
     );  

     // author
     
      $this->add_control(
         'post_meta_author_color',
         [
               'label' => esc_html__('Author color', 'quomodo-market-essential'),
               'type'  => Controls_Manager::COLOR,
               
               'selectors' => [
                  '{{WRAPPER}} .meta__author a'    => 'color: {{VALUE}};',
               
               ],
         ]
         ); 

         $this->add_group_control(
         Group_Control_Typography::get_type(),
         [
               'name'     => 'meta_author_typography',
               'label'    => esc_html__( ' Author Typography', 'quomodo-market-essential' ),
               'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
               'selector' => '{{WRAPPER}} .meta__author',
            
         ]
      ); 
     //cat
     $this->add_control(
      'post_category_color',
      [
         'label'     => esc_html__('Category Color', 'quomodo-market-essential'),
         'type'      => Controls_Manager::COLOR,
         'default'   => '',
         'selectors' => [

            '{{WRAPPER}} .tags' => 'color: {{VALUE}};',
      
         ],
      ]
      ); 
      $this->add_group_control(
         Group_Control_Typography::get_type(),
         [
             'name'     => 'meta_category_typography',
             'label'    => esc_html__( 'Category Typography', 'quomodo-market-essential' ),
             'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
             'selector' => ' {{WRAPPER}} .post-thumb .tags, {{WRAPPER}} .post-thumb-round .tags ',
             
         ]
     );
      $this->add_group_control(
         \Elementor\Group_Control_Background::get_type(),
         [
            'name'     => 'categhory_style5_background',
            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
            'types'    => [ 'classic', 'gradient', 'video' ],
            //'condition' => [ 'block_style' => ['style5'] ],
            'selector' => '{{WRAPPER}} .post-thumb .tags, {{WRAPPER}} .post-thumb-round .tags',
         ]
      );
       $this->add_responsive_control(
         'category_borders_radius',
         [
            'label'      => esc_html__( 'Categoy Border radius', 'quomodo-market-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],

            'selectors' => [
               
               '{{WRAPPER}} .post-thumb .tags' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               '{{WRAPPER}} .post-thumb-round .tags' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
              
               
               
            ],
         ]
      );
      $this->add_responsive_control(
         'post__meta_margin',
         [
             'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => [ 'px','%'],
             'selectors'  => [
                   '{{WRAPPER}} .tags'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
             ],
         ]
     );
     
     $this->end_controls_section();
 
      $this->start_controls_section('quomodomarket_image_section',
         [
            'label' => esc_html__( 'Image', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );

      $this->add_responsive_control(
         'image_margin',
            [
               'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .post-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .post-thumb-round' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

         $this->add_responsive_control(
            'post_img_borders__radius',
            [
               'label'      => esc_html__( 'Image Border radius', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .post-thumb img'   => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .post-thumb-round img'   => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
          
                  
               ],
            ]
         );
           
  
         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ,'%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .post-thumb img' => 'height: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .post-thumb-round img' => 'height: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image Width', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .post-thumb img' => 'width: {{SIZE}}{{UNIT}};',
                  '{{WRAPPER}} .post-thumb-round img' => 'width: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
      
          
      $this->end_controls_section();

      $this->start_controls_section('quomodomarket_single_box_section',
         [
            'label' => esc_html__( 'Post item', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
   
      $this->add_responsive_control(
         'item_borders_radius',
         [
            'label'      => esc_html__( 'Border radius', 'quomodo-market-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            
            'selectors' => [
               
               '{{WRAPPER}} .single__blog__post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Box_Shadow::get_type(),
         [
            'name'     => 'single_post_box_shadow',
            'label'    => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );
   
      $this->add_group_control(
         \Elementor\Group_Control_Background::get_type(),
         [
            'name'     => 'single_box_background',
            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
            'types'    => [ 'classic', 'gradient', 'video' ],
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );
   
     $this->add_responsive_control(
      'single_box_margin',
      [
         'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%'],
         'selectors'  => [
            '{{WRAPPER}} .single__blog__post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
         ],
      ]
      );

      $this->add_responsive_control(
         'single_box_padding',
         [
            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .single__blog__post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Box_Shadow::get_type(),
         [
            'name' => 'insuts_post_box_item_box_shadow',
            'label' => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section('quomodomarket_box_section',
         [
            'label' => esc_html__( ' Section', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
    
      $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        
        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );
      $this->end_controls_section();

      $this->start_controls_section('quomodomarket_post_icon_section',
         [
               'label'     => esc_html__( 'Post Icon', 'quomodo-market-essential' ),
               'tab'       => Controls_Manager::TAB_STYLE,
            
         ]
      );

      $this->add_control(
         'show_mid_icon',
         [
            'label'     => esc_html__('Show Icon', 'quomodo-market-essential'),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
            'label_off' => esc_html__('No', 'quomodo-market-essential'),
            'default'   => 'yes',
           
         ]
   );

      $this->add_control(
         'post_icon__color',
            [
               'label'     => esc_html__('Color', 'quomodo-market-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [
      
                  '{{WRAPPER}} .post-icon i' => 'color: {{VALUE}};',
            
               ],
            ]
         ); 

         $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => '_post_icon_ypography',
                'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER} .post-icon i,{{WRAPPER} .post-icon',
                
            ]
        );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name'     => '_post_icon_bg_style_background',
               'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               //'condition' => [ 'block_style' => ['style5'] ],
               'selector' => '{{WRAPPER}} .post-icon',
            ]
         );

      $this->end_controls_section();

    
   
      
        $this->start_controls_section('quomodomarket_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'quomodo-market-essential' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
                 
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%' ],
                     'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%' ],
                        'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border::get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'quomodo-market-essential' ),
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'selector' => '{{WRAPPER}} .readmore__btn',
               ]
            );
            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'quomodo-market-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .readmore__btn' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography::get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                     'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
               ]
            );
            $this->add_control(
               'readmore_bottom_border_hide',
               [
                  'label' => esc_html__( 'Border hide', 'quomodo-market-essential' ),
                  'type' => \Elementor\Controls_Manager::SELECT,
                  'default' => 'block',
                  'options' => [
                     'block'  => esc_html__( 'Show', 'quomodo-market-essential' ),
                     'none' => esc_html__( 'None', 'quomodo-market-essential' ),
                  ],
                  'selectors' => [
                     '{{WRAPPER}} .read-more:before' => 'display: {{VALUE}};',
                     '{{WRAPPER}} .read-more:after' => 'display: {{VALUE}};',
               
                  ],
               ]
            );
            $this->add_control(
               'readmore_bottom_border_color',
                  [
                     'label'     => esc_html__('Bottom border Color', 'quomodo-market-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} .read-more:before' => 'background: {{VALUE}};',
                        '{{WRAPPER}} .read-more:after' => 'background: {{VALUE}};',
                  
                     ],
                  ]
            ); 

      $this->end_controls_section();

    }

    protected function render( ) { 
      
        $settings       = $this->get_settings();
        
        $data           = new Base_Modal($settings);
        $query          = $data->get();
        
        if( !$query ){
          return;  
        }
  
     ?>
         <?php if($settings['block_style'] == 'style1'): ?>
            <!-- Blog Section Start -->
            <section class="blog-section main-section">
                  <div class="container">
                  
                     <div class="row">
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                              <div class="col-lg-4 col-md-6">
                                    <!-- Single Post Start -->
                                    <div class="single-post single__blog__post">

                                       <?php if(has_post_thumbnail()): ?>

                                                <div class="post-thumb">
                                                   <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                                                   
                                                   <?php if($settings['show_cat'] =='yes'): ?>
                                                               <?php

                                                                  $categories = get_the_category();
                                                                  if ( ! empty( $categories) ) {
                                                                     echo '<a class="tags" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                                                                  }

                                                               ?>
                                                   <?php endif; ?>

                                                   <?php 
                                                         $image_icon = quomodomarket_meta_option(get_the_id(), 'image_icon','','quomodomarket_post_options' );
                                                   ?>

                                                   <?php if( $settings['show_mid_icon'] == 'yes' ): ?>
                                                         <div class="post-icon"> <i class="<?php echo esc_attr( $image_icon==''?'icofont-home':$image_icon ); ?>"></i> </div>
                                                   <?php endif; ?>

                                                </div>

                                       <?php endif; ?>

                                       <div class="post-details">

                                                <?php if($settings['show_date'] == 'yes'): ?> 
                                                <span class="meta__date"><?php echo get_the_date(get_option( 'date_format' )); ?></span>
                                               <?php endif; ?>
                                          <h4 class="title">
                                             <a href="<?php the_permalink() ?>"><?php echo esc_html(wp_trim_words( get_the_title(),$settings['post_title_crop'] )); ?></a>
                                                </a>
                                          </h4>
                                          <?php if($settings['show_readmore'] == 'yes'): ?>
                                                   <a href="<?php the_permalink() ?>" class="readmore__btn read-more"> <?php echo esc_html($settings['readmore_text']); ?> <i class="icofont-arrow-right"></i></a>
                                             <?php endif; ?>

                                       </div>
                                    </div>
                                    <!-- Single Post End -->
                              </div>
                        <?php endwhile; wp_reset_postdata(); ?> 
                     </div>
                  </div>
            </section>
            <!-- Blog Section End -->
        <?php endif; ?>
        <?php if($settings['block_style'] == 'style2'): ?>
                  <div class="row">
                  <?php while ($query->have_posts()) : $query->the_post(); ?>
                        <div class="col-lg-6 col-md-12">
                              <!-- Single Post Start -->
                              <div class="single-post-round single__blog__post">
                                <?php if(has_post_thumbnail()): ?>
                                    <div class="post-thumb-round">
                                           <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                                          <?php if( $settings['show_cat'] =='yes' ): ?>
                                                   <?php

                                                      $categories = get_the_category();
                                                      if ( ! empty( $categories) ) {
                                                         echo '<a class="tags" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                                                      }

                                                   ?>
                                          <?php endif; ?>
                                    </div>
                                 <?php endif; ?>
                                 <div class="post-details">
                                    <?php if($settings['show_date'] == 'yes'): ?> 
                                         <span class="meta__date"><?php echo get_the_date(get_option( 'date_format' )); ?></span>
                                    <?php endif; ?>
                                    <h4 class="title">
                                       <a href="<?php the_permalink() ?>"><?php echo esc_html(wp_trim_words( get_the_title(),$settings['post_title_crop'] )); ?></a>
                                                </a>
                                    </h4>
                                   
                                    <?php if($settings['show_readmore'] == 'yes'): ?>
                                          <a href="<?php the_permalink() ?>" class="readmore__btn read-more"> <?php echo esc_html($settings['readmore_text']); ?> <i class="icofont-arrow-right"></i></a>
                                    <?php endif; ?>

                                 </div>
                              </div>
                              <!-- Single Post End -->
                        </div>
                    <?php endwhile; wp_reset_postdata(); ?> 
                  </div>
        <?php endif; ?>

       
      <?php  
    }
    

    
}