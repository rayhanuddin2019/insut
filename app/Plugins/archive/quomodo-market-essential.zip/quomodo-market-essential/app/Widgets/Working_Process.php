<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Working_Process extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodo-marketplace-working-process';
    }

    public function get_title() {
        return esc_html__( 'Quomodo market Working Process', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'quomodo-market-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'quomodo-market-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'quomodo-market-essential' ),
                    'imagelarge' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/icon-box/style1.png',
                    'imagesmall' => QUOMODOMARKET_ESSENTIAL_IMG . '/admin/icon-box/style1.png',
                    'width'      => '100%',
               ],

            

           ],

         ]
       ); 
       $this->end_controls_section();
       


        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Content settings', 'quomodo-market-essential'),
            ]
        );
       
      

		$this->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'quomodo-market-essential' ),
				'label_block' => true,
			]
        );
        
        $this->add_control(
			'list_url', [
				'label' => esc_html__( 'Url', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
		);
     
        $this->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );
       
	
 
   
     
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .about-work-item' => 'text-align: {{VALUE}};',
              
				],
			]
        );//Responsive control end

        $this->end_controls_section();
      
        
        
       

        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .title span',
            ]
        );
        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_control(
			'title_section_display_style',
			[
				'label' => esc_html__( 'Display ', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'initial',
				'options' => [
					'block'        => esc_html__( 'Block', 'quomodo-market-essential' ),
					'inline-block' => esc_html__( 'Block Inline', 'quomodo-market-essential' ),
					'none'         => esc_html__( 'None', 'quomodo-market-essential' ),
					'initial'         => esc_html__( 'Default', 'quomodo-market-essential' ),
                ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'display: {{VALUE}};',
                ],
			]
		);
        $this->end_controls_section();

    
        $this->start_controls_section('box_icon_section',
                [
                    'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control(
                'icon_color', [

                    'label'     => esc_html__( 'Icon color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .about-work-item i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .wabout-work-item svg' => 'fill: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'icon_typho',
                    'label'    => esc_html__( 'Icon Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .about-work-item i,{{WRAPPER}} .about-work-item i',
                ]
            );
           
            $this->add_responsive_control(
                'icons_section__margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .about-work-item .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'icon_section_display_style',
                [
                    'label' => esc_html__( 'Display ', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'block',
                    'options' => [
                        'block'        => esc_html__( 'Block', 'quomodo-market-essential' ),
                        'inline-block' => esc_html__( 'Block Inline', 'quomodo-market-essential' ),
                        'none'         => esc_html__( 'None', 'quomodo-market-essential' ),
                        'initial'         => esc_html__( 'Default', 'quomodo-market-essential' ),
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .about-work-item .icon' => 'display: {{VALUE}};',
                    ],
                ]
            );
           
        $this->end_controls_section();
    
         
        // main section
        $this->start_controls_section('appscred_box__main_section',
            [
            'label' => esc_html__( 'Section', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            
            ]
        );
        $this->add_responsive_control(
            '_box_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                  
                    '{{WRAPPER}} .about-work-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                  
                ],
                'separator' => 'before',
            ]
        );
         $this->add_group_control(
           \Elementor\Group_Control_Background::get_type(),
           [
              'name'     => 'main_section_background',
              'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
              'types'    => [ 'classic', 'gradient', 'video' ],
              'selector' => '{{WRAPPER}} .about-work-item ',
           ]
        );
       
       $this->add_responsive_control(
        'main_box_margin',
           [
              'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .about-work-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            
              ],
           ]
        );

        $this->add_responsive_control(
           'main_box_padding',
           [
              'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .about-work-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
              ],
           ]
        );

     $this->end_controls_section();

    
    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
		$process_url = $settings['list_url'];
    
    ?>
   
     <?php if( $settings['block_style'] == 'style1' ): ?>
        <div class="about-work-item animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="0ms">
            <div class="icon">
                <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </div>
            <a target="<?php echo esc_attr( $process_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($process_url['url']) ?>" class="title">
            <span> <?php echo esc_html($settings['list_title']); ?> </span></a>
        </div>
      <?php endif; ?>

   

    <?php  

    }
    
    protected function _content_template() { }
}