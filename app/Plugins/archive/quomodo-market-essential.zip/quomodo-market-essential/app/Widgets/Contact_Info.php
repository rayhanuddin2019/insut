<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class Contact_Info extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodomarket-contact-info';
    }

    public function get_title() {
        return esc_html__( 'Quomodo Market Contact Info', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Quomodo Contact settings', 'quomodo-market-essential'),
            ]
        );
          

		$this->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'quomodo-market-essential' ),
				'label_block' => true,
			]
		);
     
		$this->add_control(
			'list_sub_title', [
				'label'      => esc_html__( 'Sub Title', 'quomodo-market-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'show_label' => true,
			]
        );
      
		$this->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
		);
        $this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				
			]
        );	

 
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .contact-sub-item' => 'text-align: {{VALUE}};',
                     

				],
			]
        );//Responsive control end
        $this->end_controls_section();
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact-sub-item .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_control(
                    'title_hover_color', [

                        'label'     => esc_html__( 'Title Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact-sub-item .title:hover' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .contact-sub-item .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .contact-sub-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Sub title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact-sub-item span' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                $this->add_control(
                    'number_hover_color', [

                        'label'     => esc_html__( 'Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact-sub-item span:hover ' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_number_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .contact-sub-item span',
                    ]
                );
                $this->add_control(
                    'title_section_display_style',
                    [
                        'label' => esc_html__( 'Display ', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => 'block',
                        'options' => [
                            'block'        => esc_html__( 'Block', 'quomodo-market-essential' ),
                            'inline-block' => esc_html__( 'Block Inline', 'quomodo-market-essential' ),
                            'none'         => esc_html__( 'None', 'quomodo-market-essential' ),
                            'initial'         => esc_html__( 'Default', 'quomodo-market-essential' ),
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .contact-sub-item span' => 'display: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .contact-sub-item span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .contact-sub-item span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section('appscred_item_icon_box_style',
            [
            'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_box_color', [

                'label'     => esc_html__( 'Icon Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .icon i' => 'color: {{VALUE}};',
                '{{WRAPPER}} .icon svg path' => 'fill: {{VALUE}};',
                
                ],
            ]
        );

        $this->add_control(
            'icon_box_hv_color', [

                'label'     => esc_html__( 'Icon Hover Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} .icon:hover i ' => 'color: {{VALUE}};',
                
                
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'icon_box_typho',
                'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .icon i',
              
            ]
        );
     
        
        $this->add_responsive_control(
            'icon_box_n_padding',
            [
                'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );
       
        $this->end_controls_section();
        

       
        $this->start_controls_section('appscred_main_section',
                [
                'label' => esc_html__( 'Section', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
                  
                
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
	    $list  = $settings['list'];
    ?>

   
        <div class="contact-sub-item main-section">
            <div class="icon">
                <?php if($settings['image']['url'] !=''): ?>
                    <img src=" <?php echo esc_url($settings['image']['url']); ?> " alt="<?php echo esc_attr($settings['list_title']); ?>">
                <?php else: ?> 
                    <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php endif; ?>    
            </div>
            <h4 class="title"> <?php echo esc_html($settings['list_title']); ?> </h4>
            <span><?php echo esc_html($settings['list_sub_title']); ?></span>
        </div>
   
  
    <?php  

    }
    
    protected function _content_template() { }
}