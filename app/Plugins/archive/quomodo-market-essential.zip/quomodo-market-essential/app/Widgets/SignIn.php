<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class SignIn extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodo-market-signin';
    }

    public function get_title() {
        return esc_html__( 'Quomodo Market SignIn / login', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return 'far fa-user';
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Form heading', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'title', [
                    'label'       => esc_html__( 'Title text', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'heading ', 'quomodo-market-essential' ),
                    'default'     => esc_html__( 'Welcome Back', 'quomodo-market-essential' ),
                ]
            );
            $this->add_control(
                'sub_title', [
                    'label'       => esc_html__( 'Sub Title text', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Please sign in your account', 'quomodo-market-essential' ),
                    'default'     => esc_html__( 'Please sign in your account', 'quomodo-market-essential' ),
                ]
            );

         
      
        $this->end_controls_section();
       

        $this->start_controls_section(
            'section_fields',
            [
                'label' => esc_html__('Fields', 'quomodo-market-essential'),
            ]
        );

        $this->add_control(
            'username_label', [
                'label'			  => esc_html__( 'Username Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Username ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Username ', 'quomodo-market-essential' ),
            
                
            ]
        );
      
        $this->add_control(
            'username_placeholder', [
                'label'			  => esc_html__( 'Username placeholder', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Username here', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Username here', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'password_label', [
                'label'			  => esc_html__( 'Password Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Password ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Password ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'submit_text', [
                'label'			  => esc_html__( 'Submit text', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Submit ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Login  ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_registration',
            [
                'label' => esc_html__('Registration Link', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'reg_link_show',
                [
                    'label'        => esc_html__( 'Show', 'quomodo-market-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );
            $this->add_control(
                'registration_button_title', [
                    'label'       => esc_html__( 'Title text', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'heading ', 'quomodo-market-essential' ),
                    'default'     => esc_html__( 'Do not have account?', 'quomodo-market-essential' ),
                ]
            );
            $this->add_control(
                'button_registration',
                [
                    'label'       => esc_html__( 'Title', 'quomodo-market-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Sign Up', 'quomodo-market-essential' ),
                    'placeholder' => esc_html__( 'Type your title here', 'quomodo-market-essential' ),
                ]
            );
            
            $this->add_control(
                'registration_link',
                [
                    'label'         => esc_html__( 'Link', 'quomodo-market-essential' ),
                    'type'          => \Elementor\Controls_Manager::URL,
                ]
            );  
        
        $this->end_controls_section();

        // forgot password
        $this->start_controls_section(
            'section_forgot_password',
            [
                'label' => esc_html__('Forgot Link', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'forgot_link_show',
                [
                    'label'        => esc_html__( 'Show', 'quomodo-market-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );
       
            $this->add_control(
                'button_forgot_password',
                [
                    'label'       => esc_html__( 'Title', 'quomodo-market-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Forgot Password?', 'quomodo-market-essential' ),
                    'placeholder' => esc_html__( 'Type your title here', 'quomodo-market-essential' ),
                ]
            );
         
        $this->end_controls_section();
        $this->start_controls_section(
            'section_alignment_password',
            [
                'label' => esc_html__('Alignment', 'quomodo-market-essential'),
            ]
        );

        $this->add_responsive_control(
            'header_conten_text_align', [
                'label'   => esc_html__( 'Header', 'quomodo-market-essential' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [

            'left'		 => [
                
                'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                'icon'  => 'fa fa-align-left',
            
            ],
                'center'	     => [
                
                'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                'icon'  => 'fa fa-align-center',
            
            ],
            'right'	 => [

                        'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-right',
                
                    ],
                'justify'	 => [

                        'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-justify',
                
                    ],
                ],
            'default' => 'center',
            
                'selectors' => [
                    '{{WRAPPER}} .sign-in-title' => 'text-align: {{VALUE}};',

                ],
            ]
        );//Responsive control end

            $this->add_responsive_control(
                'form_content_text_align', [
                    'label'   => esc_html__( 'Label', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                        '{{WRAPPER}} .input-box' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .input-link' => 'text-align: {{VALUE}};',
                    

                    ],
                ]
            );//Responsive control end

            
            $this->add_responsive_control(
                'form_formgiot_content_text_align', [
                    'label'   => esc_html__( 'Forgot', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'right',
                
                    'selectors' => [
                
                        '{{WRAPPER}} .forgot' => 'text-align: {{VALUE}};',

                    ],
                ]
            );//Responsive control end
            
            $this->add_responsive_control(
                'form_create_account_content_text_align', [
                    'label'   => esc_html__( 'Create Account', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                
                        '{{WRAPPER}} .create-account' => 'text-align: {{VALUE}};',

                    ],
                ]
            );//Responsive control end

        $this->end_controls_section();
  
        
       

        $this->start_controls_section(
            'ultimate_icon_input_style_section',
            [
                'label' => esc_html__( 'Header', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

         
            
            $this->add_control(
                'headee0_title_color', [

                    'label'		 => esc_html__( 'Title color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .title' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_control(
                'headee0_title_normal_color', [

                    'label'		 => esc_html__( 'Bracket words color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .title span' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_title_typho',
                    'label'    => esc_html__( 'Title Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .sign-in-title .title',
                ]
            );

            
            $this->add_responsive_control(
                'header_ttile_margin',
                [
                    'label'      => esc_html__( 'Title Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .sign-in-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'headee0_content_color', [

                    'label'		 => esc_html__( 'Content color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .content' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_content_typho',
                    'label'    => esc_html__( 'Content Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .sign-in-title .content',
                ]
            );

            
            $this->add_responsive_control(
                'header_content_margin',
                [
                    'label'      => esc_html__( 'Content Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .sign-in-title .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );


            

        $this->end_controls_section();
        
        /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_input_style_section',
            [
                'label' => esc_html__( 'Input', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'input_box_tabs' );
                $this->start_controls_tab(
                    'input_box_normal_tab',
                    [
                        'label' => esc_html__( 'Normal', 'quomodo-market-essential' ),
                    ]
                );
                    $this->add_responsive_control(
                        'input_box_height',
                        [
                            'label'      => esc_html__( 'Height', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'max' => 150,
                                ],
                            ],
                         
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'height:{{SIZE}}{{UNIT}};',
                           
                               
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_width',
                        [
                            'label'      => esc_html__( 'Width', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                           
                            'selectors' => [
                                '{{WRAPPER}} .input'=> 'width:{{SIZE}}{{UNIT}};',
                         
                            ],
                        ]
                    );
                     

                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_label_box_typography',
                            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                            'selector' => '{{WRAPPER}} label',
                              
                        ]
                    );


                    $this->add_control(
                        'input_label_box_label_color',
                        [
                            'label'     => esc_html__( 'Label Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}}  label' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_label_box_margin',
                        [
                            'label'      => esc_html__( 'Label Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_box_typography',
                            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                            'selector' => '{{WRAPPER}} .input',
                              
                        ]
                    );


                    $this->add_control(
                        'input_box_placeholder_color',
                        [
                            'label'     => esc_html__( 'Placeholder Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}}  .input::-webkit-input-placeholder' => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'          => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'      => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder' => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'          => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'      => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder' => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'          => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'      => 'color: {{VALUE}};',
                                
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_box_border',
                            'label'    => esc_html__( 'Border', 'quomodo-market-essential' ),
                            'selector' => ' {{WRAPPER}} .input',
                             
                            
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_border_radius',
                        [
                            'label'     => esc_html__( 'Border Radius', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .input' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                             ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '{{WRAPPER}} .input',   
                            
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}}  .input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                              
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_responsive_control(
                        'input_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_control(
                        'input_box_transition',
                        [
                            'label'      => esc_html__( 'Transition', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'transition: {{SIZE}}s;',
                           

                            ],
                        ]
                    );

                $this->end_controls_tab();
                $this->start_controls_tab(
                    'input_box_hover_tabs',
                    [
                        'label' => esc_html__( 'Focus', 'quomodo-market-essential' ),
                    ]
                );
                $this->add_control(
                    'input_box_hover_color',
                    [
                        'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'  => 'color:{{VALUE}};',
                         
                         
                        ],
                    ]
                );
              
                $this->add_control(
                    'input_box_hover_border_color',
                    [
                        'label'     => esc_html__( 'Border Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'   => 'border-color:{{VALUE}};',
                         ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Box_Shadow:: get_type(),
                    [
                        'name'     => 'input_box_hover_shadow',
                        'selector' => '{WRAPPER}} .input:focus',
                          
                    ]
                );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();


         /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_submit_style_section',
            [
                'label' => esc_html__( 'Submit', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'submit_box_height',
            [
                'label'      => esc_html__( 'Height', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
              
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'height:{{SIZE}}{{UNIT}};',
               
                   
                ],
            ]
        );
        $this->add_responsive_control(
            'submit_box_width',
            [
                'label'      => esc_html__( 'Width', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
              
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'width:{{SIZE}}{{UNIT}};',
             
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'submit_box_typography',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .main-btn',
                   
            ]
        );
        $this->add_control(
            'submit_box_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-btn'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'gradient_submit__background',
                    'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                    'types' => [ 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-btn',
                    
                ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'submit_border',
				'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
				'selector' => '{{WRAPPER}} .main-btn',
			]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'submit_box_shadow',
                'selector' => '{{WRAPPER}} .main-btn',   
                
            ]
        );

        $this->add_responsive_control(
			'submit_btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        
        $this->add_responsive_control(
			'submit_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
     
        $this->add_responsive_control(
            'submit_btn_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors' => [
                  
                  '{{WRAPPER}} .main-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                   
               ],
            ]
         );
        $this->end_controls_section();

        //
        $this->start_controls_section(
            'ultimate_forgot_password_style_section',
            [
                'label' => esc_html__( 'Forgot Password', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'forgot_password_typography',
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .forgot-password',
                    
                ]
            );

            $this->add_control(
                'forgot_password_text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .forgot-password'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'forgot_password__display_style',
                [
                    'label' => esc_html__( 'Display ', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'block',
                    'options' => [
                        'block'        => esc_html__( 'Block', 'quomodo-market-essential' ),
                        'inline-block' => esc_html__( 'Block Inline', 'quomodo-market-essential' ),
                        'none'         => esc_html__( 'None', 'quomodo-market-essential' ),
                        'initial'      => esc_html__( 'Default', 'quomodo-market-essential' ),
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .forgot-password' => 'display: {{VALUE}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'forgot_password_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .forgot-password' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            

            $this->add_responsive_control(
                'forgot_password_password',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .forgot-password' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        
        
        $this->start_controls_section(
            'ultimate_registration_style_section',
            [
                'label' => esc_html__( 'Registration ', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'registration_text_typography',
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .create-account span',
                    
                ]
            );

            $this->add_control(
                'registration_text__text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .create-account span'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'registration_link_text_typography',
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'label'    => esc_html__( 'Link typhography', 'quomodo-market-essential' ),
                    'selector' => '{{WRAPPER}} .create-account .registration',
                    
                ]
            );
            $this->add_control(
                'registration_link___text_color',
                [
                    'label'     => esc_html__( 'Link Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .registration'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'registration_text__margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .create-account' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'registration_text__password',
                [
                    'label'      => esc_html__( 'Link Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .create-account .registration' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section(); 

        $this->start_controls_section(
			'section_box_style', [
				'label' => esc_html__( 'Box', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
        );
          
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_one_box_background',
                        'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types' => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .sign-in-box',
                    ]
                );

                $this->add_group_control(
                    Group_Control_Border::get_type(),
                    [
                        'name' => 'box_border',
                        'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .sign-in-box',
                    ]
                );
       
                $this->add_responsive_control(
                    'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .sign-in-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .sign-in-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

        $this->end_controls_section();

      
        
    
     
    } //Register control end

    protected function render( ) { 

		$settings     = $this->get_settings();
		$title        = $settings['title'];
		
        $title_1      = str_replace(['{', '}'], ['<span>', '</span>'], $title); 
      
    ?>
 

        <div class="sign-in-box">
            <?php

                $errors = [];
                if(isset($_SESSION["quomodomarket_login_msg"])){
                    $errors = $_SESSION["quomodomarket_login_msg"];      
                }       

            ?>
            <?php if( count( $errors) ): ?>
                        <ul class="errors">
                            <?php foreach($errors as $error): ?>
                                <li> <?php echo quomodo_market_kses($error); ?> </li>
                            <?php endforeach; ?>
                            
                        </ul>
            <?php unset($_SESSION["quomodomarket_login_msg"]); 
                    endif; 
            ?>
            <?php if(isset( $_SESSION["quomodomarket_login_success_msg"]) ): ?>
                <h2 class="success"> <?php echo esc_html($_SESSION["quomodomarket_login_success_msg"]); unset($_SESSION["quomodomarket_login_success_msg"]); ?> </h2> 
            <?php endif; ?> 
            <div class="sign-in-title">
                <h3 class="title"><?php echo quomodo_market_kses($title_1); ?></h3>
                <div class="content"><?php echo esc_html($settings['sub_title']); ?></div>
            </div>
            <form action="#">

                <div class="input-box">
                    <label><?php echo esc_html($settings['username_label']); ?></label>
                    <input class="input" type="text" name="username" placeholder="<?php echo esc_html($settings['username_placeholder']); ?>">
                </div>

                <div class="input-box">
                    <label><?php echo esc_html($settings['password_label']); ?></label>
                    <input class="input" name="password" type="password" >
                </div>
                <?php wp_nonce_field('quomodomarket_login_action'); ?>
                <div class="input-link forgot">
                    <?php if($settings['forgot_link_show'] == 'yes'): ?>  
                        <a class="forgot-password" href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php echo esc_html($settings['button_forgot_password']); ?></a>
                    <?php endif; ?>
                    <button class="main-btn mt-25"><?php echo esc_html($settings['submit_text']); ?></button>
                </div>
                
                <div class="input-link create-account">
                    <span>
                        <?php echo esc_html( $settings['registration_button_title'] ) ?> 
                        <?php if($settings['reg_link_show'] == 'yes'): ?>
                          <a class="registration" href="<?php echo esc_url( $settings['registration_link']['url'] ); ?>"> <?php echo esc_html( $settings['button_registration'] ); ?> </a>
                        <?php endif; ?>
                     </span>
                </div>

            </form>
        </div>
    
    <?php  

    }
    
    protected function _content_template() { }
}