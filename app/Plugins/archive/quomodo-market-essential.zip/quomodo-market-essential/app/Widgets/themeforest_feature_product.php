<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class themeforest_feature_product extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodomarket-themeforest-feature-product';
    }

    public function get_title() {
        return esc_html__( 'ThemeForest Feature Product', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('ThemeForest Feature Product', 'quomodo-market-essential'),
            ]
        );

        
        $this->add_control(
			'product_type',
			[
				'label' => esc_html__( 'Product Type', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'wordpress'  => esc_html__( 'WordPress', 'quomodo-market-essential' ),
					'site-templates' => esc_html__( 'Html', 'quomodo-market-essential' ),
					'joomla' => esc_html__( 'Joomla', 'quomodo-market-essential' ),
					'none' => esc_html__( 'None', 'quomodo-market-essential' ),
				],
			]
        );

        $this->add_control(
			'product_count',
			[
				'label' => esc_html__( 'Count', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 4,
			]
        );
        
        $this->add_control(
			'title_limit',
			[
				'label' => esc_html__( 'Title Limit', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 3,
			]
        );
        
        $this->add_control(
			'content_type',
			[
				'label' => esc_html__( 'Content Type', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'sub_title',
				'options' => [
					'sub_title'  => esc_html__( 'Sub title', 'quomodo-market-essential' ),
					'excerpt' => esc_html__( 'Excerpt', 'quomodo-market-essential' ),
				
				],
			]
        );
        $this->add_control(
			'content_limit',
			[
				'label' => esc_html__( 'Content Limit', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 3,
			]
        );
        
        $this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Download Icon', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-download',
					'library' => 'solid',
				],
			]
		);
 
        $this->end_controls_section();
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_control(
                    'title_hover_color', [

                        'label'     => esc_html__( 'Title Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-item:hover .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_product_type_style', [
				'label' => esc_html__( 'Category', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'type_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
              
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'type_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title span',
                    ]
                );

                $this->add_responsive_control(
                    'type_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'type_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'types_section_background',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .title span',
                       
                    ]
                );

              
                $this->add_responsive_control(
                    'type_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors' => [
                            '{{WRAPPER}} .title span'   => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Sub title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-content p' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                $this->add_control(
                    'number_hover_color', [

                        'label'     => esc_html__( 'Hover color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-item:hover .featured-product-content p ' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_number_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .featured-product-content p',
                    ]
                );
               
                
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .featured-product-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .featured-product-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section('appscred_item_icon_box_style',
            [
            'label' => esc_html__( 'Download Icon', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                $this->add_control(
                    'icon_box_color', [

                        'label'     => esc_html__( 'Icon Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-content ul .download-icon i' => 'color: {{VALUE}};',
                    
                        
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'icon_box_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .featured-product-content ul .download-icon i',
                    
                    ]
                );
     
                
                $this->add_responsive_control(
                    'icon_box_n_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .featured-product-content ul .download-icon i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
       
        $this->end_controls_section();
        
        $this->start_controls_section('appscred_item_download_text_box_style',
            [
            'label' => esc_html__( 'Download text', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                    $this->add_control(
                        'icon_text_box_color', [

                            'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .featured-product-content ul .download-icon span' => 'color: {{VALUE}};',
                        
                            
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name'     => 'downlaod_etxt_box_typho',
                            'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                            'selector' => '{{WRAPPER}} .featured-product-content ul .download-icon span',
                        
                        ]
                    );
        
            
                    $this->add_responsive_control(
                        'download_box_n_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .featured-product-content ul .download-icon span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                            'separator' => 'before',
                        ]
                    );
                
            $this->end_controls_section();

            $this->start_controls_section('appscred_item_rating_text_box_style',
                [
                'label' => esc_html__( 'Rating text', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

                $this->add_control(
                    'rating_text_box_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-content ul .rating span' => 'color: {{VALUE}};',
                    
                        
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'rating_etxt_box_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .featured-product-content ul .rating span',
                    
                    ]
                );
            
                
                $this->add_responsive_control(
                    'raritng_box_n_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .featured-product-content ul .rating span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
            
        $this->end_controls_section();

        $this->start_controls_section('appscred_item_rating_star_box_style',
            [
            'label' => esc_html__( 'Rating Star', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                $this->add_control(
                    'rating_starr_active_box_color', [

                        'label'     => esc_html__( 'Active Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [

                        '{{WRAPPER}} .featured-product-content .stars-inner::before' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
        
                $this->add_control(
                    'rating_starr_box_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-content .stars-outer::before' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'rating_star_box_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .featured-product-content .stars-inner,.featured-product-content .stars-outer::before',
                    
                    ]
                );
    
        
                $this->add_responsive_control(
                    'raritng_start_box_n_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .featured-product-content ul .stars-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
            
        $this->end_controls_section();
        $this->start_controls_section('appscred_item_box_ovrlay_style',
            [
            'label' => esc_html__( 'Box overlay', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'main_section_overlay_background',
                    'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .featured-product-overlay',
                ]
            );
             
        $this->end_controls_section();

        $this->start_controls_section('appscred_item_preview_button_style',
            [
            'label' => esc_html__( 'Preview Button', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

      
                $this->add_control(
                    'button_one_box_color', [

                        'label'     => esc_html__( 'Button Preview Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .featured-product-overlay .main-btn' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_one_box_typho',
                        'label'    => esc_html__( ' Button Typography', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn',
                    
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'button_one_overlay_background',
                            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn:hover',
                        ]
                );
                $this->add_control(
                    'button_one_overlay_background_heading',
                    [
                        'label' => __( 'Preview Button Hover', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'button_one_overlay_background_after',
                            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn',
                        ]
                );
                
        $this->end_controls_section();

        $this->start_controls_section('appscred_item_details_button_style',
            [
            'label' => esc_html__( 'Detials Button', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                    $this->add_control(
                        'button_two_box_color', [

                            'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .featured-product-overlay .main-btn-2' => 'color: {{VALUE}};',
                            
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name'     => 'button_two_box_typho',
                            'label'    => esc_html__( ' Button Typography', 'quomodo-market-essential' ),
                            'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn-2',
                        
                        ]
                    );

                    $this->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                            [
                                'name'     => 'button_two_overlay_background',
                                'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                                'types'    => [ 'classic', 'gradient', 'video' ],
                                'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn-2:hover',
                            ]
                    );
                    $this->add_control(
                        'button_two_overlay_background_heading',
                        [
                            'label' => __( 'Details Button Hover', 'quomodo-market-essential' ),
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                            [
                                'name'     => 'button_two_overlay_background_after',
                                'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                                'types'    => [ 'classic', 'gradient', 'video' ],
                                'selector' => '{{WRAPPER}} .featured-product-overlay .main-btn-2',
                            ]
                    );
                    
        $this->end_controls_section();

        $this->start_controls_section('appscred_item_price_box_style',
            [
            'label' => esc_html__( 'Price Box', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'price_box_color', [

                    'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .featured-product-item .box span' => 'color: {{VALUE}};',
                    
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'     => 'price_typhox_typho',
                    'label'    => esc_html__( ' Button Typography', 'quomodo-market-essential' ),
                    'selector' => '{{WRAPPER}} .featured-product-item .box span',
                
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'price_box_bg',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .featured-product-item .box',
                    ]
            );

        $this->end_controls_section();
       
        $this->start_controls_section('appscred_main_section',
                [
                'label' => esc_html__( 'Box', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'quomodo-market-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
                  
                
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

        $settings  = $this->get_settings();
        $category  = '';
       
        if($settings['product_type'] != 'none'){
            $category = $settings['product_type'];
        }
        
        $related_product = quomodo_market_themeforest_popular_product($settings['product_count'],$category);
        
        $title_limit = $settings['title_limit'];
        $content_limit = $settings['content_limit'];
    ?>

            <div class="row justify-content-center">
               <?php while ($related_product->have_posts()) : $related_product->the_post(); ?>
                         <?php

                             $value_id          = get_post_meta( get_the_id(), 'ew_envato_item_id',true);
                             $reserved_data     = quomodo_market_ewSingleitemdata($value_id);
                             $value_rating      = get_post_meta( get_the_id(), 'ew_envato_item_rating',true);
                             $base_rating       =  (integer) $value_rating;
                            
                             $starPercentage    = ($base_rating / 5) * 100;
                             $starPercentageRounded = (($starPercentage / 10) * 10).'%';

                             if(isset($reserved_data["classification"])) {

                                $classification = explode('/',$reserved_data["classification"]);
                                if(in_array("wordpress",$classification) ){
                                  $item_type = esc_html__("WordPress",'quomodo-market-essential');
                                }elseif(in_array("site-templates",$classification) ){
                                  $item_type =  esc_html__("html",'quomodo-market-essential');
                                }elseif(in_array("joomla",$classification) ){
                                  $item_type = esc_html__("joomla",'quomodo-market-essential');
                                }
                                 
                              }
                              // content
                              if($settings['content_type'] == 'excerpt'){
                                  $sub_title = wp_trim_words( get_the_excerpt(), $content_limit, '' );
                              }else{
                                $sub_title         = get_post_meta( get_the_id(), 'ew_envato_item_sub_title',true);
                                $sub_title         = wp_trim_words( $sub_title, $content_limit, '' );
                              }
                           ?>
                    <div class="col-lg-3 col-md-6 col-sm-7">
                        <div class="featured-product-item main-section animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="0ms">
                           
                            <?php if(has_post_thumbnail()): ?>
                                <div class="featured-product-thumb">
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                                </div>
                            <?php endif; ?>
                            <div class="featured-product-content">
                                <h3 class="title"><?php echo esc_html(wp_trim_words(get_the_title(),$title_limit,'')); ?> <span> <?php echo esc_html($item_type); ?> </span></h3>
                                <P><?php echo esc_html($sub_title); ?></P>
                                <ul>
                                    <li class="download-icon"><span><?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo get_post_meta( get_the_id(), 'ew_envato_item_sales',true); ?> </span></li>
                                    <li class="rating">
                                        <div class="stars-outer">
                                            <div data-rating="<?php echo esc_attr($starPercentageRounded); ?>" class="stars-inner"></div>
                                        </div>
                                        <span>(<?php echo esc_html($value_rating); ?>)</span>
                                                
                                    </li>
                                </ul>
                            </div>
                            <div class="featured-product-overlay">
                                    <ul>

                                        <?php if(isset($reserved_data['previews'])): ?>
                                            <?php $reserved_data_live_site = $reserved_data['previews']; ?>
                                            <?php if(isset($reserved_data_live_site['live_site']) && ew_is_connected()): ?>
                                                <li><a class="main-btn" href="#"><?php echo esc_html__( 'Live Preview', 'quomodo-market-essential' ) ?></a></li>
                                                <?php endif; ?> 
                                        <?php endif; ?> 
                                        <li><a class="main-btn main-btn-2" href="<?php the_permalink(  ) ?>"> <?php echo esc_html__( 'Theme Details', 'quomodo-market-essential' ) ?> </a></li>

                                    </ul>
                            </div>
                            <div class="box">
                                <?php if(isset($reserved_data["price_cents"])): ?>
                                        <span> <?php echo esc_html("$".number_format(($reserved_data["price_cents"]/100), 0, '.', ' ') ); ?> </span>
                                <?php endif; ?> 
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?> 
            </div>
       
  
    <?php  

    }
    
    protected function _content_template() { }
}