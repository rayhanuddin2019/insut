<?php
namespace AppscredEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Video_PopUp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appscred-video-popup';
    }

    public function get_title() {
        return esc_html__( 'Video PopUp', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return "fa fa-video-camera";
    }

    public function get_categories() {
        return [ 'appscred-elements' ];
    }
    public function layout(){
        return[
            
            'style1' => esc_html__( 'Style 1', 'quomodo-market-essential' ),
            'style2' => esc_html__( 'Style 2', 'quomodo-market-essential' ),
            'style3' => esc_html__( 'Style 3', 'quomodo-market-essential' ),
      
        ];
    }
    protected function _register_controls() {
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'quomodo-market-essential'),
            ]
        );
            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Title settings', 'quomodo-market-essential'),
                'condition' => [ 'style' => ['style2','style1'] ],
            ]
        );
      
        $this->add_control(
			'title', [
				'label'       => esc_html__( 'Title text', 'quomodo-market-essential' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Title here', 'quomodo-market-essential' ),
				'default'     => esc_html__( 'Appscred Helps You Succeed', 'quomodo-market-essential' ),
         	]
        );
  
 
      $this->add_control(
        'heading_type',
            [
                'label'   => esc_html__( 'Heading type', 'quomodo-market-essential' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'h2',
                'options' => [
                    'h1' => esc_html__( 'H1', 'quomodo-market-essential' ),
                    'h2' => esc_html__( 'H2', 'quomodo-market-essential' ),
                    'h3' => esc_html__( 'H3', 'quomodo-market-essential' ),
                    'h4' => esc_html__( 'H4', 'quomodo-market-essential' ),
                    'h5' => esc_html__( 'H5', 'quomodo-market-essential' ),
                    'h6' => esc_html__( 'H6', 'quomodo-market-essential' ),
                    'p'  => esc_html__( 'P', 'quomodo-market-essential' ),
                ],
            ]
        );

        $this->add_control(
			'column',
			[
				'label' => esc_html__( 'Column', 'quomodo-market-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'6'  => esc_html__( '6 Column', 'quomodo-market-essential' ),
					'4'  => esc_html__( '4 Column', 'quomodo-market-essential' ),
					'12' => esc_html__( 'Full width', 'quomodo-market-essential' ),
					'none' => esc_html__( 'None', 'quomodo-market-essential' ),
				],
			]
        );
        
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .video-7-content' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();
        $this->start_controls_section(
            'section_image_tab',
            [
                'label' => esc_html__('Images', 'quomodo-market-essential'),
            ]
        );
            $this->add_control(
                'image1',
                [
                    'label' => esc_html__( 'Choose Image one', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_video_tab',
            [
                'label' => esc_html__('Video settings', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'video_title', [
                    'label'       => esc_html__( 'Video Title', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video Title here', 'quomodo-market-essential' ),
                    'default'     => esc_html__( 'Watch Video', 'quomodo-market-essential' ),
                ]
            );

            $this->add_control(
                'video_detail', [
                    'label'       => esc_html__( 'Video Description', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'condition' => [ 'style' => ['style2'] ],
                    'placeholder' => esc_html__( 'Video Description here', 'quomodo-market-essential' ),
                    
                ]
            );

            $this->add_control(
                'video_url', [
                    'label'       => esc_html__( 'Video Url', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video url here', 'quomodo-market-essential' ),
                    'default'     => 'https://www.youtube.com/watch?v=WXW7ztYNlWg',
                ]
            );

            $this->add_control(
                'video_icon',
                [
                    'label' => esc_html__( 'Icon', 'quomodo-market-essential' ),
                    'type'  => \Elementor\Controls_Manager::ICONS,
                ]
            );

            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'List Title' , 'quomodo-market-essential' ),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'list_icon',
                [
                    'label' => esc_html__( 'Choose Icon ', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $repeater->add_responsive_control(
                'list_thumb_image_section_position_top',
                [
                    'label'      => esc_html__( 'Position Top', 'quomodo-market-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1600,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                   
                    'selectors' => [
                        '{{WRAPPER}} .video-bg {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $repeater->add_responsive_control(
                'list_thumb_image_section_position_left',
                [
                    'label'      => esc_html__( 'Position Left', 'quomodo-market-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1600,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                   
                    'selectors' => [
                        '{{WRAPPER}} .video-bg {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'shape_list',
                [
                    'label' => esc_html__( 'Background Shape List', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                    'condition' => [ 'style' => ['style2','style1'] ],
                ]
            );


        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );
                $this->add_control(
                    'bold_text_heading1',
                    [
                        'label' => esc_html__( 'Normal Text', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'normal_title_color', [

                        'label'     => esc_html__( 'Normal Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title span' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'normal_title_typho',
                        'label'    => esc_html__( 'Normal Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .title span',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_intro_ttile_style', [
				'label' => esc_html__( 'Video Intro Title / Button text', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'video_title_color', [

                        'label'     => esc_html__( 'Title color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-intro' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .intro-video' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'video_title_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-intro,{{WRAPPER}} .intro-video',
                    ]
                );
                $this->add_responsive_control(
                    'video_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-intro' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .intro-video' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'video_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-intro' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .intro-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'video_title_icon_padding',
                    [
                        'label'      => esc_html__( 'Icon Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            
                            '{{WRAPPER}} .intro-video i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        $this->start_controls_section(
			'section_intro_desc_style', [
				'label' => esc_html__( 'Video desc', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'video_desc_color', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-content .text' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'video_desc_typho',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-content .text',
                    ]
                );
                $this->add_responsive_control(
                    'video_desc_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-content .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'video_desc_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-content .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('appscred_icon_inner_main_section',
            [
            'label' => esc_html__( 'Video Icon', 'quomodo-market-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                $this->add_control( 
                    'video_icon_color', [

                        'label'     => esc_html__( 'Icon Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .video-popup i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .video-popup svg path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'video_icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .video-popup i',
                    ]
                );
                $this->add_responsive_control(
                    'video_icon_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-popup' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name' => 'video_icon_gradient_background',
                            'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .video-7-content a::before,{{WRAPPER}} .video-7-content a::after,{{WRAPPER}} .blog-list-item .blog-list-thumb a,{{WRAPPER}} .blog-list-item .blog-list-thumb a::before',
                        ]
                );

        $this->end_controls_section();
           //Image Style Section
		$this->start_controls_section(
			'section_thumb_image_style', [
				'label' => esc_html__( 'Thumb Image', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'style' => ['style2'] ],
			]
        );
 
              

                $this->add_responsive_control(
                    'thumb_image_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .video-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'thumb_image_radius',
                        [
                            'label' => esc_html__( 'Border radius', 'quomodo-market-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                           
                            'selectors' => [
                                '{{WRAPPER}} .video-thumb img' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                ); 
              
        $this->end_controls_section();
        $this->start_controls_section('appscred_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'main_sec_gradient_background',
                        'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-bg,{{WRAPPER}} .blog-list-item',
                    ]
            );
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-7-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .blog-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-7-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .blog-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'box_media_heading1',
                [
                    'label' => esc_html__( 'Inner Background Shape', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [ 'style' => ['style2'] ],
                ]
            );
            
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'inner_shape_content_background',
                        'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-area .video-bg::before',
                       
                       'condition' => [ 'style' => ['style2'] ],
                    ]
            );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		$title     = $settings['title'];
	    $title_1   = str_replace(['{', '}'], ['<span>', '</span>'], $title);
       
    ?>
            <!--====== VIDEO 7 PART START ======-->
        <?php if($settings['style'] == 'style1'): ?>   
            <section class="video-7-area">
                <div class="video-bg">
                    <?php foreach($settings['shape_list'] as $key => $item): ?>
                        <div class="video-shape-<?php echo esc_attr( ++$key ); ?> elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                           <img src=" <?php echo esc_url($item['list_icon']['url']); ?> " alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-9">
                            <div class="video-7-content">
                                <<?php echo esc_attr($settings['heading_type']); ?> class="title"> <?php echo quomodo_market_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                                <span class="video-intro"> <?php echo esc_html($settings['video_title']); ?> </span>
                                <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>">
                                   <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
       <!--====== VIDEO 7 PART ENDS ======-->
       <?php endif; ?>
       <?php if($settings['style'] == 'style2'): ?>   
         <!--====== VIDEO PART START ======-->
            <section class="video-area">
                <div class="video-bg">
              
                    <div class="shape-1"></div>
                    <div class="shape-2"></div>
                    <div class="shape-3"></div>
                </div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="video-content text-center">
                            <<?php echo esc_attr($settings['heading_type']); ?> class="title"> <?php echo quomodo_market_kses($title_1); ?> </<?php echo esc_attr($settings['heading_type']); ?>>
                                <p class="text"> <?php echo esc_html($settings['video_detail']); ?> </p>
                                <a class="main-btn video-popup intro-video" href="<?php echo esc_url($settings['video_url']); ?>">
                                      <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                     <?php echo esc_html($settings['video_title']); ?>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-10">
                            <div class="video-thumb text-center mt-50">
                                <?php if($settings['image1']['url'] !=''): ?>
                                    <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!--====== VIDEO PART ENDS ======-->
       <?php endif; ?>
       <?php if($settings['style'] == 'style3'): ?>  

            <div class="blog-list-item">
                <div class="blog-list-thumb">
                    <?php if($settings['image1']['url'] !=''): ?>
                        <img class="big-img" src=" <?php echo esc_url($settings['image1']['url']); ?> " alt="<?php echo esc_attr__('Image','quomodo-market-essential'); ?>">
                    <?php endif; ?>
                    <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>"><i class="fas fa-play"></i></a>
                </div>
            </div>

       <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}