<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class SignUp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appscred-signup';
    }

    public function get_title() {
        return esc_html__( 'Signup / Registration', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return 'far fa-user';
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }
      
    protected function _register_controls() {

        

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Form Heading', 'quomodo-market-essential'),
            ]
        );
   

            $this->add_control(
                'title', [
                    'label'			  => esc_html__( 'Title text', 'quomodo-market-essential' ),
                    'type'			  => Controls_Manager::TEXT,
                    'label_block'	  => true,
                    'default'        => esc_html__( 'Create Your Account', 'quomodo-market-essential' ),
                    
                ]
            );

            $this->add_control(
                'sub_title', [
                    'label'			  => esc_html__( 'Sub Title text', 'quomodo-market-essential' ),
                    'type'			  => Controls_Manager::TEXTAREA,
                    'default'        => esc_html__( 'Put those info and create your account', 'quomodo-market-essential' ),
                    'label_block'	  => true,
                    
                ]
            );
           
        $this->end_controls_section();

        $this->start_controls_section(
            'section_fields',
            [
                'label' => esc_html__('Fields', 'quomodo-market-essential'),
            ]
        );

        $this->add_control(
            'name_label', [
                'label'			  => esc_html__( 'Name Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Your name ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Your name ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'name_placeholder', [
                'label'			  => esc_html__( 'Name placeholder', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Your name ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Your name ', 'quomodo-market-essential' ),
            
                
            ]
        );
      
        $this->add_control(
            'username_label', [
                'label'			  => esc_html__( 'Username Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'username ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Username ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'username_placeholder', [
                'label'			  => esc_html__( 'Username placeholder', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'username ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Username ', 'quomodo-market-essential' ),
            
                
            ]
        );
        // email

        $this->add_control(
            'email_label', [
                'label'			  => esc_html__( 'Email Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Email ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Your Email ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'email_placeholder', [
                'label'			  => esc_html__( 'Email placeholder', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'email ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Your Email ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'password_label', [
                'label'			  => esc_html__( 'Password Label', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'password ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'password ', 'quomodo-market-essential' ),
            
                
            ]
        );

        $this->add_control(
            'cpassword_label', [
                'label'			  => esc_html__( ' CPassword ', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'password ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Confirm Password ', 'quomodo-market-essential' ),
            
                
            ]
        );


       
        $this->add_control(
            'submit_text', [
                'label'			  => esc_html__( 'Submit text', 'quomodo-market-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Submit ', 'quomodo-market-essential' ),
                'default'	     => esc_html__( 'Login to your account ', 'quomodo-market-essential' ),
            
                
            ]
        );
     
        $this->end_controls_section();

        $this->start_controls_section(
            'section_remenber_content',
            [
                'label' => esc_html__('Agreement ', 'quomodo-market-essential'),
            ]
        );

                $this->add_control(
                    'privacy_show',
                    [
                        'label'        => esc_html__( 'show', 'quomodo-market-essential' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                        'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                        'return_value' => 'yes',
                        'default'      => 'yes',
                    ]
                );
            
                $this->add_control(
                    'privacy_text',
                    [
                        'label'       => esc_html__( 'Title', 'quomodo-market-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                  
                    ]
                );
        
         $this->end_controls_section();

         $this->start_controls_section(
            'section_registration',
            [
                'label' => esc_html__('Login Link', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'reg_link_show',
                [
                    'label'        => esc_html__( 'show', 'quomodo-market-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );
            $this->add_control(
                'registration_button_title', [
                    'label'       => esc_html__( 'Title text', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Write a text here ', 'quomodo-market-essential' ),
                    'default'     => esc_html__( 'Do you have account?', 'quomodo-market-essential' ),
                ]
            );
            $this->add_control(
                'button_registration',
                [
                    'label'       => esc_html__( 'Link Text', 'quomodo-market-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'SignUp', 'quomodo-market-essential' ),
                    'placeholder' => esc_html__( 'Type your title here', 'quomodo-market-essential' ),
                ]
            );
            
            $this->add_control(
                'registration_link',
                [
                    'label'         => esc_html__( 'Link', 'quomodo-market-essential' ),
                    'type'          => \Elementor\Controls_Manager::URL,
                ]
            );  
        
        $this->end_controls_section();

        $this->start_controls_section(
            'section_alignment_password',
            [
                'label' => esc_html__('Alignment', 'quomodo-market-essential'),
            ]
        );

        $this->add_responsive_control(
            'header_conten_text_align', [
                'label'   => esc_html__( 'Header', 'quomodo-market-essential' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [

            'left'		 => [
                
                'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                'icon'  => 'fa fa-align-left',
            
            ],
                'center'	     => [
                
                'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                'icon'  => 'fa fa-align-center',
            
            ],
            'right'	 => [

                        'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-right',
                
                    ],
                'justify'	 => [

                        'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-justify',
                
                    ],
                ],
            'default' => 'center',
            
                'selectors' => [
                    '{{WRAPPER}} .sign-in-title' => 'text-align: {{VALUE}};',

                ],
            ]
        );//Responsive control end

            $this->add_responsive_control(
                'form_content_text_align', [
                    'label'   => esc_html__( 'Label', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                        '{{WRAPPER}} .input-box' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .input-link' => 'text-align: {{VALUE}};',
                    

                    ],
                ]
            );//Responsive control end

            
            $this->add_responsive_control(
                'form_privacy_content_text_align', [
                    'label'   => esc_html__( 'Privacy', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                
                        '{{WRAPPER}} .privacy' => 'text-align: {{VALUE}};',

                    ],
                ]
            );//Responsive control end
            
            $this->add_responsive_control(
                'form_create_account_content_text_align', [
                    'label'   => esc_html__( 'Sign In', 'quomodo-market-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'quomodo-market-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                
                        '{{WRAPPER}} .signin' => 'text-align: {{VALUE}};',

                    ],
                ]
            );//Responsive control end

        $this->end_controls_section();


        $this->start_controls_section(
            'registration_header_arear_style_section',
            [
                'label' => esc_html__( 'Header', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            
            $this->add_control(
                'headee0_title_color', [

                    'label'		 => esc_html__( 'Title color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .title' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_control(
                'headee0_title_normal_color', [

                    'label'		 => esc_html__( 'Bracket words color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .title span' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_title_typho',
                    'label'    => esc_html__( 'Title Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .sign-in-title .title',
                ]
            );

            
            $this->add_responsive_control(
                'header_ttile_margin',
                [
                    'label'      => esc_html__( 'Title Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .sign-in-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'headee0_content_color', [

                    'label'		 => esc_html__( 'Content color', 'quomodo-market-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .sign-in-title .sub-title' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_content_typho',
                    'label'    => esc_html__( 'Content Typography', 'quomodo-market-essential' ),
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .sign-in-title .sub-title',
                ]
            );

            
            $this->add_responsive_control(
                'header_content_margin',
                [
                    'label'      => esc_html__( 'Content Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .sign-in-title .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
      

        $this->end_controls_section();

      
        /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_input_style_section',
            [
                'label' => esc_html__( 'Input', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'input_box_tabs' );
                $this->start_controls_tab(
                    'input_box_normal_tab',
                    [
                        'label' => esc_html__( 'Normal', 'quomodo-market-essential' ),
                    ]
                );
                    $this->add_responsive_control(
                        'input_box_height',
                        [
                            'label'      => esc_html__( 'Height', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'max' => 150,
                                ],
                            ],
                            'default' => [
                                'size' => 55,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'height:{{SIZE}}{{UNIT}};',
                           
                               
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_width',
                        [
                            'label'      => esc_html__( 'Width', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                           
                            'selectors' => [
                                '{{WRAPPER}}  .input'=> 'width:{{SIZE}}{{UNIT}};',
                         
                            ],
                        ]
                    );
                 

                   
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_label_box_typography',
                            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                            'selector' => '{{WRAPPER}} label',
                              
                        ]
                    );


                    $this->add_control(
                        'input_label_box_label_color',
                        [
                            'label'     => esc_html__( 'Label Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}}  label' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_label_box_margin',
                        [
                            'label'      => esc_html__( 'Label Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_control(
                        'input_box_bgtext_color',
                        [
                            'label'     => esc_html__( 'Background Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .input'  => 'Background:{{VALUE}} !important;',
                              
                        
                            ],
                        ]
                    );

                    
                   
                    $this->add_control(
                        'input_box_placeholder_color',
                        [
                            'label'     => esc_html__( 'Placeholder Color', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'   => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'            => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'        => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'  => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'           => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'       => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'    => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'             => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'         => 'color: {{VALUE}};',
                                
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_box_typography',
                            'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                            'selector' => '{{WRAPPER}} .input',
                              
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_box_border',
                            'label'    => esc_html__( 'Border', 'quomodo-market-essential' ),
                            'selector' => ' {{WRAPPER}} .input',
                             
                            
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_border_radius',
                        [
                            'label'     => esc_html__( 'Border Radius', 'quomodo-market-essential' ),
                            'type'      => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .input' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                             ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '{{WRAPPER}} .input',   
                            
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}}  .input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                              
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}}  .input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_control(
                        'input_box_transition',
                        [
                            'label'      => esc_html__( 'Transition', 'quomodo-market-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                          
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'transition: {{SIZE}}s;',
                           

                            ],
                        ]
                    );
                $this->end_controls_tab();
                $this->start_controls_tab(
                    'input_box_hover_tabs',
                    [
                        'label' => esc_html__( 'Focus', 'quomodo-market-essential' ),
                    ]
                );
                $this->add_control(
                    'input_box_hover_color',
                    [
                        'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'  => 'color:{{VALUE}};',
                         
                         
                        ],
                    ]
                );
              
                $this->add_control(
                    'input_box_hover_border_color',
                    [
                        'label'     => esc_html__( 'Border Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'   => 'border-color:{{VALUE}};',
                         ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Box_Shadow:: get_type(),
                    [
                        'name'     => 'input_box_hover_shadow',
                        'selector' => '{WRAPPER}} .input:focus',
                          
                    ]
                );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();


                /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_submit_style_section',
            [
                'label' => esc_html__( 'Submit', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'submit_box_height',
            [
                'label'      => esc_html__( 'Height', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
               
                
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'height:{{SIZE}}{{UNIT}};',
               
                   
                ],
            ]
        );
        $this->add_responsive_control(
            'submit_box_width',
            [
                'label'      => esc_html__( 'Width', 'quomodo-market-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
               
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'width:{{SIZE}}{{UNIT}};',
             
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'submit_box_typography',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .main-btn',
                   
            ]
        );
        $this->add_control(
            'submit_box_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-btn'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'gradient_submit__background',
                    'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                    'types' => [ 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-btn',
                    
                ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'submit_border',
				'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
				'selector' => '{{WRAPPER}} .main-btn',
			]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'submit_box_shadow',
                'selector' => '{{WRAPPER}} .main-btn',   
                
            ]
        );

        $this->add_responsive_control(
			'submit_btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        
        $this->add_responsive_control(
			'submit_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
     
        $this->add_responsive_control(
            'submit_btn_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'quomodo-market-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors' => [
                  
                  '{{WRAPPER}} .main-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                 
                  
               ],
            ]
         );
        $this->end_controls_section();
      

        $this->start_controls_section(
            'ultimate_privacy_style_section',
            [
                'label' => esc_html__( ' Agreement ', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'registration_text_typography',
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .privacy p',
                    
                ]
            );

            $this->add_control(
                'registration_text__text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .privacy p'  => 'color:{{VALUE}};',
                    ],
                ]
            );


            $this->add_responsive_control(
                'registration_text__margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .privacy' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'registration_text__password',
                [
                    'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .privacy p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section(); 

        $this->start_controls_section(
            'ultimate_login_style_section',
            [
                'label' => esc_html__( ' Footer   ', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'signin_text_typography',
                    'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                    'selector' => '{{WRAPPER}} .create-account,{{WRAPPER}} .signin span',
                    
                ]
            );

            $this->add_control(
                'signin_text__text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .signin span'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'signin_link__text_color',
                [
                    'label'     => esc_html__( 'Link Color', 'quomodo-market-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .create-account'  => 'color:{{VALUE}};',
                    ],
                ]
            );


            $this->add_responsive_control(
                'signin_text__margin',
                [
                    'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .signin span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'signin_text__password',
                [
                    'label'      => esc_html__( 'Link Padding', 'quomodo-market-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .create-account' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section(); 
       
       
        $this->start_controls_section(
			'section_box_style', [
				'label' => esc_html__( 'Box', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
        );
      

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_one_box_background',
                        'label' => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types' => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .sign-in-box',
                    ]
                );

                $this->add_group_control(
                    Group_Control_Border::get_type(),
                    [
                        'name' => 'box_border',
                        'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .sign-in-box',
                    ]
                );

       
                $this->add_responsive_control(
                    'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .sign-in-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .sign-in-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

        $this->end_controls_section();

       

        $this->start_controls_section(
            'alignment_success_msg_section',
            [
                'label' => esc_html__( 'Success Message', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'success_msg_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
				
				],
               'default' => 'left',
            
                'selectors' => [
                     '{{WRAPPER}} .success' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->add_control(
            'tsuccess__text_color',
            [
                'label'     => esc_html__( 'Message Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .success'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'tsucces_text_typography',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'label'     => esc_html__( 'Message', 'quomodo-market-essential' ),
                'selector' => '{{WRAPPER}} .success',
                   
            ]
        );

        $this->add_control(
            'tsuccess_link_text_color',
            [
                'label'     => esc_html__( 'Link Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .success a'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'tsuccess_typography',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'label'     => esc_html__( 'Link', 'quomodo-market-essential' ),
                'selector' => '{{WRAPPER}} .success a',
                   
            ]
        );
        $this->add_responsive_control(
			'success_margin',
			[
				'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .success' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'error__msg_section',
            [
                'label' => esc_html__( 'Error Message', 'quomodo-market-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'error_msg_align', [
				'label'   => esc_html__( 'Alignment', 'quomodo-market-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'quomodo-market-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
				
				],
               'default' => 'left',
            
                'selectors' => [
                     '{{WRAPPER}} .errors' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->add_control(
            'error__text_color',
            [
                'label'     => esc_html__( 'Message Color', 'quomodo-market-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .errors li'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'eror_text_typography',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                'label'     => esc_html__( 'Message', 'quomodo-market-essential' ),
                'selector' => '{{WRAPPER}} .errors li',
                   
            ]
        );

       
        $this->add_responsive_control(
			'error_msg_margin',
			[
				'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .errors' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->add_responsive_control(
			'error_msg_padding',
			[
				'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .errors li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );

        $this->end_controls_section();
    } //Register control end


    protected function render( ) { 

		$settings     = $this->get_settings();
		$title        = $settings['title'];
        $title_1      = str_replace(['{', '}'], ['<span>', '</span>'], $title); 
       
       
    ?>
     

        <div class="sign-in-box">
            <div class="sign-in-title">
                <?php

                    $errors = [];
                    if(isset($_SESSION["quomodomarket_reg_msg"])){
                        $errors = $_SESSION["quomodomarket_reg_msg"];      
                    }       

                ?>
                <?php if( count( $errors) ): ?>
                    <ul class="errors">
                        <?php foreach($errors as $error): ?>
                            <li> <?php echo esc_html($error); ?> </li>
                        <?php endforeach; ?>
                    </ul>
                <?php 
                    unset($_SESSION["quomodomarket_reg_msg"]); 
                endif; 
                ?>
                <?php if(isset($_SESSION['quomodomarket_reg_msg_success'])): ?>
                <h2 class="success">
                    <?php echo esc_html($_SESSION['quomodomarket_reg_msg_success']); unset($_SESSION["quomodomarket_reg_msg_success"]); ?> 
                    <a 
                                
                        rel="<?php echo esc_attr($settings['registration_link']['nofollow']?'nofollow':''); ?> " 
                        target="<?php echo  esc_attr($settings['registration_link']['is_external']?"_blank":"_self"); ?>" 
                        href="<?php echo esc_url($settings['registration_link']['url']); ?>"
                    >
                    <?php echo esc_html__( 'Go to login page', 'quomodo-market-essential' ) ?> 
                    </a> 
                </h2>

                <?php endif; ?>
                <h3 class="title"><?php echo quomodo_market_kses($title_1); ?></h3>
                <?php if($settings['sub_title'] !=''): ?>
                    <div class="sub-title"> <?php echo esc_html($settings['sub_title']); ?> </div>
                <?php endif; ?>

            </div>
            <form action="#">

                <div class="input-box">
                    <label><?php echo esc_attr($settings['name_label']); ?></label>
                    <input class="input" name="name" type="text" placeholder="<?php echo esc_attr($settings['name_placeholder']); ?>">
                </div>
                
                 <div class="input-box">
                    <label><?php echo esc_attr($settings['username_label']); ?></label>
                    <input class="input" name="username" type="text" placeholder="<?php echo esc_attr($settings['username_placeholder']); ?>">
                </div>
                <div class="input-box">
                    <label><?php echo esc_attr($settings['email_label']); ?></label>
                    <input class="input" name="email" type="email" placeholder="<?php echo esc_attr($settings['email_placeholder']); ?>">
                </div>
                <div class="input-box">
                    <label><?php echo esc_attr($settings['password_label']); ?></label>
                    <input class="input" name="password" type="password" >
                </div>
                <div class="input-box">
                    <label><?php echo esc_attr($settings['cpassword_label']); ?></label>
                    <input class="input" name="cpassword" type="password">
                </div>
                <input type="hidden" name="quomodomarket_registration_form" />
                <?php wp_nonce_field('quomodomarket_registration_action'); ?>
                <?php if($settings['privacy_show']): ?>
                    <div class="input-link privacy mt-15">
                        <p> <?php echo quomodo_market_kses($settings['privacy_text']); ?> </p>
                    </div>
                <?php endif; ?>
                <div class="input-link signin">
                    <button class="main-btn mb-15"><?php echo esc_html($settings['submit_text']); ?></button>
                    <span>
                       <?php echo esc_html( $settings['registration_button_title'] ) ?>
                       <?php if($settings['reg_link_show']): ?>
                        <a class="create-account" href="<?php echo esc_url( $settings['registration_link']['url'] ); ?>"><?php echo esc_html( $settings['button_registration'] ); ?> </a>
                       <?php endif; ?>
                      </span>
                </div>
            </form>
        </div>

   

    <?php  

    }
    
    protected function _content_template() { }
}