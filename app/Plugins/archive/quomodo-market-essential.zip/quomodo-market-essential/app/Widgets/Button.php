<?php
namespace QuomodoMarketEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;


class Button extends Widget_Base {


    public $base;

    public function get_name() {
        return 'quomodo-marketplace-button';
    }

    public function get_title() {
        return esc_html__( 'Quomodo Market Button', 'quomodo-market-essential' );
    }

    public function get_icon() { 
        return 'eicon-dual-button';
    }

    public function get_categories() {
        return [ 'quomodo-marketplace-elements' ];
    }

    protected function _register_controls() {

       
        $this->start_controls_section(
            'section_button_tab',
            [
                'label' => esc_html__('Button settings', 'quomodo-market-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label' => esc_html__( 'Style', 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1'  => esc_html__( 'Style 1', 'quomodo-market-essential' ),
                       // 'style2' => esc_html__( 'Style 2', 'quomodo-market-essential' ),
                    ],
                ]
            );

            $this->add_control(
                'button_text', [
                    'label'       => esc_html__( 'Button text', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'button_url', [
                    'label'       => esc_html__( 'Button Url', 'quomodo-market-essential' ),
                    'type'        => Controls_Manager::URL,
                    'label_block' => true,
                ]
            );

          
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_button_style2', [
				'label' => esc_html__( 'Button', 'quomodo-market-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'fea_button_color2', [

                        'label'     => esc_html__( 'Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .quomodo-marketplace-btn' => 'color: {{VALUE}};',
                      
                        ],
                    ]
                );

                $this->add_control(
                    'fea_button_hv_color2', [

                        'label'     => esc_html__( 'Hover Color', 'quomodo-market-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}}  .quomodo-marketplace-btn:hover' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'button_content_typho2',
                        'label'    => esc_html__( 'Typography', 'quomodo-market-essential' ),
                        'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .quomodo-marketplace-btn',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .quomodo-marketplace-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin2',
                    [
                        'label'      => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .quomodo-marketplace-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'button_background_heading2',
                    [
                        'label' => esc_html__( 'Background color', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_background2',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-btn::before',
                    ]
                );
                $this->add_control(
                    'button_background_hv_heading2',
                    [
                        'label' => esc_html__( 'Background hover color', 'quomodo-market-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_hv_background2',
                        'label'    => esc_html__( 'Background', 'quomodo-market-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .quomodo-marketplace-btn:hover',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'quomodo-market-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .quomodo-marketplace-btn' => 'border-radius: {{VALUE}}px;',
                                '{{WRAPPER}} .main-btn::before' => 'border-radius: {{VALUE}}px;',
                              
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button2_section_border',
                        'label' => esc_html__( 'Border', 'quomodo-market-essential' ),
                        'selector' => '{{WRAPPER}} .quomodo-marketplace-btn',
                    ]
                );

                

        $this->end_controls_section();
       
       
        
        

    } //Register control end

    protected function render( ) { 

        $settings    = $this->get_settings();
        $button_url  = $settings['button_url'];
        $button_text = $settings['button_text'];
     
    ?>
        <?php if($settings['style'] == 'style1'): ?> 

            <?php  if( $settings['button_text'] !='' ): ?> 
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="quomodo-marketplace-btn main-btn">
                          <?php echo esc_html( $settings['button_text'] ); ?>
                    </a>
            <?php endif; ?>     
           
       <?php endif; ?>
            
    <?php  

    }
    
    protected function _content_template() { }
}