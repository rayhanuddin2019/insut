<?php
/**
 * @package  quomodo-market-essential
 */
namespace QuomodoMarketEssential\Base;

class Activate
{
	public static function activate() {
		flush_rewrite_rules();
	}
}