<?php 
/**
 * @package  quomodo
 */
namespace QuomodoMarketEssential\Base;

use Carbon_Fields\Widget;


abstract class CarbonWidget extends Widget
{
	 /**
     * Register loader with init class.
     *
     * @return void
     */
    function register(){
        add_action( 'widgets_init', [$this,'register_widgets'] );
    }
    
    function register_widgets() {
        register_widget( get_called_class() );
    }
}