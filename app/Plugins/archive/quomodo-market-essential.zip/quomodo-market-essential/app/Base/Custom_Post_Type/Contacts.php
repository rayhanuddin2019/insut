<?php
/**
 * @package  quomodo-marketplace-essential
 */
namespace QuomodoMarketEssential\Base\Custom_Post_Type;
use QuomodoMarketEssential\Api\Callbacks\Custom_Post;

class Contacts extends Custom_Post
{

    public $name         = 'Address Book';
    public $menu         = 'Address Book';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = true;
    public $slug         = 'quomodo-contacts';
    public $search       = true;

	public function register() {

        $this->textdomain = 'quomodo-market-essential';
        $this->posts      = array();

		add_action( 'init', array( $this, 'create_post_type' ) );
    }
    
    public function create_post_type(){
         
       
        if( quomodomarket_option('contacts_name') !='' ){
            $this->name = quomodomarket_option('contacts_name');    
        }
        
        if( quomodomarket_option('contacts_menu') !='' ){
            $this->menu = quomodomarket_option('contacts_menu');    
        }
        
        if( quomodomarket_option('contacts_exclude_from_search') ){
            $this->search = true;    
        }else{
            $this->search = false;    
        } 
        
        if( quomodomarket_option('contacts_details_page') ){
            $this->public_quary = true;    
        }else{
            $this->public_quary = false;    
        }
    
        if(quomodomarket_option('contacts_slug_name') !=''){
            $this->slug = quomodomarket_option('contacts_slug_name');    
        }
         
        $this->init( 'quomodo-contacts', $this->name, $this->menu, array( 'menu_icon' => 'dashicons-admin-users',
          
            'supports'            => array( 'title'),
            'rewrite'             => array( 'slug' => $this->slug ),
            'exclude_from_search' => $this->search,
            'has_archive'         => true,                                            // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
            
        ) 

       );

       $this->register_custom_post();
    }
}