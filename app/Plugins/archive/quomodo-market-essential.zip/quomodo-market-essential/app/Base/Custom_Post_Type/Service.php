<?php
/**
 * @package  quomodo-market-essential
 */
namespace QuomodoMarketEssential\Base\Custom_Post_Type;
use QuomodoMarketEssential\Api\Callbacks\Custom_Post;

class Service extends Custom_Post
{

    public $name         = 'Service';
    public $menu         = 'Service';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = true;
    public $slug         = 'quomodo-service';
    public $search       = true;

	public function register() {

        $this->textdomain = 'quomodo-market-essential';
        $this->posts      = array();

		add_action( 'init', array( $this, 'create_post_type' ) );
    }
    
    public function create_post_type(){
         
       
        if( quomodomarket_option('service_name') !='' ){
            $this->name = quomodomarket_option('service_name');    
        }
        
        if( quomodomarket_option('service_menu') !='' ){
            $this->menu = quomodomarket_option('service_menu');    
        }
        
        if( quomodomarket_option('service_exclude_from_search') ){
            $this->search = true;    
        }else{
            $this->search = false;    
        } 
        
        if( quomodomarket_option('service_details_page') ){
            $this->public_quary = true;    
        }else{
            $this->public_quary = false;    
        }

        if(quomodomarket_option('service_slug_name') !=''){
            $this->slug = quomodomarket_option('service_slug_name');    
        }
         
        $this->init( 'quomodo-service', $this->name, $this->menu, array( 'menu_icon' => 'dashicons-admin-users',
          
            'supports'            => array( 'title','thumbnail','editor','author','page-attributes'),
            'rewrite'             => array( 'slug' => $this->slug ),
            'exclude_from_search' => $this->search,
            'has_archive'         => false,                                            // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
        ) 

       );

       $this->register_custom_post();
    }
}