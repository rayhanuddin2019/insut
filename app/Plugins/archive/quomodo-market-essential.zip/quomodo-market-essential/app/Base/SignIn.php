<?php 
/**
 * @package  quomodo-market-essential
 */
namespace QuomodoMarketEssential\Base;
use QuomodoMarketEssential\Base\BaseController;

/**
* signup form widget
*/
class SignIn extends BaseController
{
	public function register() {
	
        add_action('init',[$this,'form_submit']);
    }
    function form_validate($data){
        unset( $_SESSION["quomodomarket_login_msg"] );
       
        if(isset($data['password']) && $data['password'] == ''){
            $_SESSION["quomodomarket_login_msg"]['valid_email'] = esc_html__('Password is not empty','quomodo-market-essential');
        } 

        if(isset($_SESSION["quomodomarket_login_msg"])){
            return true;
        }    

        return false;
        
    }
    public function login($data){
       
        $creds = array(
            'user_login'    => $data['username'],
            'user_password' => $data['password'],
            'remember'      => true
        );
        
        $creds['remember'] = isset( $_POST['rememberme'] )?true:false;
        $user = wp_signon( $creds, false );
     
        if ( is_wp_error( $user ) ) {

            $_SESSION["quomodomarket_login_msg"]['valid_email'] = $user->get_error_message();
        
        }else{
        
            $_SESSION["quomodomarket_login_success_msg"]  = esc_html__('Login Success','quomodo-market-essential');  
        
        }      
    }
    public function form_submit(){
     
        $retrieved_nonce = isset($_REQUEST['_wpnonce'])?$_REQUEST['_wpnonce']:'';

        if ( !wp_verify_nonce($retrieved_nonce, 'quomodomarket_login_action' ) ){
          return;  
        }

        session_start();
        $error =  $this->form_validate($_REQUEST); 

        if( $error == false ){
          $this->login($_REQUEST);   
        }  
       
        $request = $_SERVER["HTTP_REFERER"];
        wp_redirect($request); exit;
  
    }
	

   
}