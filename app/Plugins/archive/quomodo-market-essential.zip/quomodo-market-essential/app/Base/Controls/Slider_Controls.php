<?php 
namespace QuomodoMarketEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use QuomodoMarketEssential\Base\BaseController;

class Slider_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('quomodomarket_section_slider_tab' , array( $this, 'settings_section' ), 10 , 2 );
	}

	public function settings_section( $ele,$widget ) 
	{
           $ele->start_controls_section(
            'section_slider_tab',
                [
                    'label' => esc_html__('Slider Controls', 'quomodo-market-essential'),
                ]
            );
            
            $ele->add_control(
                'slider_enable',
                [
                    'label'        => esc_html__( 'Enable Slider', 'quomodo-market-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                   
                ]
            );
            $ele->add_responsive_control(
                'quomodomarket_slider_items',
                [
                    'label'   => esc_html__( 'Items', 'quomodo-market-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 1,
                    'max'     => 20,
                    'step'    => 1,
                    'default' => 1
                   
                ]
            );

            $ele->add_control(
                'quomodomarket_slider_loop',
                    [
                    'label'        => esc_html__( 'Loop', 'quomodo-market-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'no'
                    ]
            );

            $ele->add_control(
                'quomodomarket_slider_autoplay',
                    [
                    'label'        => esc_html__( 'Autoplay', 'quomodo-market-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'no'
                    ]
            );
     
            $ele->add_control(
                'quomodomarket_slider_autoplay_timeout',
                [
                    'label'   => esc_html__( 'Autoplay timeout', 'quomodo-market-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 20000,
                    'step'    => 1,
                   
                ]
            );
        
            $ele->add_control(
                'quomodomarket_slider_smart_speed',
                [
                    'label'   => esc_html__( 'Smart Speed', 'quomodo-market-essential' ),
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'min'     => 0,
                    'max'     => 20000,
                    'step'    => 1,
                   
                ]
            );
             
            $ele->add_control(
                'quomodomarket_slider_nav_show',
                    [
                    'label'        => esc_html__( 'Nav', 'quomodo-market-essential' ),
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'quomodo-market-essential' ),
                    'label_off'    => esc_html__( 'No', 'quomodo-market-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes'
                    ]
            );
            if($widget !='quomodo-marketplace-testimonial-slider'){
                $ele->add_control(
                    'quomodomarket_slider_margin',
                    [
                        'label'   => esc_html__( 'Margin', 'quomodo-market-essential' ),
                        'type'    => \Elementor\Controls_Manager::NUMBER,
                        'min'     => 0,
                        'max'     => 200,
                        'step'    => 1,
                       
                    ]
                );

                $ele->add_responsive_control(
                    'slick_slide_image_width',
                    [
                       'label'      => esc_html__( 'Item Width', 'quomodo-market-essential' ),
                       'type'       => Controls_Manager::SLIDER,
                       'size_units' => [ 'px'],
                       'range'      => [
                          'px' => [
                             'min'  => 50,
                             'max'  => 800,
                             'step' => 1,
                          ],
                       
                       ],
                    
                       'selectors' => [
                          '{{WRAPPER}} .slick-slide' => 'width: {{SIZE}}{{UNIT}} !important;',
                       ],
                    ]
                 );
            }
           

           
    
         
            do_action( 'quomodomarket_section_slider_tab_extra_control', $ele, $widget );    
            $ele->end_controls_section();	
	}
}