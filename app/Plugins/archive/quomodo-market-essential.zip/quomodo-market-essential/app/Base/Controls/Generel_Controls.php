<?php 
namespace QuomodoMarketEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use QuomodoMarketEssential\Base\BaseController;

class Generel_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('quomodomarket_section_general_tab' , array( $this, 'settings_section' ), 10, 2 );
		add_action('quomodomarket_section_general_tab_extra_control' , array( $this, 'settings_section_extra' ),10, 2 );
	}
   
	public function settings_section( $ele,$widget ) 
	{
            
           $ele->start_controls_section(
            'section_general_tab',
                [
                    'label' => esc_html__('General', 'quomodo-market-essential'),
                ]
            );
                $ele->add_control(
                'post_count',
                    [
                        'label'         => esc_html__( 'Post count', 'quomodo-market-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '8',
                    ]
                );
               
                $ele->add_control(
                'post_title_crop',
                    [
                        'label'         => esc_html__( 'Post title crop', 'quomodo-market-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '8',
                    ]
                );
                // uncommon  
                
                    $ele->add_control(
                        'show_content',
                        [
                            'label'     => esc_html__('Show content', 'quomodo-market-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
                            'label_off' => esc_html__('No', 'quomodo-market-essential'),
                            'default'   => 'yes',
                        ]
                    );
    
               
                
                    $ele->add_control(
                        'post_content_crop',
                            [
                                'label'         => esc_html__( 'Post content crop', 'quomodo-market-essential' ),
                                'type'          => Controls_Manager::NUMBER,
                                'default'       => '18',
                            ]
                    );
              
               
                    $ele->add_control(
                        'show_date',
                        [
                            'label'     => esc_html__('Show Date', 'quomodo-market-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
                            'label_off' => esc_html__('No', 'quomodo-market-essential'),
                            'default'   => 'yes',
                        ]
                    );
               

               
                    $ele->add_control(
                        'show_cat',
                        [
                            'label'     => esc_html__('Show Category', 'quomodo-market-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
                            'label_off' => esc_html__('No', 'quomodo-market-essential'),
                            'default'   => 'yes',
                        ]
                    );
               
                
                    $ele->add_control(
                        'show_author',
                        [
                            'label'     => esc_html__('Show Author', 'quomodo-market-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
                            'label_off' => esc_html__('No', 'quomodo-market-essential'),
                            'default'   => '',
                        ]
                    );
               
                
                    $ele->add_control(
                        'show_readmore',
                        [
                            'label'     => esc_html__('Show Readmore', 'quomodo-market-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'quomodo-market-essential'),
                            'label_off' => esc_html__('No', 'quomodo-market-essential'),
                            'default'   => 'yes',
                        ]
                    );
               
                    $ele->add_control(
                        'readmore_text',
                            [
                                'label'         => esc_html__( 'Post content crop', 'quomodo-market-essential' ),
                                'type'          => Controls_Manager::TEXT,
                                'default'       => esc_html__( 'more details', 'quomodo-market-essential' ),
                            ]
                    );
                
               
               
                do_action( 'quomodomarket_section_general_tab_extra_control', $ele, $widget );
            $ele->end_controls_section();	
    }
    
    public function settings_section_extra($ele, $widget ){
        
        if($widget == 'video-post-slider'){

            $ele->add_responsive_control(
                'thumbnail_height',
                [
                    'label' =>esc_html__( "Thumbnail Height", 'quomodo-market-essential' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'desktop_default' => [
                        'size' => 300,
                        'unit' => 'px',
                    ],
                    'tablet_default' => [
                        'size' => 250,
                        'unit' => 'px',
                    ],
                    'mobile_default' => [
                        'size' => 250,
                        'unit' => 'px',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .video-item.qoverlay-style' => 'min-height: {{SIZE}}{{UNIT}};',
                    ],
                
                ]
            );
        }
    }
}