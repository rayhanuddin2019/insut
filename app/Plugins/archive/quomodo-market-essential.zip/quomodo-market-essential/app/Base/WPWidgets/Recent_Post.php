<?php 

namespace QuomodoMarketEssential\Base\WPWidgets;
use QuomodoMarketEssential\Base\BaseWPWidget;

if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * recent post widget
 */
class Recent_Post extends BaseWPWidget {

	function __construct() {

		$widget_opt = array(
			'classname'		 => 'quomodo-marketplace-widget widget widget-recent-post',
			'description'	 => esc_html__('Recent post with thumbnail','quomodo-market-essential')
		);

		parent::__construct( 'qomodo-recent-post', esc_html__( 'Quomodo Market Recent post', 'quomodo-market-essential' ), $widget_opt );
	}

	function widget( $args, $instance ) {

		global $wp_query;

		echo quomodomarket_return($args[ 'before_widget' ]);

		

		if ( !empty( $instance[ 'number_of_posts' ] ) ) {
			$no_of_post = $instance[ 'number_of_posts' ];
		} else {
			$no_of_post = 3;
		}

		if ( !empty( $instance[ 'image_show' ] ) ) {
			$image_show = $instance[ 'image_show' ];
		} else {
			$image_show = '';
		}
		
		if ( !empty( $instance[ 'footer' ] ) ) {
			$footer = $instance[ 'footer' ];
		} else {
			$footer = '';
		}

		if ( !empty( $instance[ 'posts_title_limit' ] ) ) {
			$posts_title_limit = $instance[ 'posts_title_limit' ];
		} else {
			$posts_title_limit = 8;
		}
		
		if ( !empty( $instance[ 'posts_excerp_limit' ] ) ) {
			$posts_excerp_limit = $instance[ 'posts_excerp_limit' ];
		} else {
			$posts_excerp_limit = 18;
        }
      
        if ( !empty( $instance[ 'quomodomarket_post_type' ] ) ) {
			$quomodo_post_type = $instance[ 'quomodomarket_post_type' ];
		} else {
			$quomodo_post_type = 'recent';
		}

		$query = array(
			'post_type'		 => array( 'post' ),
			'post_status'	 => array( 'publish' ),
			'orderby'		 => 'date',
			'order'			 => 'DESC',
			'posts_per_page' => $no_of_post
		); 

		if($quomodo_post_type == "populer" ){
			$query['orderby'] = "comment_count"; 
		}
 
        $loop = new \WP_Query( $query );
      
		?>
		<?php if(!$footer): ?>
	    <?php 
			if ( !empty( $instance[ 'title' ] ) ) {

				echo quomodomarket_return($args[ 'before_title' ]) . apply_filters( 'widget_title', $instance[ 'title' ] ) . quomodomarket_return($args[ 'after_title' ]);
			}
		
		?>		
		<div class="blog-post">			
	        	 <?php
					if ( $loop->have_posts() ):
						while ( $loop->have_posts() ):
							$loop->the_post();
							?>	
								<div class="item d-flex align-items-center">
								  
										<?php

											if($image_show !='' && has_post_thumbnail()): 
												
												$thumbnail = get_the_post_thumbnail_url(  get_the_ID() , 'quomodo_market_sidebar_img' );
	                                    		
											
												echo '<div class="thumb"><a href="'.get_the_permalink().'"><img src="' . esc_url( $thumbnail ) . '" alt="' . esc_attr__('thumb','quomodo-market-essential') . '"></a> </div>';
											
											endif;

										?>
								
									<div class="content">
										<h4>
											<a href="<?php echo get_the_permalink(); ?>">  <?php echo wp_trim_words(get_the_title(),$posts_title_limit,' ');?></a>
										</h4> 
										<span><?php echo quomodo_market_essen_post_time_ago_function() ?> | <?php echo get_the_date(get_option( 'date_format' )); ?></span>
									</div>
									
								</div>

						<?php endwhile; ?>
					<?php else: ?>
						<div class="qomodo-no-post">
							<p><?php echo esc_html__( 'No post avaiable', 'quomodo-market-essential' ) ?></p>
						</div>
					<?php endif; ?> 
			</div>
			<?php
			wp_reset_postdata();
			?>
		  
		   <?php else: ?> 	
			<div class="footer-list">
				<?php
					
					if ( !empty( $instance[ 'title' ] ) ) {

						echo quomodomarket_return($args[ 'before_title' ]) . apply_filters( 'widget_title', $instance[ 'title' ] ) . quomodomarket_return($args[ 'after_title' ]);
					}

				?>  
				 <?php 
				 
				 if ( $loop->have_posts() ):
					while ( $loop->have_posts() ):
						$loop->the_post();
						?>	
							<div class="footer-post">
							  
									<?php

										if($image_show !='' && has_post_thumbnail()): 
											
											$thumbnail = get_the_post_thumbnail_url(  get_the_ID() , 'quomodo_market_sidebar_img' );
											
										
											echo '<a href="'.get_the_permalink().'"><img src="' . esc_url( $thumbnail ) . '" alt="' . esc_attr__('thumb','quomodo-market-essential') . '"></a>';
										
										endif;

									?>
							
								
							           <span> <?php echo get_the_date(get_option( 'date_format' )); ?></span>
									  <h4> <a href="<?php echo get_the_permalink(); ?>">  <?php echo wp_trim_words(get_the_title(),$posts_title_limit,' ');?></a> </h4> 
							
								
							</div>

					<?php endwhile; ?>
				<?php else: ?>
					<div class="qomodo-no-post">
						<p><?php echo esc_html__( 'No post avaiable', 'quomodo-market-essential' ) ?></p>
					</div>
				<?php endif; ?> 
				
            </div>
			<?php wp_reset_postdata(); ?>
			<?php 
			 endif;
			echo quomodomarket_return($args[ 'after_widget' ]);
	}

	function update( $new_instance, $old_instance ) {

		$old_instance[ 'title' ]              = strip_tags( $new_instance[ 'title' ] );
		$old_instance[ 'number_of_posts' ]    = $new_instance[ 'number_of_posts' ];
		$old_instance[ 'quomodomarket_post_type' ] = $new_instance[ 'quomodomarket_post_type' ];
		$old_instance[ 'posts_title_limit' ]  = $new_instance[ 'posts_title_limit' ];
		$old_instance[ 'posts_excerp_limit' ] = $new_instance[ 'posts_excerp_limit' ];
		$old_instance[ 'image_show' ]         = isset($new_instance[ 'image_show' ])?$new_instance[ 'image_show' ]:'';
		$old_instance[ 'footer' ]         = isset($new_instance[ 'footer' ])?$new_instance[ 'footer' ]:'';

		return $old_instance;
	}

	function form( $instance ) {

     
		if ( isset( $instance[ 'quomodomarket_post_type' ] ) ) {
			$quomodo_post_type = $instance['quomodomarket_post_type'];  
		}else{
			$quomodo_post_type = 'recent';  
		} 
        // title
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		} else {
			$title = esc_html__( 'Recent posts', 'quomodo-market-essential' );
		}
         //limit
		if ( isset( $instance[ 'number_of_posts' ] ) ) {
			$no_of_post = $instance[ 'number_of_posts' ];
		} else {
			$no_of_post = 3;
		}
         // title limit
		if ( isset( $instance[ 'posts_title_limit' ] ) ) {
			$posts_title_limit = $instance[ 'posts_title_limit' ];
		} else {
			$posts_title_limit = 8;
		}
        // excerpt limit
		if ( isset( $instance[ 'posts_excerp_limit' ] ) ) {
			$posts_excerp_limit = $instance[ 'posts_excerp_limit' ];
		} else {
			$posts_excerp_limit = 20;
		}

		if ( isset( $instance[ 'image_show' ] ) ) {
			$image_show = $instance[ 'image_show' ];
		} else {
			$image_show = '';
		}
		
		if ( isset( $instance[ 'footer' ] ) ) {
			$footer = $instance[ 'footer' ];
		} else {
			$footer = '';
		}
         
	?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'quomodo-market-essential' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
        <p>
		    <select class='widefat' id="<?php echo $this->get_field_id('quomodomarket_post_type'); ?>"
					name="<?php echo $this->get_field_name('quomodomarket_post_type'); ?>" type="text">
					<option
						value='recent' 
						<?php echo ($quomodo_post_type=='recent')?'selected':''; ?>>
						<?php echo esc_html__('Recent post','quomodo-market-essential'); ?>
					</option>
					<option 
						value='populer'
						<?php echo ($quomodo_post_type=='populer')?'selected':''; ?>>
						<?php echo esc_html__('Populer post','quomodo-market-essential'); ?>
					</option> 
			</select>                
        </p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number_of_posts' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'quomodo-market-essential' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number_of_posts' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number_of_posts' ) ); ?>" type="text" value="<?php echo esc_attr( $no_of_post ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_title_limit' ) ); ?>"><?php esc_html_e( 'Title limit:', 'quomodo-market-essential' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'posts_title_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_title_limit' ) ); ?>" type="text" value="<?php echo esc_attr( $posts_title_limit ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_excerp_limit' ) ); ?>"><?php esc_html_e( 'Content limit:', 'quomodo-market-essential' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'posts_excerp_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_excerp_limit' ) ); ?>" type="text" value="<?php echo esc_attr( $posts_excerp_limit ); ?>" />
		</p>

		<p>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'image_show' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'image_show' ) ); ?>" type="checkbox" value="1" <?php checked( $image_show, 1 ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'image_show' ) ); ?>"><?php _e( esc_attr( 'Image show' ) ); ?> </label> 
		</p>
		
		<p>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'footer' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'footer' ) ); ?>" type="checkbox" value="1" <?php checked( $footer, 1 ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'footer' ) ); ?>"><?php _e( esc_attr( 'Show In Footer' ) ); ?> </label> 
		</p>
		<?php
	}

}
