<?php 
namespace QuomodoMarketEssential\Api;

Class Open_Weather_Api {

    public function get(){

        $api_key = '740cd415ed47885198f16aab3c44ff77';
        $lat     = 35;
        $lon     = 139;
        $city_id = 'london';
       
        $settings = quomodomarket_option('weather_forcast');
       
        if( isset($settings['api_key']) && $settings['api_key'] !='' ){
           $api_key = $settings['api_key'];
        }
      
        if( isset($settings['coordinates_lat']) && $settings['coordinates_lat'] !='' ){
            $lat = $settings['coordinates_lat'];
        }
        
        if( isset($settings['coordinates_lon']) && $settings['coordinates_lon'] !='' ){
            $lat = $settings['coordinates_lon'];
        }

        if( isset($settings['city_name']) && $settings['city_name'] !='' ){
            $city_id = $settings['city_name'];
        } 
      
        if(isset($settings['weather_cache_enable']) && $settings['weather_cache_enable'] == 'yes'){

        }
        if( isset($settings['data_source']) && $settings['data_source'] =='coordinate' ){
            $url = "api.openweathermap.org/data/2.5/weather?lat={$lat}&lon={$lon}&appid={$api_key}";
        }else{
            $url = "api.openweathermap.org/data/2.5/weather?q={$city_id}&appid={$api_key}";
        }
      
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        
        curl_close($ch);
        $data = json_decode($response);
        
        return $data;
    }

}