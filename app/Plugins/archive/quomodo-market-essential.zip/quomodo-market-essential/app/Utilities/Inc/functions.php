<?php 


if(!function_exists('quomodomarket_return')):
    function quomodomarket_return($str){
        return $str;
    }
endif;

/**
 * 
 *
 * get widgets class list
 *
 * @since 1.0
 * @return array
 */
if(!function_exists('quomodomarket_widgets_class_list')):

    function quomodomarket_widgets_class_list($dir){
       $classes = [];
        foreach (glob("$dir/*.php") as $filename) {
            if(!is_null(basename( $filename))){
                $classes[] = strtok( basename($filename),'.') ;
            }
           
        }
        return $classes;
    }
    
endif;

if(!function_exists('quomodomarket_option')){
    function quomodomarket_option( $option = '', $default = '' , $parent = 'quomodomarket_settings') {
       
       if( class_exists( 'CSF' ) ){
          $options = get_option( $parent ); 
          return ( isset( $options[$option] ) ) ? $options[$option] : $default;
       }
       
       return $default;
    }
 } 
function quomodomarket_errors(){
    static $wp_error; // Will hold global variable safely
    return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
}

// get theme setting option
if( !function_exists('quomodomarket_carbon_option')):
    function quomodomarket_carbon_option( $key, $default_value = '', $method = 'option' ) {
        
        if ( defined( 'QTRP' ) ) {
            switch ( $method ) {
             
                case 'option':
                    $value = carbon_get_theme_option( $key );
                    break;
                default:
                    $value = '';
                    break;
            }
            return (!isset($value) || $value == '') ? $default_value :  $value;
        }
        return $default_value;
    }
endif;
// get theme post ,page meta option
if( !function_exists('quomodomarket_carbon_meta_option')): 
    function quomodomarket_carbon_meta_option( $postid, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_post_meta($postid, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get user meta option
if( !function_exists('quomodomarket_user_meta_option')): 
    function quomodomarket_user_meta_option( $user_id, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_user_meta($user_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get comment meta option
if( !function_exists('quomodomarket_comment_meta_option')): 
    function quomodomarket_comment_meta_option( $comment_id, $key, $default_value = '' ) {

        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_comment_meta($comment_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;

    }
endif;

 if(!function_exists('quomodomarket_get_post_category')) {
    function quomodomarket_get_post_category($tax = 'category') {

        static $list = [];
        if( !count( $list ) ) {
         
            $categories = get_terms( $tax, array(
                    'orderby'       => 'name', 
                    'order'         => 'DESC',
                    'hide_empty'    => false,
                    'number'        => 200
            
            ) );
        
            foreach( $categories as $category ) {
            $list[$category->term_id] = $category->name;
            }
        }
       
        return $list;
    }
 }

 if( !function_exists('quomodomarket_get_post_tags') ){

    function quomodomarket_get_post_tags($tax = 'post_tag') {
   
        static $list = [];

        if( !count( $list ) ) {
           $categories = get_terms( $tax, array(
              'orderby'       => 'name', 
              'order'         => 'DESC',
              'hide_empty'    => false,
              'number'        => 200
             
          ) );
     
          foreach( $categories as $category ) {
             $list[$category->term_id] = $category->name;
          }
          
        }
      
        return $list;
    }
 }

 if(!function_exists('quomodomarket_get_post_author')){

    function quomodomarket_get_post_author(){
        static $list = [];

        if( !count( $list ) ) {
           $authors = get_users(
                array( 
                    'fields' => array( 'display_name','ID' ) ) 
            );
     
          foreach( $authors as $author ) {
             $list[$author->ID] = $author->display_name;
          }
          
        }
      
        return $list;
    }

 }

 if(!function_exists('quomodomarket_get_posts')) {

    function quomodomarket_get_posts(){
        static $list = [];

        if( !count( $list ) ) {
           $posts = get_posts(
                [
                'numberposts' => -1,
                'post_status' => 'publish'
                ]
            );
     
          foreach( $posts as $post ) {
             $list[$post->ID] = $post->post_title;
          }
          
        }
      
        return $list;
    }

 }

 function quomodomarket_current_theme_supported_post_format(){
   
    static $list = [];

    if( !count( $list ) ) {

        $post_formats = get_theme_support( 'post-formats' );
        
        if(isset($post_formats[0])) {
            $post_formats = $post_formats[0];
        }else{
            return $list;
        }
        
        foreach( $post_formats as $format ) {
            $list['post-format-'.$format] = $format;
        }
      
    }
   
    return $list;
   
 }

 /* elementor Slider control  */

 function quomodomarket_widgets_slider_controls_setttings($settings){
    
    $return_controls = [];

    $slider_controls = [
        'quomodomarket_slider_items',
        'slider_enable',
        'quomodomarket_slider_items_tablet',
        'quomodomarket_slider_items_mobile',
        'quomodomarket_slider_autoplay',
        'quomodomarket_slider_autoplay_timeout',
        'quomodomarket_slider_smart_speed',
        'quomodomarket_slider_dot_nav_show',
        'quomodomarket_slider_nav_show',
        'quomodomarket_slider_padding',
        'quomodomarket_slider_loop'
    ];   
    
    
    foreach($settings as $key=> $item){

       if(in_array($key,$slider_controls) ){
          $return_controls[$key] = $item;
       } 
      
    }
    
   return $return_controls;
 }
  // get all user created menu list
 function quomodomarket_get_all_menus(){

    $list = [];
    $menus = wp_get_nav_menus(); 
    
    foreach($menus as $menu){
        $list[$menu->slug] = $menu->name;
    }
    $list['empty'] = esc_html__('Empty','quomodo-market-essential');
    return $list;

 }

 function quomodomarket_get_border_style(){

    $borders_class = [
        'border_white_right'  => esc_html__( 'Right', 'quomodo-market-essential' ),
        'border_white_left'   => esc_html__( 'Left', 'quomodo-market-essential'),
        'border_white_bottom' => esc_html__( 'Bottom', 'quomodo-market-essential'),
        'border_white_top'    => esc_html__( 'Top', 'quomodo-market-essential'),
        'border_none'         => esc_html__( 'None', 'quomodo-market-essential' ),
    ];

    return $borders_class;
 }

    
    if(!function_exists('quomodomarket_meta_option')){
        function quomodomarket_meta_option( $postid, $key, $default_value = '', $parent_key = '' ) {
           
            $post_key = 'quomodomarket_post_options';  
            // page meta
            if(is_singular( 'page' )){
                $post_key = 'quomodomarket_page_options';
            }
                // post meta
            if(is_singular('post')){
                $post_key = 'quomodomarket_post_options';
            }
            // custom post meta
            if(is_singular('quomodo-service')){
                $post_key = 'quomodomarket_service_options';
            }
            // custom post meta
            if(is_singular('quomodo-case')){
                $post_key = 'quomodomarket_case_options';
            }
            
            if(is_singular('quomodo-contacts')){
                $post_key = 'quomodomarket_contacts_options';
            }
            
            if( $parent_key !='' ){
                $post_key = $parent_key;
            }

            if( class_exists( 'CSF' ) ){
              $options = get_post_meta( $postid, $post_key, true );
             
              return ( isset( $options[$key] ) ) ? $options[$key] : $default_value; 
            }
           
           return $default_value;
        }
     }
   

    

     if( !function_exists('quomodomarket_term_option')):
        
        function quomodomarket_term_option( $termid, $key, $default_value = '', $taxomony = 'category') {
           
           if ( defined( 'FW' ) ) {
                $value = fw_get_db_term_option($termid, $taxomony, $key);
            }
           
           return (!isset($value) || $value == '') ? $default_value :  $value;
        }

    endif;

    function quomodomarket_widgets_owl_slider_controls_setttings($settings){
    
        $return_controls = [];
    
        $slider_controls = [
            'quomodomarket_slider_items',
            'quomodomarket_slider_items_tablet',
            'quomodomarket_slider_items_mobile',
            'quomodomarket_slider_autoplay',
            'quomodomarket_slider_autoplay_hover_pause',
            'quomodomarket_slider_autoplay_timeout',
            'quomodomarket_slider_smart_speed',
            'quomodomarket_slider_dot_nav_show',
            'quomodomarket_slider_nav_show',
            'quomodomarket_slider_margin',
            'quomodomarket_slider_loop',
            'slider_enable'
        ];   
        
        
        foreach($settings as $key=> $item){
    
           if(in_array($key,$slider_controls) ){
              $return_controls[$key] = $item;
           } 
          
        }
        
       return $return_controls;
     }

     function quomodo_market_essen_post_time_ago_function() {
   
        return sprintf( esc_html__( '%s ago', 'quomodo-market' ), human_time_diff(get_the_time ( 'U' ), current_time( 'timestamp' ) ) );
     }