<?php 
  /*************************************
/*******  Theme svg file support  ********
**************************************/
    if(!function_exists('quomodomarket_mime_types')){

        function quomodomarket_mime_types($mimes) {
            $mimes['svg'] = 'image/svg+xml';
            return $mimes;
        }
        
    }
   
add_filter('upload_mimes', 'quomodomarket_mime_types');
/*************************************
/*******  Contact Form 7 Auto p  ********
**************************************/
add_filter('wpcf7_autop_or_not', '__return_false');

/*************************************
/*******  Load More widget Blog  ********
**************************************/


function quomodomarket_blog_post_widget_ajax_loading_cb()
{   
    $data = $_POST['ajax_json_data'];
    $arg  = $data['args'];
   
    $allpostloding = new WP_Query($arg);
    extract($data['settings']);

    if ( $allpostloding->have_posts() ) :

        while($allpostloding->have_posts()){
            
            $allpostloding->the_post(); 
            include QUOMODOMARKET_ESSENTIAL_PLUGIN_PATH.'/app/Widgets/Content/blog.php'; 
        
        }

    else:

       echo wp_send_json(['found'=>$allpostloding->found_posts]);     

    endif;

    wp_reset_postdata();
    wp_die();
  
}

/**
 * quomodo_market_archive_count_span() This code filters the Archive widget to include the post count inside the link
 * @param  [type] $links
 * @return [type] $string 
 */
function quomodo_market_archive_count_span($links) {
   
    $links = str_replace('</a>&nbsp;(', ' <span>', $links);
    $links = str_replace(')', '</span></a>', $links);
 
    return $links;
}
add_filter('get_archives_link', 'quomodo_market_archive_count_span');



add_action( 'wp_ajax_nopriv_quomodomarket_post_widget_ajax_loading', 'quomodomarket_blog_post_widget_ajax_loading_cb' );
add_action( 'wp_ajax_quomodomarket_post_widget_ajax_loading', 'quomodomarket_blog_post_widget_ajax_loading_cb' );

