<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Create a Contact info
    //
    CSF::createWidget( 'quomodomarket_contact_widget', array(
      'title'       => esc_html__( 'Quomod MarketPlace Contact Widget', 'quomodo-market-essential' ),
      'classname'   => 'about-widget',
      'description' => esc_html__( 'About us and contact info' , 'quomodo-market-essential' ),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   =>  esc_html__( 'Title' , 'quomodo-market-essential' ),
        ),
      
        array(
            'id'      => 'logo',
            'type'    => 'media',
            'title'   => esc_html__( 'Logo' , 'quomodo-market-essential' ),
            'library' => 'image',
          ),
        array(
            'id'      => 'link',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Link' , 'quomodo-market-essential' ),
        ),
        array(

          'id'      => 'content',
          'type'    => 'textarea',
          'title'   => esc_html__( 'Content' , 'quomodo-market-essential' ),
         
        ),

        array(

            'id'     => 'contact_info',
            'type'   => 'repeater',
            'title'   => esc_html__( 'Contact info' , 'quomodo-market-essential' ),
            'fields' => array(
          
                array(
                    'id'    => 'icon',
                    'type'  => 'icon',
                    'title'   => esc_html__( 'Icon' , 'quomodo-market-essential' ),
                ),
                
                array(
                    'id'      => 'title',
                    'type'    => 'text',
                    'title'   =>  esc_html__( 'Title' , 'quomodo-market-essential' ),
                ),
                array(
                    'id'      => 'content',
                    'type'    => 'textarea',
                    'title'   =>  esc_html__( 'Content' , 'quomodo-market-essential' ),
                ),
            ),
        ),
  
      )
    ) );
  
    
    if( ! function_exists( 'quomodomarket_contact_widget' ) ) {
      function quomodomarket_contact_widget( $args, $instance ) {
  
        echo $args['before_widget'];
  
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }

        ?>
       
            <div class="foo-logo">
                <?php if($instance['link'] !=''): ?>
                    <a href="<?php echo esc_url($instance['link']); ?>"><img src="<?php echo esc_url($instance['logo']['url']); ?>" alt="<?php echo esc_attr($instance['title']); ?>"/></a>
                <?php else: ?> 
                    <img src="<?php echo esc_url($instance['logo']['url']); ?>" alt="<?php echo esc_attr($instance['title']); ?>"/>
                <?php endif; ?>
            </div>
          
           <?php if($instance['content'] !=''): ?>
                <p>
                    <?php echo quomodomarket_kses($instance['content']); ?>
                </p>
           <?php endif; ?>
           <?php if(is_array( $instance['contact_info'])): ?>
                <?php foreach($instance['contact_info'] as $item): ?>
                    <div class="icon-box-03">
                        <i class=" <?php echo esc_attr($item['icon']) ?> "></i>
                        <span><?php echo esc_html($item['title']) ?></span>
                        <h5><?php echo esc_html($item['content']) ?></h5>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
       <?php
        echo $args['after_widget'];
  
      }
    }
  
  }
  