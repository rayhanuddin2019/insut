<?php

if( class_exists( 'CSF' ) ) {

  //
  // Create a video popup widget
  //
  CSF::createWidget( 'quomodomarket_widget_video_popup', array(
    'title'       => esc_html__( 'Insut Video PopUp Widget', 'quomodo-market-essential' ),
    'classname'   => 'widget-video',
    'description'       => esc_html__( 'Insut Video PopUp', 'quomodo-market-essential' ),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   =>  esc_html__( 'Title' , 'quomodo-market-essential' ),
        ),


        array(
            'id'    => 'icon',
            'type'  => 'icon',
            'title'   => esc_html__( 'Video Icon' , 'quomodo-market-essential' ),
        ),

        array(
              'id'      => 'link',
              'type'    => 'text',
              'title'   =>  esc_html__( 'Youtube Video Link' , 'quomodo-market-essential' ),
              'desc'    => esc_html__( 'Provide Embed youtube link Link', 'quomodo-market-essential' )
        ),

        array(
            'id'           => 'image',
            'type'         => 'upload',
            'title'   =>  esc_html__( 'Image' , 'quomodo-market-essential' ),
            'library'      => 'image',
            'placeholder'  => 'http://',
            'button_title' => esc_html__( 'Add Image', 'quomodo-market-essential' ),
            'remove_title' => esc_html__( 'Remove Image', 'quomodo-market-essential' )
          ),

      

    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'quomodomarket_widget_video_popup' ) ) {
    function quomodomarket_widget_video_popup( $args, $instance ) {

      
       echo $args['before_widget'];
    
      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }
      ?>
        <div class="video-area" style="background-image: url(<?php echo esc_url($instance['image']); ?>);">
            <a class="popup-video" href="<?php echo esc_url($instance['link']); ?>" data-rel="lightcase">
            <?php if($instance['icon'] == ''): ?>
            <i class="icofont-ui-play"></i>
            <?php else: ?>
                <i class="<?php echo esc_attr($instance['icon']); ?>" ></i>
            <?php endif; ?>
        </a>
        </div>
     <?php
   

      echo $args['after_widget'];

    }
  }

}
