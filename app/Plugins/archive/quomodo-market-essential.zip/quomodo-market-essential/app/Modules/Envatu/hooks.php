<?php

function quomodo_market_items_setting_notice($data) {
    ?>
    <?php if( isset($_GET["post_type"]) && isset($_GET["page"]) && isset($_GET["message"]) ): ?>
        <?php if($_GET["post_type"] == "envato-portfolio" && $_GET["page"] =="ew_rest_api_data_setting"): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($_GET["message"]); ?></p>
            </div>
        <?php endif; ?>    
    <?php endif; ?>       
    <?php
}

add_action( 'admin_notices', 'quomodo_market_items_setting_notice' );

register_deactivation_hook(QUOMODOMARKET_ESSENTIAL_PLUGIN_PATH, 'quomodo_market_schedule_deactivation');

function quomodo_market_schedule_deactivation() {
    ew_store_log("All EW schedules have been removed");
	wp_clear_scheduled_hook('ew_get_product_item_from_server_cron_action');
	wp_clear_scheduled_hook('ew_get_single_product_item_from_server_cron_action');
}

