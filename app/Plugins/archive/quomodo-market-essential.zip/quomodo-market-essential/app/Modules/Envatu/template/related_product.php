     
    <?php 
    
       $related_product = quomodo_market_related_products_by_tags();
       $option = get_option( 'ew_options_data' );
       $title_limit = isset($option['ew_related_product_title_limit'])?$option['ew_related_product_title_limit']:5;
      
       if(!isset($related_product->found_posts)){
         return;
       }
       
       if(!$related_product->found_posts){
         return;
       }

  
    ?> 

    <section class="featured-product-area featured-product-page">
        <div class="featured-product-item-area pt-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="featured-product-title d-sm-flex d-block align-items-center justify-content-between">
                            <h3 class="title"> <?php echo esc_html__( 'Similiar Templates', 'quomodo-market-essentail' ) ?> </h3>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <?php while ($related_product->have_posts()) : $related_product->the_post(); ?>
                         <?php
                             $value_id          = get_post_meta( get_the_id(), 'ew_envato_item_id',true);
                             $reserved_data     = quomodo_market_ewSingleitemdata($value_id);
                             $value_rating      = get_post_meta( get_the_id(), 'ew_envato_item_rating',true);
                             $base_rating       =  (integer) $value_rating;
                             
                             $starPercentage = ($base_rating / 5) * 100;
                             $starPercentageRounded = (($starPercentage / 10) * 10).'%';
                           
                           ?>
                        <div class="col-lg-3 col-md-6 col-sm-7">
                            <div class="featured-product-item mt-30 animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="0ms">
                               <?php if(has_post_thumbnail()): ?>
                                   <div class="featured-product-thumb">
                                      <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>">
                                    </div>
                                <?php endif; ?>
                                <div class="featured-product-content">
                                    <h3 class="title"> <?php echo esc_html(wp_trim_words(get_the_title(),$title_limit,'...')); ?> </h3>
                                    <P> <?php echo get_the_excerpt(); ?> </P>
                                    <ul>
                                        <li><span><i class="fas fa-download"></i> <?php echo get_post_meta( get_the_id(), 'ew_envato_item_sales',true); ?> </span></li>
                                        <li>
                                            <div class="stars-outer">
                                              <div data-rating="<?php echo esc_attr($starPercentageRounded); ?>" class="stars-inner"></div>
                                            </div>
                                            <span>(<?php echo esc_html($value_rating); ?>)</span>
                                                 
                                        </li>
                                    </ul>
                                </div>
                                <div class="featured-product-overlay">
                                    <ul>

                                        <?php if(isset($reserved_data['previews'])): ?>
                                              <?php $reserved_data_live_site = $reserved_data['previews']; ?>
                                              <?php if(isset($reserved_data_live_site['live_site']) && ew_is_connected()): ?>
                                                <li><a class="main-btn" href="#"><?php echo esc_html__( 'Live Preview', 'quomodo-market-essential' ) ?></a></li>
                                                <?php endif; ?> 
                                          <?php endif; ?> 
                                        <li><a class="main-btn main-btn-2" href="<?php the_permalink(  ) ?>"> <?php echo esc_html__( 'Theme Details', 'quomodo-market-essential' ) ?> </a></li>
                                    </ul>
                                </div>
                                <div class="box">
                                    <?php if(isset($reserved_data["price_cents"])): ?>
                                          <span> <?php echo esc_html("$".number_format(($reserved_data["price_cents"]/100), 0, '.', ' ') ); ?> </span>
                                    <?php endif; ?> 
                                </div>
                            </div>
                        </div>
                    <?php endwhile; wp_reset_postdata(); ?> 
                </div>
            </div>
        </div>
    </section>