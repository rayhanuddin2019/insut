<?php 

function quomodo_market_create_envato_world_portfolio() {
  $slug = 'themeforest-product';
  $name = 'themeforest-product';
  $names = 'themeforest-products';
  $option_data = get_option( 'ew_options_data' );

  if(isset($option_data['ew_product_slug'])){
      if($option_data['ew_product_slug'] !=''){
        $slug = $option_data['ew_product_slug'];
      }
  }
    
  if(isset($option_data['ew_product_name'])){
      if($option_data['ew_product_name'] !=''){
      $name = $option_data['ew_product_name'];
      }
  }

  if(isset($option_data['ew_product_names'])){
    if($option_data['ew_product_names'] !=''){
    $names = $option_data['ew_product_names'];
    }
  }
 
   register_post_type( 'envato-portfolio',
     array(
       'labels' => array(
         'name' => $names,
         'singular_name' => $name
       ),
       'public' => true,
       'has_archive' => true,
       'supports'=>array(
         'title',
         'editor',
         'thumbnail',
         'excerpt'
      ),
      'rewrite'             => array( 'slug' => $slug ),
     )
   );
 }
 add_action( 'init', 'quomodo_market_create_envato_world_portfolio' );

 function quomdo_market_load_portfolio_template($template,$data) {
   global $post;
  
   if ($post->post_type == "envato-portfolio" && $template !== locate_template(array("portfolio.php"))){
       $old_temp = explode('/',$template);
       if(is_array($old_temp)){
         $file_ext = end($old_temp);
         if($file_ext == 'single-envato-portfolio.php'){
           return $template;
         }
       } 
       return QUOMODOMARKET_ESSENTIAL_PLUGIN_PATH . "app/Modules/Envatu/template/portfolio.php";
   }

   return $template;
}

add_filter('single_template', 'quomdo_market_load_portfolio_template',10,2);