<?php
/**
 * the template for displaying all posts.
 */

   get_header(); 
   //get_template_part( 'template-parts/banner/content', 'banner-blog' );
   $reserved_data = [];    
   $setting_option = get_option( 'ew_options_data' );
   
?>
  
  <div class="quomodo-theme-portfolio" id="post-<?php the_ID(); ?>"  role="main">

  <?php while ( have_posts() ) : the_post(); ?>
          <?php 

            $item_type         = '';
            $post_id           = $post->ID;
            $value_id          = get_post_meta( $post_id, 'ew_envato_item_id',true);
            $sub_title         = get_post_meta( $post_id, 'ew_envato_item_sub_title',true);
            $value_url         = get_post_meta( $post_id, 'ew_envato_item_url',true);
            $value_license_url = get_post_meta( $post_id, 'ew_envato_item_license_url',true);
            $value_user        = get_post_meta( $post_id, 'ew_envato_item_user',true);
            $value_sales       = get_post_meta( $post_id, 'ew_envato_item_sales',true);
            $value_rating      = get_post_meta( $post_id, 'ew_envato_item_rating',true);
            $value_cost        = get_post_meta( $post_id, 'ew_envato_item_cost',true);
            $value_uploaded_on = get_post_meta( $post_id, 'ew_envato_item_uploaded_on',true);
            $value_tags        = get_post_meta( $post_id, 'ew_envato_item_tags',true);
            $value_category    = get_post_meta( $post_id, 'ew_envato_item_category',true);
            $reserved_data     = quomodo_market_ewSingleitemdata($value_id);
           
            if(isset($reserved_data["classification"])){
              $classification = explode('/',$reserved_data["classification"]);
              if(in_array("wordpress",$classification) ){
                $item_type = esc_html__("WordPress",'quomodo-market-essential');
              }elseif(in_array("site-templates",$classification) ){
                $item_type =  esc_html__("html",'quomodo-market-essential');
              }elseif(in_array("joomla",$classification) ){
                $item_type = esc_html__("joomla",'quomodo-market-essential');
              }
               
            }
            $skip_attribute = ['demo-url'];
            
          
          ?>
          <section class="product-details-area">
              <div class="container">
                  <div class="row">
                      <div class="col-lg-12">
                          <div class="details-title text-center">
                              <h2 class="title"> <?php echo esc_html(get_the_title()); ?> </h2>
                              <?php if($sub_title !=''): ?>
                                <span> <?php echo esc_html( $sub_title ) ?> </span>
                              <?php endif; ?>
                          </div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-lg-8">
                          <div class="product-details-item mt-30">
                              <div class="product-thumb">
                                  <div class="thumb">
                                      <?php if(get_the_post_thumbnail_url($post_id)): ?>
                                            <img class="img-responsive" src="<?php echo esc_url(get_the_post_thumbnail_url($post_id)); ?>" >
                                      <?php else: ?>   
                                          <img class="img-responsive" src="<?php echo esc_url($reserved_data["previews"]["landscape_preview"]["landscape_url"]); ?>" alt="<?php echo esc_html($reserved_data["name"]); ?>">
                                      <?php endif; ?> 
                                      <div class="product-thumb-overlay">
                                          <ul>
                                              <?php if(isset($reserved_data['previews'])): ?>
                                                    <?php $reserved_data_live_site = $reserved_data['previews']; ?>
                                                    <?php if(isset($reserved_data_live_site['live_site']) && ew_is_connected()): ?>
                                                      <li> <a class="main-btn" href="<?php echo esc_url("https://".$reserved_data["site"].$reserved_data["previews"]["live_site"]["href"]); ?>" target="_blank"><?php echo esc_html__("Live Preview",'quomodo-market-essential'); ?> </a></li>
                                                    <?php endif; ?> 
                                              <?php endif; ?> 
                                              <?php if(isset($reserved_data['url'])): ?>    
                                                <li>
                                                    <a href="<?php echo esc_url($reserved_data['url']); ?>" class="main-btn main-btn-2">
                                                        <?php echo esc_html__('Buy This','quomodo-market-essential'); ?>
                                                    </a>
                                                </li>
                                              <?php endif; ?>
                                           </ul>
                                      </div>
                                  </div>
                              </div>
                              <div class="product-details-tab">
                                  <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                      <li class="nav-item" role="presentation">
                                          <a class="nav-link active" id="pills-1-tab" data-toggle="pill" href="#pills-1" role="tab" aria-controls="pills-1" aria-selected="true"> <?php echo esc_html__( 'Details', 'quomodo-market-essential' ) ?></a>
                                      </li>
                                      <?php if(isset($setting_option['ew_product_comment'])): ?>
                                          <li class="nav-item" role="presentation">
                                              <a class="nav-link" id="pills-2-tab" data-toggle="pill" href="#pills-2" role="tab" aria-controls="pills-2" aria-selected="false">
                                               
                                                    <?php 
                                                        if(get_comments_number()==1){
                                                          printf(  esc_html__( 'Comment', 'quomodo-market' ) .'('.'%1$s'.')' , get_comments_number() );
                                                        }else{
                                                          printf(  esc_html__( 'Comments', 'quomodo-market' ) .'('.'%1$s'.')' , get_comments_number() );
                                                        }
                                                    ?>
                                              
                                              </a>
                                          </li>
                                     <?php endif; ?>
                                     <?php if(isset($setting_option['ew_product_review'])): ?>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link" id="pills-3-tab" data-toggle="pill" href="#pills-3" role="tab" aria-controls="pills-3" aria-selected="false"> <?php echo esc_html__( 'Review', 'quomodo-market-essential' ) ?> </a>
                                        </li>
                                     <?php endif; ?>
                                     <?php if(isset($setting_option['ew_product_support'])): ?>
                                      <li class="nav-item" role="presentation">
                                          <a class="nav-link" id="pills-4-tab" data-toggle="pill" href="#pills-4" role="tab" aria-controls="pills-4" aria-selected="false"> <?php echo esc_html__( 'Support', 'quomodo-market-essential' ) ?></a>
                                      </li>
                                      <?php endif; ?>
                                  </ul>
                                  <div class="tab-content" id="pills-tabContent">
                                      <div class="tab-pane fade show active" id="pills-1" role="tabpanel" aria-labelledby="pills-1-tab">
                                          <div class="text">

                                              <?php if($post->post_content==''): ?>
                                                  <?php if(isset($reserved_data["description"])): ?>   
                                                    <?php echo wp_kses_post(($reserved_data["description"])); ?>
                                                  <?php endif; ?>  
                                              <?php else: ?>
                                                    <?php echo wp_kses_post(($post->post_content)); ?>
                                              <?php endif; ?> 
                                             
                                          </div>
                                      </div>
                                      <?php if(isset($setting_option['ew_product_comment'])): ?>
                                      <div class="tab-pane fade" id="pills-2" role="tabpanel" aria-labelledby="pills-2-tab">
                                        <?php  comments_template();  ?>
                                      </div>
                                      <?php endif; ?>
                                      <?php if(isset($setting_option['ew_product_review'])): ?>
                                      <div class="tab-pane fade" id="pills-3" role="tabpanel" aria-labelledby="pills-3-tab">
                                          <div class="product-review-area">
                                               <?php if($setting_option['ew_review_shortcode'] !=''): ?>
                                                <?php echo do_shortcode(trim($setting_option['ew_review_shortcode'])); ?>
                                                <?php else: ?>
                                                       <?php do_action( 'quomodo_market_product_review' ); ?>
                                               <?php endif; ?>
                                          </div>
                                      </div>
                                      <?php endif; ?>
                                      <?php if(isset($setting_option['ew_product_support'])): ?>
                                      <div class="tab-pane fade" id="pills-4" role="tabpanel" aria-labelledby="pills-4-tab">
                                          <div class="support-area">
                                              <?php if($setting_option['ew_support_shortcode'] !=''): ?>
                                                <?php echo do_shortcode(trim($setting_option['ew_support_shortcode'])); ?>
                                                <?php else: ?>
                                                       <?php do_action( 'quomodo_market_product_support' ); ?>
                                               <?php endif; ?>
                                          </div>
                                      </div>
                                      <?php endif; ?> 
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4">
                          <div class="product-details-sidebar mt-30">
                              <div class="product-details-download text-center">
                                  <i class="fas fa-download"></i><br>
                                  <?php if(isset($reserved_data["number_of_sales"])): ?>
                                     <span><?php echo esc_html__( 'Total Download', 'quomodo-market-essential' ).' :'; ?> <?php echo esc_html($reserved_data["number_of_sales"]); ?></span>
                                  <?php endif; ?> 
                              </div>
                              <div class="product-details-buy text-center mt-40">
                                  <span><?php echo esc_html( get_the_title() ); ?></span>
                                  <?php if(isset($reserved_data["price_cents"])): ?>
                                     <h3 class="title"><?php echo esc_html("$".number_format(($reserved_data["price_cents"]/100), 2, '.', ' ') ); ?></h3>
                                  <?php endif; ?> 
                                  <ul>
                                      <?php if(isset($reserved_data['previews'])): ?>
                                              <?php $reserved_data_live_site = $reserved_data['previews']; ?>
                                              <?php if(isset($reserved_data_live_site['live_site']) && ew_is_connected()): ?>
                                                <li> <a class="main-btn" href="<?php echo esc_url("https://".$reserved_data["site"].$reserved_data["previews"]["live_site"]["href"]); ?>" target="_blank"><?php echo esc_html__("Live Preview",'quomodo-market-essential'); ?> </a></li>
                                              <?php endif; ?> 
                                        <?php endif; ?> 
                                        <?php if(isset($reserved_data['url'])): ?>    
                                          <li>
                                              <a href="<?php echo esc_url($reserved_data['url']); ?>" class="main-btn main-btn-2">
                                                  <?php echo esc_html__('Buy This','quomodo-market-essential'); ?>
                                              </a>
                                          </li>
                                        <?php endif; ?>
                                  </ul>
                              </div>
                              <div class="product-information mt-40">
                                  <div class="title text-center">
                                      <h3><?php echo esc_html__( 'Product Information', 'quomodo-market-essential' ) ?></h3>
                                  </div>
                                  <div class="product-information-list">
                                      <ul>
                                          <li>
                                             <ul class="product-information-content d-flex">  
                                                <li class="product-label">  <?php echo esc_html__( 'Last Update', 'quomodo-market-essential' ).' :'; ?> </li>
                                                <li class="product-value">  <span><?php echo esc_html(date('d M, Y', strtotime($reserved_data["updated_at"]))); ?></span> </li>
                                             </ul> 
                                            
                                          </li>
                                          <li>
                                             <ul class="product-information-content d-flex">  
                                                <li class="product-label">  <?php echo esc_html__( 'Released', 'quomodo-market-essential' ).' :'; ?> </li>
                                                <li class="product-value">  <span><?php echo esc_html(date('d M, Y', strtotime($reserved_data["published_at"]))); ?></span> </li>
                                             </ul> 
                                            
                                          </li>
                                          <?php if(isset($reserved_data["wordpress_theme_metadata"]["version"])): ?>
                                          <li>
                                             <ul class="product-information-content d-flex">  
                                                <li class="product-label">  <?php echo esc_html__( 'Version', 'quomodo-market-essential' ).' :'; ?> </li>
                                                <li class="product-value">  <span> <?php echo esc_html($reserved_data["wordpress_theme_metadata"]["version"]); ?> </span> </li>
                                             </ul> 
                                            
                                          </li>
                                          <?php endif; ?>
                                          <li>
                                             <ul class="product-information-content d-flex">  
                                                <li class="product-label">  <?php echo esc_html__( 'Category', 'quomodo-market-essential' ).' :'; ?> </li>
                                                <li class="product-value">  <span> <?php echo esc_html($item_type); ?> </span> </li>
                                             </ul> 
                                            
                                          </li>
                                           
                                              <?php if(isset($reserved_data["attributes"])): ?>
                                                      <?php foreach($reserved_data["attributes"] as $item_attr): ?>
                                                       
                                                          <?php if(!in_array($item_attr['name'],$skip_attribute)): ?>
                                                                  <li>
                                                                      <ul class="product-information-content d-flex"> 
                                                                            <li class="product-label"> <?php echo explode('-',$item_attr["name"])[0].' :'; ?> </li>
                                                                            <li class="product-value"> 
                                                                              <span>
                                                                                  <?php
                                                        
                                                                                        if(is_array($item_attr["value"])):
                                                                                          echo implode(' , ',$item_attr["value"]);
                                                                                        else:
                                                                                          if(wp_http_validate_url($item_attr["value"])):
                                                                                            echo "<a href=".esc_url($item_attr["value"]).">".esc_html__("Open",'quomodo-market-essential') ."</a>" ; 
                                                                                          else:
                                                                                          echo esc_html($item_attr["value"]); 
                                                                                          endif;  
                                                                                        endif;  

                                                                                  ?> 
                                                                              </span> 
                                                                          </li>
                                                                    </ul> 
                                                                  </li>
                                                          <?php endif; ?>
                                                          
                                                    <?php endforeach; ?>
                                              <?php endif; ?>
                                                                                             
                                      </ul>
                                     
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <?php do_action('quomodo_market_related_product'); ?>
    <?php endwhile; ?>

<?php get_footer(); ?>