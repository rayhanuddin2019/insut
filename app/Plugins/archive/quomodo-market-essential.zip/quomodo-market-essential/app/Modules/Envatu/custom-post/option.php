<?php

class Quomodo_Market_Custom_Cpt_SettingsPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
       

        add_submenu_page(
            'edit.php?post_type=envato-portfolio',
            __( 'Settings', 'quomodo-market-essential' ),
            __( 'Settings', 'quomodo-market-essential' ),
            'manage_options',
            'ew-cpt-setting-admin',
            array($this,'create_admin_page')
            
        );

        add_submenu_page(
         'edit.php?post_type=envato-portfolio',
         __( 'Product Import', 'quomodo-market-essential' ),
         __( 'Product Import', 'quomodo-market-essential' ),
         'manage_options',
         'ew_rest_api_data_setting',
         array($this,'ew_rest_api_data_setting_page')
         
       );

    }
    
    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'ew_options_data' );
        ?>
        <div class="wrap quomodo-themeforest-settings">
            <h1> <?php echo esc_html__( 'ThemeForst Settings', 'quomodo-market-essential' ) ?></h1>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'my_option_group' );
                do_settings_sections( 'ew-cpt-setting-admin' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'my_option_group', // Option group
            'ew_options_data', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', // ID
            __('General Settings','quomodo-market-essential'), // Title
            array( $this, 'print_section_info' ), // Callback
            'ew-cpt-setting-admin' // Page
        );  

        add_settings_field(
            'token_number', // ID
            __('Envato Api Token ','quomodo-market-essential'), // Title 
            array( $this, 'token_number_callback' ), // Callback
            'ew-cpt-setting-admin', // Page
            'setting_section_id' // Section           
        );
        
        add_settings_field(
         'ew_product_cache_time', // ID
         __('Envato Product Cache Time','quomodo-market-essential'), // Title 
         array( $this, 'ew_product_cache_time_callback' ), // Callback
         'ew-cpt-setting-admin', // Page
         'setting_section_id' // Section           
        );
        
        add_settings_field(
         'ew_single_product_cache_time', // ID
         __('Envato Product Cache Time(single)','quomodo-market-essential'), // Title 
         array( $this, 'ew_single_product_cache_time_callback' ), // Callback
         'ew-cpt-setting-admin', // Page
         'setting_section_id' // Section           
        ); 

        add_settings_field(
            'ew_portfolio_allowed_category', 
            __('Allowed Category','quomodo-market-essential'), 
            array( $this, 'ew_portfolio_allowed_category_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'ew_portfolio_schedule_update_time', 
            __('Schedule time','quomodo-market-essential'), 
            array( $this, 'ew_portfolio_schedule_update_time_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'title_heading', 
            __('Product Settings ','quomodo-market-essential'), 
            array( $this, 'heading_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );
        
        add_settings_field(
            'cpt_slug', 
            __('Slug','quomodo-market-essential'), 
            array( $this, 'ew_product_slug_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );  
        
        add_settings_field(
            'cpt_name', 
            __('Name','quomodo-market-essential'), 
            array( $this, 'ew_product_name_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );
        
        add_settings_field(
            'cpt_names', 
            __('Plural Name','quomodo-market-essential'), 
            array( $this, 'ew_product_names_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );
        
        add_settings_field(
            'title_heading2', 
            __('Page Tabs ','quomodo-market-essential'), 
            array( $this, 'heading_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );


        add_settings_field(
            'cpt_enable_comment', 
            __('Comments','quomodo-market-essential'), 
            array( $this, 'ew_product_comment_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'cpt_enable_review', 
            __('Reviews','quomodo-market-essential'), 
            array( $this, 'ew_product_review_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'cpt_review_shortcode', 
            __('Reviews ShortCode','quomodo-market-essential'), 
            array( $this, 'ew_product_review_shortcode_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'cpt_enable_support', 
            __('Supports','quomodo-market-essential'), 
            array( $this, 'ew_product_support_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        ); 

        add_settings_field(
            'cpt_support_shortcode', 
            __('Support ShortCode','quomodo-market-essential'), 
            array( $this, 'ew_product_support_shortcode_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );

        add_settings_field(
            'cpt_enable_related_product', 
            __('Related Product','quomodo-market-essential'), 
            array( $this, 'ew_related_product_callback' ), 
            'ew-cpt-setting-admin', 
            'setting_section_id'
        );
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['token_number'] ) )
            $new_input['token_number'] = sanitize_text_field( $input['token_number'] );

        if( isset( $input['title'] ) )
            $new_input['title'] = sanitize_text_field( $input['title'] );

        if( isset( $input['ew_portfolio_allowed_category'] ) )
            $new_input['ew_portfolio_allowed_category'] = sanitize_text_field( $input['ew_portfolio_allowed_category'] );

        if( isset( $input['ew_product_cache_time'] ) )
            $new_input['ew_product_cache_time'] = sanitize_text_field( $input['ew_product_cache_time'] );

        if( isset( $input['ew_single_product_cache_time'] ) )
            $new_input['ew_single_product_cache_time'] = sanitize_text_field( $input['ew_single_product_cache_time'] );
            
        if( isset( $input['ew_product_slug'] ) )
            $new_input['ew_product_slug'] = sanitize_text_field( $input['ew_product_slug'] );
        if( isset( $input['ew_product_name'] ) )
            $new_input['ew_product_name'] = sanitize_text_field( $input['ew_product_name'] );
            
        if( isset( $input['ew_product_names'] ) )
            $new_input['ew_product_names'] = sanitize_text_field( $input['ew_product_names'] );
            
        if( isset( $input['ew_product_comment'] ) )
            $new_input['ew_product_comment'] = sanitize_text_field($input['ew_product_comment']);
            
        if( isset( $input['ew_product_review'] ) )
            $new_input['ew_product_review'] = sanitize_text_field($input['ew_product_review']);

        if( isset( $input['ew_product_support'] ) )
        $new_input['ew_product_support'] = sanitize_text_field($input['ew_product_support']);
        
        if( isset( $input['ew_review_shortcode'] ) )
        $new_input['ew_review_shortcode'] = sanitize_text_field($input['ew_review_shortcode']);
        
        if( isset( $input['ew_support_shortcode'] ) )
        $new_input['ew_support_shortcode'] = sanitize_text_field($input['ew_support_shortcode']);
        if( isset( $input['ew_related_product'] ) )
        $new_input['ew_related_product'] = sanitize_text_field($input['ew_related_product']);
        if( isset( $input['ew_portfolio_schedule_update_time'] ) )
            $new_input['ew_portfolio_schedule_update_time'] = sanitize_text_field( $input['ew_portfolio_schedule_update_time'] );
        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'Enter your settings below:';
    }
    public function heading_callback(){
      
    }
    public function ew_portfolio_schedule_update_time_callback(){
       
        echo '<select id="ew_portfolio_schedule_update_time" name="ew_options_data[ew_portfolio_schedule_update_time]" >';
        echo '<option value="">'.__("Select schedule",'quomodo-market-essential').'</option>'; 
        foreach(wp_get_schedules() as $key_time=>$schedule_time):
            if( isset($schedule_time["display"]) ): 
                if($key_time==$this->options['ew_portfolio_schedule_update_time']):  
                    echo '<option selected value="'.$key_time.'">'.$schedule_time["display"].'</option>';
                else:
                    echo '<option value="'.$key_time.'">'.$schedule_time["display"].'</option>';      
                endif;     
            endif;   
        endforeach;  
        echo '</select>';
       
    }
    public function ew_single_product_cache_time_callback(){
      printf(
         '<input type="text" id="ew_single_product_cache_time" name="ew_options_data[ew_single_product_cache_time]" value="%s" /> <span class="cache-time"> %s </span> ',
         isset( $this->options['ew_single_product_cache_time'] ) ? esc_attr( $this->options['ew_single_product_cache_time']) : '',
         esc_html__("In seconds",'quomodo-market-essential')
     );
    }
    
    public function ew_product_comment_callback(){
       
        ?>
            <ul class="switch_common switch_style2 switch_icon d_inline float-right">
                <li class="md_switch">
                    <?php if(isset($this->options['ew_product_comment'])){ ?>
                    <input name="ew_options_data[ew_product_comment]" value="1" class="switch" id="ew_product_comment" type="checkbox" <?php echo 'checked'; ?>>
                    <?php }else{ ?>
                        <input name="ew_options_data[ew_product_comment]" class="switch" id="ew_product_comment" type="checkbox" >
                    <?php } ?>
                    <label for="ew_product_comment"></label>
                </li>
            </ul>
        
        <?php 

    }
    
    public function ew_related_product_callback(){
       
        ?>
            <ul class="switch_common switch_style2 switch_icon d_inline float-right">
                <li class="md_switch">
                    <?php if(isset($this->options['ew_related_product'])){ ?>
                    <input name="ew_options_data[ew_related_product]" value="1" class="switch" id="ew_related_product" type="checkbox" <?php echo 'checked'; ?>>
                    <?php }else{ ?>
                        <input name="ew_options_data[ew_related_product]" class="switch" id="ew_related_product" type="checkbox" >
                    <?php } ?>
                    
                    <label for="ew_related_product"></label>
                    <p> <?php echo esc_html__( 'Show Related Product In details Page', 'quomodo-market-essential' ) ?> </p>
                </li>
            </ul>
        
        <?php 

    }

    public function ew_product_support_callback(){
       
        ?>
            <ul class="switch_common switch_style2 switch_icon d_inline float-right">
                <li class="md_switch">
                    <?php if(isset($this->options['ew_product_support'])){ ?>
                    <input name="ew_options_data[ew_product_support]" value="1" class="switch" id="ew_product_support" type="checkbox" <?php echo 'checked'; ?>>
                    <?php }else{ ?>
                        <input name="ew_options_data[ew_product_support]" class="switch" id="ew_product_support" type="checkbox" >
                    <?php } ?>
                    <label for="ew_product_support"></label>
                </li>
            </ul>
        
        <?php 

    }

    public function ew_product_review_callback(){
       
        ?>
                   <ul class="switch_common switch_style2 switch_icon d_inline float-right">
                        <li class="md_switch">
                            <?php if(isset($this->options['ew_product_review'])){ ?>
                            <input name="ew_options_data[ew_product_review]" value="1" class="switch" id="ew_product_review" type="checkbox" <?php echo 'checked'; ?>>
                            <?php }else{ ?>
                                <input name="ew_options_data[ew_product_review]" class="switch" id="ew_product_review" type="checkbox" >
                            <?php } ?>
                            <label for="ew_product_review"></label>
                        </li>
                   </ul>
        
        <?php 

    }
    public function ew_portfolio_allowed_category_callback(){

        $transient_data = get_transient( 'ew_item_category_data' );
        if(!$transient_data){
            $transient_data =[]; 
        }
      printf(
         '<input type="text" id="ew_portfolio_allowed_category" name="ew_options_data[ew_portfolio_allowed_category]" value="%s" />' .'<i> Hints: '. implode(',',$transient_data ). '</i>',
         isset( $this->options['ew_portfolio_allowed_category'] ) ? esc_attr( $this->options['ew_portfolio_allowed_category']) : ''
     );
    }
    public function ew_product_cache_time_callback(){
      printf(
         '<input type="text" id="ew_product_cache_time" name="ew_options_data[ew_product_cache_time]" value="%s" /> <span class="cache-time"> %s  </span> ',
         isset( $this->options['ew_product_cache_time'] ) ? esc_attr( $this->options['ew_product_cache_time']) : '',
         esc_html__("In seconds",'quomodo-market-essential')
     );
    }

    public function ew_product_support_shortcode_callback(){
        printf(
           '<input type="text" id="ew_support_shortcode" name="ew_options_data[ew_support_shortcode]" value="%s" /> ',
           isset( $this->options['ew_support_shortcode'] ) ? esc_attr( $this->options['ew_support_shortcode']) : ''
          
       );
    }

    public function ew_product_review_shortcode_callback(){
        printf(
           '<input type="text" id="ew_review_shortcode" name="ew_options_data[ew_review_shortcode]" value="%s" /> ',
           isset( $this->options['ew_review_shortcode'] ) ? esc_attr( $this->options['ew_review_shortcode']) : ''
          
       );
    }

    public function ew_product_slug_callback(){
        printf(
           '<input type="text" id="ew_product_slug" name="ew_options_data[ew_product_slug]" value="%s" /> <span class="q-slug"> %s  </span> ',
           isset( $this->options['ew_product_slug'] ) ? esc_attr( $this->options['ew_product_slug']) : '',
           esc_html__("Product Slug",'quomodo-market-essential')
       );
    }
    
    
    public function ew_product_name_callback(){
        printf(
           '<input type="text" id="ew_product_name" name="ew_options_data[ew_product_name]" value="%s" /> <span class="q-name"> %s  </span> ',
           isset( $this->options['ew_product_name'] ) ? esc_attr( $this->options['ew_product_name']) : '',
           esc_html__("Product Singular Name",'quomodo-market-essential')
       );
    }

    public function ew_product_names_callback(){

        printf(
           '<input type="text" id="ew_product_names" name="ew_options_data[ew_product_names]" value="%s" /> <span class="q-names"> %s  </span> ',
           isset( $this->options['ew_product_names'] ) ? esc_attr( $this->options['ew_product_names']) : '',
           esc_html__("Product Name",'quomodo-market-essential')
       );
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function token_number_callback()
    {
        printf(
            '<input type="text" id="token_number" name="ew_options_data[token_number]" value="%s" />',
            isset( $this->options['token_number'] ) ? esc_attr( $this->options['token_number']) : ''
        );
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function title_callback()
    {
        printf(
            '<input type="text" id="title" name="ew_options_data[title]" value="%s" />',
            isset( $this->options['title'] ) ? esc_attr( $this->options['title']) : ''
        );
    }

    public function ew_rest_api_data_setting_page(){
       
    ?>
    
    <div class="ew-admin-inner-content">
     
      <h1> <?php echo esc_html__( 'Product Colloction', 'quomodo-market-essential' ) ?> </h1>
      <hr/>
      <h3> <?php echo esc_html__( 'Cache ThemeForest all item', 'quomodo-market-essential') ?> </h3>
      <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">

      <label for="ew_data_type"><?php esc_html__("Data source",'quomodo-market-essential'); ?> </label>
      <select id="ew_data_type" name="ew_data_type" >
           <option  value="0"> <?php echo esc_html__("Select option",'quomodo-market-essential'); ?> </option>
           <option  value="ew_restapi"> <?php echo esc_html__("Envato Server to local",'quomodo-market-essential');?> </option>
           <option  value="ew_cpt"> <?php echo esc_html__("CPT cache",'quomodo-market-essential'); ?> </option>
      </select>
         <label for="username"><?php echo esc_html__("User",'quomodo-market-essential'); ?></label>
         <input value="<?php echo get_option( 'ew_envato_option_form_user' ); ?>" type="text" name="user_name" placeholder="<?php echo esc_attr__( 'Themeforest Username', 'quomodo-market-essential' ) ?>" id="username" required>
         <label for="sitename"> <?php echo esc_html__("Site",'quomodo-market-essential'); ?> </label>
         <input value="<?php echo get_option( 'ew_envato_option_form_site' ); ?>" type="text" name="site_name" id="sitename" placeholder="<?php echo esc_attr__( 'themeforest', 'quomodo-market-essential' ) ?>" required>
         <br/>
         <input type="hidden" name="action" value="ew_cpt_api_settings_form">
         <input class="button button-primary" id="ew-admin-submit" type="submit" value=" <?php echo esc_attr__( 'Submit', 'quomodo-market-essential' ) ?>">
      </form>
  
  
        <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
           <input type="hidden" name="action" value="ew_cpt_api_settings_form_cache_remove">
           <input class="button button-secondary" id="ew-admin-submit" type="submit" value=" <?php echo esc_attr__( 'Clear cache', 'quomodo-market-essential' ) ?>">
        </form>

        <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
           <input type="hidden" name="action" value="ew_cpt_api_settings_for_clear_schedule">
           <input class="button button-danger" id="ew-admin-submit" type="submit" value="<?php echo esc_attr__( 'Remove Schedule', 'quomodo-market-essential' ) ?>">
        </form>
   
     
</div>
   <?php     
   }
}

if( is_admin() ){

    $CustomCptSettingsPage = new Quomodo_Market_Custom_Cpt_SettingsPage();

    add_action( 'admin_post_ew_cpt_api_settings_form', 'quomodo_market_cpt_api_settings_form' );

    function quomodo_market_cpt_api_settings_form() {
   
        $user = esc_html($_POST["user_name"]);
        $site = esc_html($_POST["site_name"]);
        $sourece = esc_html($_POST["ew_data_type"]);
  
        update_option( 'ew_envato_option_form_user', $user );
        update_option( 'ew_envato_option_form_site', $site );
        update_option( 'ew_envato_option_form_data_source', $sourece );
        $message = esc_html__("Done",'quomodo-market-essential');
        if( $sourece=='0' ){
              
            wp_redirect(admin_url('edit.php?axsdas=asdasd&post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
        }

        if( $sourece=="ew_cpt" ){

            quomodo_market_ewMakeCpt();
        
        } elseif ($sourece=="ew_restapi") { // server source
         
         $products = [];
         if($site!='' && $user!='') {
            $products = quomodo_market_getAllProducts($user,$site);
         }
       
         if(count($products)) {
           
            foreach($products as $pr_key=>$pr_value){
              
               $ew_meta_id = '';
               $ew_meta_id= $pr_value["id"];
            
               global $wpdb;
               $is_product_db = $wpdb->get_results( 
               $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}postmeta WHERE `meta_key` LIKE '%envato_item_id%' AND `meta_value` = %s", 
                  $ew_meta_id 
                  ) 
               );

               // new item add to db
               if(!count($is_product_db)) {
                  quomodo_market_makeEwPortfolioItem($pr_value);
               }
               //end new item add
            }
            flush_rewrite_rules();
         }
         quomodo_market_ewMakeCpt();
         quomodo_market_getItemCategory($user,$site);
     
   }
   
         wp_redirect(admin_url('edit.php?post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
   
    }


    add_action( 'admin_post_ew_cpt_api_settings_form_cache_remove', 'quomodo_market_cpt_api_settings_form_cache_remove' );

    function quomodo_market_cpt_api_settings_form_cache_remove(){
        $message = esc_html__("Done",'quomodo-market-essential');
        try{
        
            quomodo_market_product_cache_clear();
            quomodo_market_scheduleClear();   
            wp_redirect(admin_url('edit.php?post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
           
        } catch (\Exception $ex) {
            $message = $ex->getMessage();
            wp_redirect(admin_url('edit.php?post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
        }
    
    
    }

    add_action("admin_post_ew_cpt_api_settings_for_clear_schedule","quomodo_market_cpt_api_settings_for_clear_schedule_callback");
    function quomodo_market_cpt_api_settings_for_clear_schedule_callback(){
        $message = esc_html__("Done",'quomodo-market-essential');
        try{
        
            quomodo_market_scheduleClear();   
            wp_redirect(admin_url('edit.php?post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
    
        } catch (\Exception $ex) {
            $message = $ex->getMessage();
            wp_redirect(admin_url('edit.php?post_type=envato-portfolio&page=ew_rest_api_data_setting&message='.$message));
        }
        
    }

}

   