<?php 
// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $post_prefix = 'quomodo_market_themeforst_options';
  
    //
    // Create a metabox for post
    CSF::createMetabox( $post_prefix, array(
      'title'     => 'Settings',
      'post_type' => 'envato-portfolio',
      'data_type' => 'unserialize',
       
    ) );
    
    CSF::createSection( $post_prefix, array(
      'title'  => esc_html__( 'General', 'quomodo-market-essential'),
      'fields' => array(
          array(
            'id'    => 'ew_envato_item_sub_title',
            'type'  => 'text',
            'title' => esc_html__('Sub Title','quomodo-market-essential'),
          ),
         array(
            'id'    => 'ew_envato_item_id',
            'type'  => 'text',
            'title' => esc_html__('Product ID','quomodo-market-essential'),
          ),
          array(
            'id'    => 'ew_envato_item_url',
            'type'  => 'text',
            'title' => esc_html__('Product URL','quomodo-market-essential'),
          ),
          
          array(
            'id'    => 'ew_envato_item_license_url',
            'type'  => 'text',
            'title' => esc_html__('Product License URL','quomodo-market-essential'),
          ),
          
          array(
            'id'    => 'ew_envato_item_user',
            'type'  => 'text',
            'title' => esc_html__('User','quomodo-market-essential'),
          ),
          
          array(
            'id'    => 'ew_envato_item_sales',
            'type'  => 'text',
            'title' => esc_html__('Item Sales','quomodo-market-essential'),
          ), 
          
          array(
            'id'    => 'ew_envato_item_rating',
            'type'  => 'text',
            'title' => esc_html__('Item Rating','quomodo-market-essential'),
          ),
          
          array(
            'id'    => 'ew_envato_item_cost',
            'type'  => 'text',
            'title' => esc_html__('Item Cost','quomodo-market-essential'),
          ), 
          
          array(
            'id'       => 'ew_envato_item_uploaded_on',
            'type'     => 'date',
            'title'    => esc_html__('Uploaded Date','quomodo-market-essential'),
            'settings' => array(
               'dateFormat'  => 'yy-mm-dd',
               'changeMonth' => true,
               'changeYear'  => true,
             )
          ),
          
          array(
            'id'       => 'ew_envato_item_updated_on',
            'type'     => 'date',
            'title'    => esc_html__('Updated On','quomodo-market-essential'),
            'settings' => array(
               'dateFormat'  => 'yy-mm-dd',
               'changeMonth' => true,
               'changeYear'  => true,
             )
          ),

          array(
            'id'    => 'ew_envato_item_tags',
            'type'  => 'textarea',
            'title' => esc_html__('Tags','quomodo-market-essential'),
          ),
          
          array(
            'id'    => 'ew_envato_item_category',
            'type'  => 'textarea',
            'title' => esc_html__('Categories','quomodo-market-essential'),
          ), 

          array(
            'id'    => 'ew_envato_affiliate_url',
            'type'  => 'text',
            'title' => esc_html__('Affiliate URL','quomodo-market-essential'),
          ), 
          
 
         
      )
    ) );
 

 
  
  
  }
  