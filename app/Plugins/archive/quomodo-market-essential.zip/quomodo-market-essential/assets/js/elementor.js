( function( $ ) {
  
   

       /*===============================  
             BRAND ACTIVE SLICK JS
        ================================*/
      
      var Widget_Sponsor = function( $scope, $ ) {

        var $container  = $scope.find('.brand-active');
   
        $container.slick({
            arrows: false,
            dots: false,
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            responsive: [
                {
                    breakpoint: 1600,
                    settings: {
                        slidesToShow: 5,
                    }
            }, {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 4,
                    }
            },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                    }
            },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                    }
            },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1,
                    }
            }
        ]
        });        
        
       
      }; 

      /*--------------------------------------------------------
      / . Widget_Testimonial_Slider  
      /----------------------------------------------------------*/
      
      var Widget_Testimonial_Slider = function( $scope, $ ) {

        var $container  = $scope.find('.testimonial-slider-ele');

        var controls    = null;
        var nav         = null;
        var style         = null;
        var control_obj = {};
        controls    = JSON.parse($container.attr('data-controls'));
        style         = $container.attr('data-style');
        control_obj = quomodomarket_slider_controls(controls);
       
        if(!control_obj.slider_enable){
          return; 
        }

       console.log(control_obj);
        $container.slick({
            arrows: control_obj.quomodomarket_slider_nav_show,
            prevArrow: '<span class="prev"><i class="fal fa-long-arrow-left"></i></span>',
            nextArrow: '<span class="next"><i class="fal fa-long-arrow-right"></i></span>',
            dots: false,
            infinite: control_obj.quomodomarket_slider_loop,
            fade: true,
            slidesToShow: control_obj.quomodomarket_slider_items,
            slidesToScroll: 1,
            autoplay: control_obj.quomodomarket_slider_autoplay,
            autoplaySpeed: control_obj.quomodomarket_slider_smart_speed,
            responsive: [
                {
                    breakpoint: 576,
                    settings: {
                        arrows: control_obj.quomodomarket_slider_nav_show,
                    }
            }
        ]
        });

      }; 

  
  

	// Make sure you run this code under Elementor.
	$( window ).on( 'elementor/frontend/init', function() {
        
	   	// elementorFrontend.hooks.addAction( 'frontend/element_ready/quomodo-marketplace-intro-banner.default', intro_banner );
	   	// elementorFrontend.hooks.addAction( 'frontend/element_ready/quomodo-marketplace-intro-banner-button.default', Widget_hero_slider );
	   	// elementorFrontend.hooks.addAction( 'frontend/element_ready/quomodo-marketplace-quote-service.default', Widget_quote_service );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/quomodo-marketplace-testimonial-slider.default', Widget_Testimonial_Slider );
	   	elementorFrontend.hooks.addAction( 'frontend/element_ready/quomodo-marketplace-brend.default', Widget_Sponsor );
	   
    } );

   
   // utility function  
   // get slider control default settings
   function quomodomarket_slider_controls(controls=[]){
    var newObj = {

      quomodomarket_slider_autoplay:true,
      quomodomarket_slider_loop:false,
      quomodomarket_slider_autoplay_hover_pause:false,
      quomodomarket_slider_autoplay_timeout:5000,
      quomodomarket_slider_dot_nav_show:false,
      quomodomarket_slider_items:2,
      quomodomarket_slider_items_mobile:1,
      quomodomarket_slider_items_tablet:3,
      quomodomarket_slider_margin:20,
      quomodomarket_slider_nav_show:false,
      slider_enable:true,
      quomodomarket_slider_smart_speed:250,

    };
  
    if ('quomodomarket_slider_autoplay' in controls){
      if(controls.quomodomarket_slider_autoplay == 'yes'){
        newObj.quomodomarket_slider_autoplay = true;
      }else{
        newObj.quomodomarket_slider_autoplay = false;
      }  
    }  
    
    if ('quomodomarket_slider_loop' in controls){
      if(controls.quomodomarket_slider_loop == 'yes'){
        newObj.quomodomarket_slider_loop = true;
      }else{
        newObj.quomodomarket_slider_loop = false;
      }  
    }

    if ('quomodomarket_slider_dot_nav_show' in controls){
      if(controls.quomodomarket_slider_dot_nav_show == 'yes'){
        newObj.quomodomarket_slider_dot_nav_show = true;
      }else{
        newObj.quomodomarket_slider_dot_nav_show = false;
      }  
    } 
    
    if ('slider_enable' in controls){
      if(controls.slider_enable == 'yes'){
        newObj.slider_enable = true;
      }else{
        newObj.slider_enable = false;
      }  
    }
     if ('quomodomarket_slider_nav_show' in controls){
      if(controls.quomodomarket_slider_nav_show == 'yes'){
        newObj.quomodomarket_slider_nav_show = true;
      }else{
        newObj.quomodomarket_slider_nav_show = false;
      }  
    }

    if ('quomodomarket_slider_autoplay_timeout' in controls){
       newObj.quomodomarket_slider_autoplay_timeout = parseInt( controls.quomodomarket_slider_autoplay_timeout );
    }

    if ('quomodomarket_slider_items' in controls){
        newObj.quomodomarket_slider_items = parseInt( controls.quomodomarket_slider_items || 1 );
    }
    
    if ('slider_enable' in controls){
        newObj.slider_enable = Boolean( controls.slider_enable =='yes'?true:false);
    }

    if ('quomodomarket_slider_items_mobile' in controls){
        newObj.quomodomarket_slider_items_mobile = parseInt( controls.quomodomarket_slider_items_mobile || 1 );
    }
    if ('quomodomarket_slider_items_tablet' in controls){
        newObj.quomodomarket_slider_items_tablet = parseInt( controls.quomodomarket_slider_items_tablet || 1 );
    }
    
    if ('quomodomarket_slider_margin' in controls){
        newObj.quomodomarket_slider_margin =  controls.quomodomarket_slider_margin || 0;
    } 
    
    if ('quomodomarket_slider_smart_speed' in controls){
        newObj.quomodomarket_slider_smart_speed =  controls.quomodomarket_slider_smart_speed || 250;
    }
    return newObj; 
  }



  
} )( jQuery );


