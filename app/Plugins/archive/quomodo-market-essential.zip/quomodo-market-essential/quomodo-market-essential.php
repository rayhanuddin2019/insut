<?php
/*
* Plugin Name: Quomodo Market Essentials
* License - GNU/GPL V2 or Later
* Description: This is a essential plugin for Quomod MarketPlace theme.
* Version: 1.0
* text domain: quomodo-market-essential
*/

// If this file is calledd directly, abort!!!
defined( 'ABSPATH' ) or die( 'Hey, what are you doing here? You silly human!' );

// Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/** 
 * plugin constant
 */
define( 'QTRP', true );
define( 'QUOMODOMARKET_ESSENTIAL_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'QUOMODOMARKET_ESSENTIAL_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'QUOMODOMARKET_ESSENTIAL_PLUGIN',plugin_basename( dirname( __FILE__ ) ) . '/quomodo-marketplace-essential.php');
define( 'QUOMODOMARKET_ESSENTIAL_IMG', get_template_directory_uri() . '/assets/images');
define( 'QUOMODOMARKET_ESSENTIAL_CSS', get_template_directory_uri() . '/assets/css');
define( 'QUOMODOMARKET_ESSENTIAL_THEME_DIR', get_template_directory() );
define( 'QUOMODOMARKET_ESSENTIAL_CSS_DIR', QUOMODOMARKET_ESSENTIAL_THEME_DIR . '/assets/css' );

/* Option Framework */
require_once QUOMODOMARKET_ESSENTIAL_PLUGIN_PATH .'app/codestar-framework/codestar-framework.php'; 
/**
 * The code that runs during plugin activation
 */
add_action( 'plugins_loaded', 'quomodomarket_essential_crb_load' );

function quomodomarket_essential_crb_load() {

	\Carbon_Fields\Carbon_Fields::boot();
	
}

function quomodomarket_activate_essential_plugin() {
	QuomodoMarketEssential\Base\Activate::activate();
}
register_activation_hook( __FILE__, 'quomodomarket_activate_essential_plugin' );

/**
 * The code that runs during plugin deactivation
 */
function quomodomarket_deactivate_essential_plugin() {
	QuomodoMarketEssential\Base\Deactivate::deactivate();
}

register_deactivation_hook( __FILE__, 'quomodomarket_deactivate_essential_plugin' );

/**
 * Initialize all the core classes of the plugin
 */

if ( class_exists( 'QuomodoMarketEssential\\Init' ) ) {
	QuomodoMarketEssential\Init::register_services();
	QuomodoMarketEssential\Init::register_modules();
}
// codester custom fonts
add_action('csf_loaded',function(){

	$themefonts = new \QuomodoMarketEssential\Base\ThemeFonts();
	$themefonts->register();	
	
});


