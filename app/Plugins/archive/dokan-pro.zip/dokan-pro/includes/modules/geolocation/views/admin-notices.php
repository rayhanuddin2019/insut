<div id="message" class="error notice is-dismissible">
    <p><?php _e( '<strong>Dokan Geolocation Module</strong> requires Google Map API Key or Mapbox Access Token. Please set your API Key or Token in <strong>Dokan Admin Settings > Appearance</strong>.', 'dokan' ); ?></p>
</div>
