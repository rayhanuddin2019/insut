import AbuseReports from './pages/AbuseReports.vue';

dokan_add_route(AbuseReports);
